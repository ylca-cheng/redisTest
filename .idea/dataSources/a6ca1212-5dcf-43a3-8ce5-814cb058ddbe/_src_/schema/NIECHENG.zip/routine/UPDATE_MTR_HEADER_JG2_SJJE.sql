CREATE procedure UPDATE_MTR_HEADER_JG2_SJJE(v_rid in number) is
  type def_cursor is ref cursor;
  tmp_cursor       def_cursor;
  v_mtr_header_def mtr_header%rowtype;

begin
  open tmp_cursor for
    SELECT h.id, h.jg2 from mtr_header h where h.rid = v_rid;
  loop
    fetch tmp_cursor
      into v_mtr_header_def.id, v_mtr_header_def.jg2;
    exit when tmp_cursor%notfound;

    UPDATE MTR_HEADER
       SET sjje = v_mtr_header_def.jg2
     where id = v_mtr_header_def.id;
    commit;

  end loop;
  close tmp_cursor;
end UPDATE_MTR_HEADER_JG2_SJJE;

/
