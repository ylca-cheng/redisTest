CREATE function fuc_age (c_d date,p_a varchar2)
	return number
is
	l_date date;
begin
 	l_date := to_date(p_a,'YYYYMMDD');
	return floor(months_between(c_d,l_date)/12);
	exception when others then
 	return 0;
end;

/
