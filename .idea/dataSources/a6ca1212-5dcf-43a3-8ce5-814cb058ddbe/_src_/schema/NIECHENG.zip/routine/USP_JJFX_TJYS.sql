CREATE procedure usp_jjfx_tjys(argym in varchar2)
is
i number :=0;
ym number:=0;
  /*
    argym 格式 YYYY-MM
  */
  begin
    select to_number(to_char(to_date(argym||'-01','YYYY-MM-DD'),'YYYYMM')) into ym  from dual;

    -- 删除TJYS_RMZ
  delete from TJYS_RMZ where tjrq like ym||'%';
  commit;
  --删除TJYS_YMZ
  delete from TJYS_YMZ where tjrq=ym;
  commit;
  --删除TJYS_YMZXM
  delete from TJYS_YMZXM where tjrq=ym;
  commit;
  --删除TJYS_YZY
  delete from TJYS_YZY where tjrq=ym;
  commit;
  --删除TJYS_YZYXM
  delete from TJYS_YZYXM where tjrq=ym;
  commit;

  --汇总入TJYS_RMZ
  i:=0;
  for r_row in
  (
  select to_number(to_char(yscyrq,'YYYYMMDD')) tjrq,jgid,ysdm gh
  ,count(distinct ghdjid) num01,0 num02,0 num03,0 num04,0 num05
  from JJFX_CFMX_TMP
  where jzlx='1' and ysdm is not null
  group by to_number(to_char(yscyrq,'YYYYMMDD')),jgid,ysdm
  )
  loop
  insert into TJYS_RMZ (tjrq,jgid,gh,num01,num02,num03,num04,num05)
  values (r_row.tjrq,r_row.jgid,r_row.gh,r_row.num01,r_row.num02,r_row.num03,r_row.num04,r_row.num05);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入TJYS_YMZ
  i:=0;
  for y_row in
  (
  select tjrq,jgid,gh,ddm
  ,sum(num01) num01,sum(num02) num02,sum(num03) num03
  ,sum(num04) num04,sum(num05) num05,sum(num06) num06
  ,sum(num07) num07,sum(num08) num08,sum(num09) num09
  ,sum(num10) num10
  from
  (select rqm tjrq,jgid,ysgh gh,ddm,sum(r002) num01,sum(r001) num02,0 num03,0 num04,0 num05
  ,0 num06,0 num07,0 num08,0 num09,0 num10
  from tj_mz
  where rqm=ym
  group by rqm,jgid,ysgh,ddm
  union all
  select rqm tjrq,jgid,ysgh gh,ddm,0 num01,0 num02
  ,sum(decode(xmlb,'1',r001,0)) num03
  ,sum(decode(xmlb,'2',r001,0)) num04
  ,sum(decode(xmlb,'3',r001,0)) num05
  ,0 num06,0 num07,0 num08,0 num09,0 num10
  from tj_mzxm
  where rqm=ym
  group by rqm,jgid,ysgh,ddm) t
  group by tjrq,jgid,gh,ddm
  )
  loop
  insert into TJYS_YMZ (tjrq,jgid,gh,ddm,num01,num02,num03,num04,num05,num06,num07,num08,num09,num10)
  values (y_row.tjrq,y_row.jgid,y_row.gh,y_row.ddm
  ,y_row.num01,y_row.num02,y_row.num03,y_row.num04,y_row.num05
  ,y_row.num06,y_row.num07,y_row.num08,y_row.num09,y_row.num10);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入TJYS_YMZXM
  i:=0;
  for x_row in
  (
  select rqm tjrq,jgid,ysgh gh,xmdm,xmlb,xmdj,sflb
  ,sum(r002) num01,sum(r003) num02,sum(r001) num03,0 num04,0 num05
  from tj_mzxm
  where rqm=ym
  group by rqm,jgid,ysgh,xmdm,xmlb,xmdj,sflb
  )
  loop
  insert into TJYS_YMZXM (tjrq,jgid,gh,xmdm,xmlb,xmdj,sflb,num01,num02,num03,num04,num05)
  values (x_row.tjrq,x_row.jgid,x_row.gh,x_row.xmdm,x_row.xmlb,x_row.xmdj,x_row.sflb
  ,x_row.num01,x_row.num02,x_row.num03,x_row.num04,x_row.num05);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入TJYS_YZY
  i:=0;
  for y_row in
  (
  select tjrq,jgid,gh,ddm
  ,sum(num01) num01,sum(num02) num02,sum(num03) num03
  ,sum(num04) num04,sum(num05) num05,sum(num06) num06
  ,sum(num07) num07,sum(num08) num08,sum(num09) num09
  ,sum(num10) num10
  from
  (select rqm tjrq,jgid,ysgh gh,ddm,sum(r002) num01,sum(r006) num02,sum(r001) num03,0 num04,0 num05
  ,0 num06,0 num07,0 num08,0 num09,0 num10
  from tj_zy
  where rqm=ym
  group by rqm,jgid,ysgh,ddm
  union all
  select rqm tjrq,jgid,ysgh gh,ddm,0 num01,0 num02,0 num03
  ,sum(decode(xmlb,'1',r001,0)) num04
  ,sum(decode(xmlb,'2',r001,0)) num05
  ,sum(decode(xmlb,'3',r001,0)) num06
  ,0 num07,0 num08,0 num09,0 num10
  from tj_zyxm
  where rqm=ym
  group by rqm,jgid,ysgh,ddm) t
  group by tjrq,jgid,gh,ddm
  )
  loop
  insert into TJYS_YZY (tjrq,jgid,gh,ddm,num01,num02,num03,num04,num05,num06,num07,num08,num09,num10)
  values (y_row.tjrq,y_row.jgid,y_row.gh,y_row.ddm
  ,y_row.num01,y_row.num02,y_row.num03,y_row.num04,y_row.num05
  ,y_row.num06,y_row.num07,y_row.num08,y_row.num09,y_row.num10);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入TJYS_YZYXM
  i:=0;
  for x_row in
  (
  select rqm tjrq,jgid,ysgh gh,xmdm,xmlb,xmdj,sflb
  ,sum(r002) num01,sum(r003) num02,sum(r001) num03,0 num04,0 num05
  from tj_zyxm
  where rqm=ym
  group by rqm,jgid,ysgh,xmdm,xmlb,xmdj,sflb
  )
  loop
  insert into TJYS_YZYXM (tjrq,jgid,gh,xmdm,xmlb,xmdj,sflb,num01,num02,num03,num04,num05)
  values (x_row.tjrq,x_row.jgid,x_row.gh,x_row.xmdm,x_row.xmlb,x_row.xmdj,x_row.sflb
  ,x_row.num01,x_row.num02,x_row.num03,x_row.num04,x_row.num05);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  end;

/
