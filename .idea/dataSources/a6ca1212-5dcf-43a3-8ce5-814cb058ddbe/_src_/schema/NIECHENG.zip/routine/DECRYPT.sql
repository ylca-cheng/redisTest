CREATE FUNCTION decrypt(outpass in varchar2)
RETURN varchar2 IS
string_in varchar2(78);
string_out varchar2(39);
offset number(2);
inpass varchar2(30);

BEGIN
string_in :='YN8K1JOZVURB3MDETS5GPL27AXWIHQ94C6F0#$_';
string_out :='_$#ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
offset:=instr(string_in,substr(outpass,1,1));
string_in:=string_in||string_in;
string_in:=substr(string_in,offset,39);
inpass:=translate(upper(substr(outpass,2)),
string_out,string_in);
return inpass;
end;

/
