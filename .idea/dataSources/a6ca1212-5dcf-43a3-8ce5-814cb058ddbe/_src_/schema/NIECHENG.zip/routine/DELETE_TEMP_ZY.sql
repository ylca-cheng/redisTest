CREATE procedure delete_temp_zy is
n number(10);
cur number(10);
need_delete number(10);
begin
DBMS_OUTPUT.ENABLE(buffer_size => null);
select count(*) into n from temp_zy t where t.ysflsh is not null;

cur:=1;
loop

  execute immediate 'truncate table temp_zy_id';
  insert into temp_zy_id
    select zy1.id t1_id,zy2.id t3_id from (
    select "XM","ID","LSH","YSFLSH","MXDM","MXSL","MXJE","RK" from (
    select
    t1.xm,
    t1.id,
    t1.lsh,
    t1.ysflsh,
    t1.mxdm,
    t1.mxsl,
    t1.mxje,
    rank() over(partition by t1.xm,t1.mxdm,t1.ysflsh,abs(t1.mxsl),abs(t1.mxje) order by id) rk
    from temp_zy t1
    where
    t1.mxje<0
    ) zy
    )zy1
    inner join
    (select "XM","ID","LSH","YSFLSH","MXDM","MXSL","MXJE","RK" from (
    select
    t1.xm,
    t1.id,
    t1.lsh,
    t1.ysflsh,
    t1.mxdm,
    t1.mxsl,
    t1.mxje,
    rank() over(partition by t1.xm,t1.lsh,t1.mxdm,abs(t1.mxsl),abs(t1.mxje) order by id) rk
    from temp_zy t1
    where
    t1.mxje>0
    ) zy
/*    where
    zy.xm='丁美兰' and abs(zy.mxje)=5.9
    and zy.lsh='1301010278811253'
*/    )zy2 on zy2.lsh=zy1.ysflsh and zy1.mxdm=zy2.mxdm and zy1.mxsl=-zy2.mxsl and zy1.mxje=-zy2.mxje
    and zy1.rk=zy2.rk;

  commit;

  select count(*) into need_delete from temp_zy_id;
  If need_delete=0 or cur>=n then
    dbms_output.put_line('第'||to_char(cur)||'批要删除数为0行。程序结束。当前时间'||to_char(sysdate,'hh:mi:ss'));


    insert into log_report
    values(sysdate,'delete_temp_zy',
    '第'||to_char(cur)||'批要删除数为0行。程序结束');
    commit;
    exit;
  end if;



  delete from temp_zy t
  where exists(select 1 from temp_zy_id i where t.id=i.t1_id);
  commit;

  dbms_output.put_line('第'||to_char(cur)||'批已删除'||to_char(need_delete)
  ||'行数据。当前时间'||to_char(sysdate,'hh:mi:ss'));
    insert into log_report
    values(sysdate,'delete_temp_zy',
    '第'||to_char(cur)||'批已删除'||to_char(need_delete)
  ||'行数据。');
    commit;

  delete from temp_zy t
  where exists(select 1 from temp_zy_id i where t.id=i.t3_id);
  dbms_output.put_line('已删除配对数据'||to_char(need_delete)||
   '行。当前时间'||to_char(sysdate,'hh:mi:ss'));
  commit;

  insert into log_report
  values(sysdate,'delete_temp_zy',
  '第'||to_char(cur)||'批已删除'||to_char(need_delete)
  ||'行数据。');
  commit;

  cur:=cur+1;

end loop;

end delete_temp_zy;

/
