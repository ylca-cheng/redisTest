CREATE procedure USP_CK01_CBRY is
  i      number := 0;
  I_PCDM VARCHAR2(200);
begin
  select nvl((select CS
               from APP_OPTION
              where lbdm = 'FXPCDM'
                and rownum = 1),
             '') PCDM
    into I_PCDM
    from dual;

  for ghdj_row in (select cj.grid as id,
                          max(cj.grmc) as xm,
                          decode(mod(substr(max(cj.zjhm), 17, 1), 2),
                                 0,
                                 2,
                                 1,
                                 1) as xb,
                          substr(max(cj.zjhm), 7, 8) as csrq,
                          cj.grid as dm,
                          max(cj.dwid) as dwid,
                          max(cj.dwid) as dwdm,
                          max(cj.zjhm) as zjhm,
                          max(cj.hzkh) as ybkh              -----------20140504加 by zjy
                     from CK10_GHDJ cj
                    where
                     lengthb(cj.zjhm)>=18
                     and replace(translate(substr(zjhm,1,17), '0123456789', '0'), '0', '') is null
                     and cj.grid is not null
                      and not exists
                    (select * from ck01_cbry cy where cy.id = cj.grid)
                    group by cj.grid) loop
    i := i + 1;
    insert into ck01_cbry
      (id, xm, xb, csrq, dm, dwid, dwdm, zjhm,ybkh)
    values
      (ghdj_row.id,
       ghdj_row.xm,
       ghdj_row.xb,
       ghdj_row.csrq,
       ghdj_row.dm,
       ghdj_row.dwid,
       ghdj_row.dwdm,
       ghdj_row.zjhm,
       ghdj_row.ybkh);
    if (mod(i, 1000) = 0) then
      commit;
    end if;
  end loop;
  commit;
end;

/
