CREATE procedure largedata_insert(p_i_table_name   in varchar2, --目标表
                                             p_i_table_column in varchar2, --目标字段
                                             p_i_table_select in varchar2, --SELECT 查询语句
                                             v_rows in number --分批行数
                                             ) is

  /********************************************************
  名称：largedata_insert
  创建时间：2014-01-02
  描述：大数据分批插入提交
  由来：从网上找到相关的存储过程，然后由lqw进行修改
  ********************************************************/
  v_begin_time varchar2(20);
  v_end_time   varchar2(20);

  runTime number;
  i       number;
  amount  number;
  s_sql   varchar2(8000);
  s_sql2  varchar2(8000);
  --v_rows  number := 10000;

  v_deal_flag varchar2(1);

begin

  --获取开始时间
  v_begin_time := to_char(sysdate, 'yyyymmdd hh24:mi:ss');

  --核必逻辑内容，可根据具体的业务逻辑来定义
  s_sql := 'select count(1) from (' || p_i_table_select || ')';

  execute immediate s_sql
    into amount;

  --每(v_rows)万提交一次
  runTime := mod(amount, v_rows);

  if (runTime > 0) then
    runTime := 1 + trunc(amount / v_rows);
  end if;

  if (runTime = 0) then
    runTime := trunc(amount / v_rows);
  end if;

  for i in 1 .. runTime loop

    s_sql2 := ' insert into ' || p_i_table_name || ' (' || p_i_table_column ||
                 ' ) select ' || p_i_table_column || ' from ( select tt.*, rownum rownumType
                  from (' || p_i_table_select || ') tt
                  where rownum <= ' || i || '*' || v_rows || ')
                  where rownumType > (' || i || ' - 1) * ' || v_rows || '';
    EXECUTE IMMEDIATE 'truncate table t' ;
    INSERT INTO t VALUES(s_sql2) ;
    COMMIT;
    execute immediate s_sql2;

    commit;

  end loop;

  dbms_output.put_line('结束' || to_char(sysdate, 'yyyymmddhh24miss'));

exception
  when others then
    rollback;

    v_end_time  := to_char(sysdate, 'yyyymmdd hh24:mi:ss');
    v_deal_flag := '0';

    --使用存储过程 pr_log_write 向 log_record 插入错误日志记录
    pr_log_write('largedata_insert',
                 '',
                 v_begin_time,
                 v_end_time,
                 v_deal_flag,
                 '',
                 sqlcode,
                 substr(sqlerrm, 1, 500),
                 s_sql2);

    raise;

    raise;

end largedata_insert;

/
