CREATE procedure usp_jjfx_hzpm(argym in varchar2)
is
i number :=0;
ym number:=0;
  /*
    argym 格式 YYYY-MM
  */
  begin

    select to_number(to_char(to_date(argym||'-01','YYYY-MM-DD'),'YYYYMM')) into ym from dual;

    --删除TJHZ_PM01
  delete from TJHZ_PM01 where tjrq=ym;
  commit;
    --删除TJHZ_PM02
  delete from TJHZ_PM02 where tjrq=ym;
  commit;
    --删除TJHZ_PM03
  delete from TJHZ_PM03 where tjrq=ym;
  commit;
    --删除TJHZ_PM04
  delete from TJHZ_PM04 where tjrq=ym;
  commit;
    --删除TJHZ_PM05
  delete from TJHZ_PM05 where tjrq=ym;
  commit;
  --删除TJHZ_PM06
  delete from TJHZ_PM06 where tjrq=ym;
  commit;

    --汇总入TJHZ_PM01
  insert into TJHZ_PM01(tjrq,grid,pm,jg)
  select ym,t.grid,rownum,t.jg
  from
  (select grid,count(distinct ghdjid) jg
  from jjfx_jsmx_tmp
  where jzlx='1' and grid is not null
  group by grid
  having count(distinct ghdjid)>=10
  order by count(distinct ghdjid) desc) t
  where rownum<=1000;
  commit;

    --汇总入TJHZ_PM02
  insert into TJHZ_PM02(tjrq,grid,pm,jg)
  select ym,t.grid,rownum,t.jg
  from
  (select grid,sum(zfy) jg
  from jjfx_jsmx_tmp
  where jzlx='1' and grid is not null
  group by grid
  having sum(zfy)>=1000
  order by sum(zfy) desc) t
  where rownum<=1000;
  commit;

    --汇总入TJHZ_PM03
  insert into TJHZ_PM03(tjrq,grid,pm,jg)
  select ym,t.grid,rownum,t.jg
  from
  (select grid,count(distinct ghdjid) jg
  from jjfx_jsmx_tmp
  where jzlx='2' and grid is not null
  group by grid
  order by count(distinct ghdjid) desc) t
  where rownum<=1000;
  commit;

    --汇总入TJHZ_PM04
  insert into TJHZ_PM04(tjrq,grid,pm,jg)
  select ym,t.grid,rownum,t.jg
  from
  (select grid,sum(zfy) jg
  from jjfx_jsmx_tmp
  where jzlx='2' and grid is not null
  group by grid
  having sum(zfy)>=1000
  order by sum(zfy) desc) t
  where rownum<=1000;
  commit;

    --汇总入TJHZ_PM05
  insert into TJHZ_PM05(tjrq,grid,pm,jg)
  select ym,t.grid,rownum,t.jg
  from
  (select grid,count(distinct ghdjid) jg
  from jjfx_jsmx_tmp
  where jzlx='3' and grid is not null
  group by grid
  having count(distinct ghdjid)>=5
  order by count(distinct ghdjid) desc) t
  where rownum<=1000;
  commit;

  --汇总入TJHZ_PM06
  insert into TJHZ_PM06(tjrq,grid,pm,jg)
  select ym,t.grid,rownum,t.jg
  from
  (select grid,sum(zfy) jg
  from jjfx_jsmx_tmp
  where jzlx='3' and grid is not null
  group by grid
  having sum(zfy)>=1000
  order by sum(zfy) desc) t
  where rownum<=1000;
  commit;

  end;

/
