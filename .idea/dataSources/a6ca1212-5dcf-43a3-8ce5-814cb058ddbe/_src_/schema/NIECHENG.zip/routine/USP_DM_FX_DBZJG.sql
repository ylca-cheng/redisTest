CREATE procedure USP_DM_FX_DBZJG (ABYM in varchar2,AEYM in varchar2,ASFLB in varchar2,ADDM in varchar2)
is
  I_DEX NUMBER := 1;
  AJZLX NUMBER := 2;
  begin
 	for E in (
 		select a.ym,''||AJZLX jzlx,a.jgid,ADDM ddm,ASFLB ssflb
		,sum(r001) r001,sum(r002) r002,sum(r003) r003,sum(r004) r004,sum(r005) r005,sum(r006) r006
		,0 r007,0 r008,0 r009,0 r010
		from
		(select to_char(g.cyrq,'YYYY-MM') ym,g.jgid
		,0 r001,0 r002,count(distinct g.id) r003,0 r004,0 r005,sum(c.je) r006
		from
		(select * from ck10_ghdj
		where jzlx=AJZLX
		and cyrq between to_date(ABYM||'-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss')
		and last_day(to_date(AEYM||'-01 23:59:59', 'yyyy-mm-dd hh24:mi:ss'))
		and cyzddm like ADDM||'%') g
		,ck10_cfmx c
		where g.id=c.ghdjid
		and c.sflb in (select distinct ysflb from fx_dbzmb where jzlx=''||AJZLX and yxbz='1' and ddm=ADDM and ssflb=ASFLB)
		group by to_char(g.cyrq,'YYYY-MM'),g.jgid
		union all
		select to_char(g.cyrq,'YYYY-MM') ym,g.jgid
		,count(distinct g.id) r001,0 r002,0 r003,sum(c.je) r004,0 r005,0 r006
		from
		(select * from ck10_ghdj
		where jzlx=AJZLX
		and cyrq between to_date(ABYM||'-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss')
		and last_day(to_date(AEYM||'-01 23:59:59', 'yyyy-mm-dd hh24:mi:ss'))
		and cyzddm like ADDM||'%') g
		,ck10_cfmx c
		where g.id=c.ghdjid
		and c.sflb in (select distinct ysflb from fx_dbzmb where jzlx=''||AJZLX and yxbz='1' and ddm=ADDM and ssflb=ASFLB)
		and not exists (select 1 from (select * from fx_dbzmb where jzlx=''||AJZLX and yxbz='1' and ddm=ADDM and ssflb=ASFLB) d
		where d.ysflb=c.sflb and ((ASFLB in ('1','2','3') and d.xmmc=c.xmmc) or (ASFLB in ('4') and c.xmmc like '%'||d.xmmc||'%')))
		group by to_char(g.cyrq,'YYYY-MM'),g.jgid
		union all
		select to_char(g.cyrq,'YYYY-MM') ym,g.jgid
		,0 r001,count(distinct g.id) r002,0 r003,0 r004,sum(c.je) r005,0 r006
		from
		(select * from ck10_ghdj
		where jzlx=AJZLX
		and cyrq between to_date(ABYM||'-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss')
		and last_day(to_date(AEYM||'-01 23:59:59', 'yyyy-mm-dd hh24:mi:ss'))
		and cyzddm like ADDM||'%') g
		,ck10_cfmx c
		where g.id=c.ghdjid
		and c.sflb in (select distinct ysflb from fx_dbzmb where jzlx=''||AJZLX and yxbz='1' and ddm=ADDM and ssflb=ASFLB)
		and exists (select 1 from (select * from fx_dbzmb where jzlx=''||AJZLX and yxbz='1' and ddm=ADDM and ssflb=ASFLB) d
		where d.ysflb=c.sflb and ((ASFLB in ('1','2','3') and d.xmmc=c.xmmc) or (ASFLB in ('4') and c.xmmc like '%'||d.xmmc||'%')))
		group by to_char(g.cyrq,'YYYY-MM'),g.jgid) a
		group by a.ym,a.jgid
		)
  	LOOP
		INSERT INTO FX_DBZJG (YM,JZLX,JGID,DDM,SSFLB,R001,R002,R003,R004,R005,R006,R007,R008,R009,R010)
		VALUES(E.YM,E.JZLX,E.JGID,E.DDM,E.SSFLB,E.R001,E.R002,E.R003,E.R004,E.R005,E.R006,E.R007,E.R008,E.R009,E.R010);
		IF I_DEX>1000 THEN
   			COMMIT;
    		I_DEX:=I_DEX-1000;
   		END IF;
   			I_DEX:=I_DEX+1;
  	END LOOP;
  	COMMIT;
  end;

/
