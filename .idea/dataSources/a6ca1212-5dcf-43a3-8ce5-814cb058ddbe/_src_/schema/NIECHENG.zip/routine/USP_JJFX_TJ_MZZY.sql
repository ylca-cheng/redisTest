CREATE procedure usp_jjfx_tj_mzzy(argym in varchar2)
is
i number :=0;
ym1 number:=0;
yq number:=0;
yy number:=0;
  /*
    argym 格式 YYYY-MM
  */
  begin

    select to_number(to_char(to_date(argym||'-01','YYYY-MM-DD'),'YYYYMM')) into ym1  from dual;
  select to_number(to_char(to_date(argym||'-01','YYYY-MM-DD'),'YYYYQ')) into yq from dual;
  select to_number(to_char(to_date(argym||'-01','YYYY-MM-DD'),'YYYY')) into yy from dual;

    --删除TJ_MZ
  delete from TJ_MZ where rqm=ym1;
  commit;
  --删除TJ_ZY
  delete from TJ_ZY where rqm=ym1;
  commit;
  --删除TJ_MZXM
  delete from TJ_MZXM where rqm=ym1;
  commit;
  --删除TJ_ZYXM
  delete from TJ_ZYXM where rqm=ym1;
  commit;

    --汇总入TJ_MZ
  i:=0;
  for c_row in
  (
  select
  t.rqm,t.rqs,t.rqy,t.tcqdm,t.jgid,nvl(y.jgdj,'0') jgdj,nvl(y.jglx,'0') jglx
  ,t.ksdm,t.ysgh,t.ddm,t.dlb,t.yllb,t.rylb,t.xzlb
  ,t.r001,t.r002,t.r003,t.r004,t.r005,t.r006,t.r007,t.r008,t.r009,t.r010
  from
  (select
  ym1 rqm,yq rqs,yy rqy
  ,nvl(tcqdm,'0') tcqdm,jgid,nvl(ksdm,'0') ksdm,nvl(ysdm,'0') ysgh
  ,nvl(ddm,'0') ddm,nvl(ddm,'0') dlb
  ,nvl(yllb,'0') yllb,nvl(rylb,'0') rylb,'0' xzlb
  ,sum(nvl(zfy,0)) r001,count(distinct ghdjid) r002
  ,sum(nvl(tczf,0)) r003,sum(nvl(zhzf,0)) r004,sum(nvl(xjzf,0)) r005
  ,0 r006,0 r007,0 r008,0 r009,0 r010
  from JJFX_JSMX_TMP
  where 1=1
  and jzlx='1'
  group by nvl(tcqdm,'0'),jgid,nvl(ksdm,'0'),nvl(ysdm,'0'),nvl(ddm,'0'),nvl(yllb,'0'),nvl(rylb,'0')) t
  left join ck01_yljg y
  on t.jgid=y.id
  )
  loop
  insert into TJ_MZ
  (rqm,rqs,rqy,tcqdm,jgid,jgdj,jglx,ksdm,ysgh,ddm,dlb,yllb,rylb,xzlb
  ,r001,r002,r003,r004,r005,r006,r007,r008,r009,r010)
  values
  (c_row.rqm,c_row.rqs,c_row.rqy,c_row.tcqdm,c_row.jgid,c_row.jgdj,c_row.jglx
  ,c_row.ksdm,c_row.ysgh,c_row.ddm,c_row.dlb,c_row.yllb,c_row.rylb,c_row.xzlb
  ,c_row.r001,c_row.r002,c_row.r003,c_row.r004,c_row.r005
  ,c_row.r006,c_row.r007,c_row.r008,c_row.r009,c_row.r010);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入TJ_ZY
  i:=0;
  for c_row in
  (
  select
  t.rqm,t.rqs,t.rqy,t.tcqdm,t.jgid,nvl(y.jgdj,'0') jgdj,nvl(y.jglx,'0') jglx
  ,t.ksdm,t.ysgh,t.ddm,t.dlb,t.yllb,t.rylb,t.xzlb
  ,t.r001,t.r002,t.r003,t.r004,t.r005,t.r006,t.r007,t.r008,t.r009,t.r010
  from
  (select
  ym1 rqm,yq rqs,yy rqy
  ,nvl(tcqdm,'0') tcqdm,jgid,nvl(ksdm,'0') ksdm,nvl(ysdm,'0') ysgh
  ,nvl(ddm,'0') ddm,nvl(ddm,'0') dlb
  ,nvl(yllb,'0') yllb,nvl(rylb,'0') rylb,'0' xzlb
  ,sum(nvl(zfy,0)) r001,count(distinct ghdjid) r002
  ,sum(nvl(tczf,0)) r003,sum(nvl(zhzf,0)) r004,sum(nvl(xjzf,0)) r005
  ,sum(nvl(zyts,1)) r006,0 r007,0 r008,0 r009,0 r010
  from JJFX_JSMX_TMP
  where 1=1
  and jzlx='2'
  group by nvl(tcqdm,'0'),jgid,nvl(ksdm,'0'),nvl(ysdm,'0'),nvl(ddm,'0'),nvl(yllb,'0'),nvl(rylb,'0')) t
  left join ck01_yljg y
  on t.jgid=y.id
  )
  loop
  insert into TJ_ZY
  (rqm,rqs,rqy,tcqdm,jgid,jgdj,jglx,ksdm,ysgh,ddm,dlb,yllb,rylb,xzlb
  ,r001,r002,r003,r004,r005,r006,r007,r008,r009,r010)
  values
  (c_row.rqm,c_row.rqs,c_row.rqy,c_row.tcqdm,c_row.jgid,c_row.jgdj,c_row.jglx
  ,c_row.ksdm,c_row.ysgh,c_row.ddm,c_row.dlb,c_row.yllb,c_row.rylb,c_row.xzlb
  ,c_row.r001,c_row.r002,c_row.r003,c_row.r004,c_row.r005
  ,c_row.r006,c_row.r007,c_row.r008,c_row.r009,c_row.r010);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入TJ_MZXM
  i:=0;
  for c_row in
  (
  select
  t.rqm,t.rqs,t.rqy,t.tcqdm,t.jgid,nvl(y.jgdj,'0') jgdj,nvl(y.jglx,'0') jglx
  ,t.ksdm,t.ysgh,t.ddm,t.dlb,t.yllb,t.rylb,t.xzlb
  ,t.xmdm,nvl(v.xmlb,'0') xmlb,nvl(v.xmdj,'0') xmdj,nvl(v.sflb,'0') sflb
  ,t.r001,t.r002,t.r003,t.r004,t.r005,t.r006,t.r007,t.r008,t.r009,t.r010
  from
  (select
  ym1 rqm,yq rqs,yy rqy
  ,nvl(tcqdm,'0') tcqdm,jgid,nvl(ksdm,'0') ksdm,nvl(ysdm,'0') ysgh
  ,nvl(ddm,'0') ddm,nvl(ddm,'0') dlb
  ,nvl(yllb,'0') yllb,nvl(rylb,'0') rylb,'0' xzlb,xmdm
  ,sum(nvl(je,0)) r001,count(distinct ghdjid) r002
  ,sum(nvl(sl,0)) r003,count(*) r004
  ,0 r005,0 r006,0 r007,0 r008,0 r009,0 r010
  from JJFX_CFMX_TMP
  where 1=1
  and jzlx='1'
  and xmdm is not null
  group by nvl(tcqdm,'0'),jgid,nvl(ksdm,'0'),nvl(ysdm,'0'),nvl(ddm,'0')
  ,nvl(yllb,'0'),nvl(rylb,'0'),xmdm) t
  left join ck01_yljg y
  on t.jgid=y.id
  left join v_sml v
  on t.xmdm=v.dm
  )
  loop
  insert into TJ_MZXM
  (rqm,rqs,rqy,tcqdm,jgid,jgdj,jglx,ksdm,ysgh,ddm,dlb,yllb,rylb,xzlb
  ,xmdm,xmlb,xmdj,sflb
  ,r001,r002,r003,r004,r005,r006,r007,r008,r009,r010)
  values
  (c_row.rqm,c_row.rqs,c_row.rqy,c_row.tcqdm,c_row.jgid,c_row.jgdj,c_row.jglx
  ,c_row.ksdm,c_row.ysgh,c_row.ddm,c_row.dlb,c_row.yllb,c_row.rylb,c_row.xzlb
  ,c_row.xmdm,c_row.xmlb,c_row.xmdj,c_row.sflb
  ,c_row.r001,c_row.r002,c_row.r003,c_row.r004,c_row.r005
  ,c_row.r006,c_row.r007,c_row.r008,c_row.r009,c_row.r010);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入TJ_ZYXM
  i:=0;
  for c_row in
  (
  select
  t.rqm,t.rqs,t.rqy,t.tcqdm,t.jgid,nvl(y.jgdj,'0') jgdj,nvl(y.jglx,'0') jglx
  ,t.ksdm,t.ysgh,t.ddm,t.dlb,t.yllb,t.rylb,t.xzlb
  ,t.xmdm,nvl(v.xmlb,'0') xmlb,nvl(v.xmdj,'0') xmdj,nvl(v.sflb,'0') sflb
  ,t.r001,t.r002,t.r003,t.r004,t.r005,t.r006,t.r007,t.r008,t.r009,t.r010
  from
  (select
  ym1 rqm,yq rqs,yy rqy
  ,nvl(tcqdm,'0') tcqdm,jgid,nvl(ksdm,'0') ksdm,nvl(ysdm,'0') ysgh
  ,nvl(ddm,'0') ddm,nvl(ddm,'0') dlb
  ,nvl(yllb,'0') yllb,nvl(rylb,'0') rylb,'0' xzlb,xmdm
  ,sum(nvl(je,0)) r001,count(distinct ghdjid) r002
  ,sum(nvl(sl,0)) r003,count(*) r004
  ,0 r005,0 r006,0 r007,0 r008,0 r009,0 r010
  from JJFX_CFMX_TMP
  where 1=1
  and jzlx='2'
  and xmdm is not null
  group by nvl(tcqdm,'0'),jgid,nvl(ksdm,'0'),nvl(ysdm,'0'),nvl(ddm,'0')
  ,nvl(yllb,'0'),nvl(rylb,'0'),xmdm) t
  left join ck01_yljg y
  on t.jgid=y.id
  left join v_sml v
  on t.xmdm=v.dm
  )
  loop
  insert into TJ_ZYXM
  (rqm,rqs,rqy,tcqdm,jgid,jgdj,jglx,ksdm,ysgh,ddm,dlb,yllb,rylb,xzlb
  ,xmdm,xmlb,xmdj,sflb
  ,r001,r002,r003,r004,r005,r006,r007,r008,r009,r010)
  values
  (c_row.rqm,c_row.rqs,c_row.rqy,c_row.tcqdm,c_row.jgid,c_row.jgdj,c_row.jglx
  ,c_row.ksdm,c_row.ysgh,c_row.ddm,c_row.dlb,c_row.yllb,c_row.rylb,c_row.xzlb
  ,c_row.xmdm,c_row.xmlb,c_row.xmdj,c_row.sflb
  ,c_row.r001,c_row.r002,c_row.r003,c_row.r004,c_row.r005
  ,c_row.r006,c_row.r007,c_row.r008,c_row.r009,c_row.r010);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  end;

/
