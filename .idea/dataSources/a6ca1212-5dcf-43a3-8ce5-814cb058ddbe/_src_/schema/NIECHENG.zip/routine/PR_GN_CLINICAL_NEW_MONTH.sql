CREATE procedure pr_gn_clinical_new_month(v_id in number) is



  v_begin_time varchar2(20);



  v_end_time   varchar2(20);



  v_rq   varchar2(20);



  bg_ghdj_seq      NUMBER ;



  ed_ghdj_seq      NUMBER ;



  min_data_status_info_id  NUMBER ;



  --var_ydlx varchar2(2);







  var_exec_cycle int;







  /**********************************************************************



  名称：pr_gn_clinical



  作者：lqw



  创建时间：20131220



  修改时间：2014-01-06



  描述：1、临床规则通用，根据规则id判别



          6, 7, 8, 110, 111, 112, 113, 114, 115, 117, 118, 121,  124, 125,



        126, 213, 306, 1010, 1020, 1070, 1080, 1150, 1160, 1210, 1290, 1620



  ***********************************************************************/







  v_pr_name varchar2(20) := 'pr_gn_clinical';







  v_mc varchar2(400);







begin







  --获取开始时间



  v_begin_time := to_char(sysdate, 'yyyymmdd hh24:mi:ss');







  v_pr_name := v_pr_name || '_' || v_id;







  v_rq := to_char(sysdate, 'yyyy-mm-dd');







  --获取阈值



  --select t.yz1 into v_yz1 from mt_rule t where t.id = v_id;



  --获取医疗类别



  --select t.yllb into v_yllb from mt_rule t where t.id = v_id;



  --获取规则名称



  select t.mc into v_mc from mt_rule t where t.id = v_id;



  --获取规则周期，exec_cycle = 0表示月汇总，exec_cycle=1 表示日汇总



  dbms_output.put_line('var_exec_cycle');



  select max(nvl(exec_cycle,1)) into var_exec_cycle from rule_config where code in(select dm from mt_rule where id = v_id);



   dbms_output.put_line('var_exec_cycle : ' || var_exec_cycle);



  --先删除日志记录



  delete from log_pr_rid_list t



   where t.rid = v_id;



  commit;







  --插入一条当前存储过程开始执行的记录 deal_flag=1



  insert into log_pr_rid_list



    (rid, pr_name, rq, deal_flag, begin_time,step_no)



  values



    (v_id, v_pr_name, v_rq, '1', v_begin_time,min_data_status_info_id);



  commit;







  --获取未分析的批次



  select min(t.id) into min_data_status_info_id from data_status_info t



  where t.clinical_summary_flag = '0' and t.clinical_analysis_flag='1';



  SELECT info.ghdj_max_seq,info.ghdj_min_seq INTO   ed_ghdj_seq,bg_ghdj_seq



  FROM data_status_info  info



  WHERE info.id = min_data_status_info_id and clinical_summary_flag = '0' and clinical_analysis_flag='1';







  ---------------------------------------------------------------------------------



  --执行时先删除mtr_header、mtr_mapping表中需要重跑的数据



  delete from mtr_header  where rid = v_id and id in



         (select hid from mtr_mapping p where p.rid = v_id and EXISTS



         (select 1 from ck10_ghdj g where g.id = p.lid and g.seq_id > bg_ghdj_seq and g.seq_id <= ed_ghdj_seq));



  delete from mtr_mapping where rid = v_id and lid in



         (select id from ck10_ghdj g where g.seq_id > bg_ghdj_seq and g.seq_id <= ed_ghdj_seq);







  ---------------------------------------header start----------------------------



if var_exec_cycle = 2 --按月进行汇总



then



  INSERT INTO mtr_header



     (rid,rq, jgid,jgdm,jgmc, hzid,jg1,jg2,sjje, jgms,jdtx,hzdm,hzmc,shzt,ysid,ysdm,ysmc,zjhm,tcqdm)



     SELECT V_ID AS RID,



        to_char(y.cfrq,'yyyy-mm') AS RQ,



        max(T.JGID),



        max(T.Jgdm),



        max(T.Jgmc),



				y.hzid,



        count(DISTINCT T.ID) as jg1,



        COUNT(DISTINCT T.ID) AS JG2,



        SUM(T.JE)*count(DISTINCT T.ID)/count(T.ID) AS SJJE, --mtr_clinical_result有重复



        ' 次。' AS JGMS,



        '疑似违反《 '||v_mc||' 》，涉及 ' ||count(distinct t.id)|| ' 次。' as jdtx,



        max(t.hzdm),



        max(t.hzxm) as hzmc,



        c.shzt,



				t.ysid,



				t.ysdm,



				t.ysmc,



				max(r.zjhm) zjhm,


				max(g.tcqdm) tcqdm


   FROM mtr_clinical_ydnr y



   left join  MTR_CLINICAL_RESULT T  on  t.id = y.mcrid



   left join ck10_ghdj g on g.id = y.ydid



	 left join mt_rule c on c.id = y.gzdm



	 left join ck01_cbry r on r.id=y.hzid



  WHERE y.ydlx = 1



    AND y.GZDM = V_ID



    AND g.seq_id > bg_ghdj_seq



    AND g.seq_id <= ed_ghdj_seq



    AND T.FLAG = 0



  GROUP BY y.gzdm,y.hzid,to_char(y.cfrq,'yyyy-mm'),c.shzt,t.ysid,t.ysdm,t.ysmc;







  commit;







  --------------------------------------------header end------------------------------







  ------------------------------mapping start-----------------------------------------







INSERT INTO MTR_MAPPING



   (HID, RID, RQ, LID)



 SELECT



 DISTINCT T.ID AS HID, v_id AS RID, t.rq AS RQ, y.ydid AS LID



   FROM mtr_clinical_ydnr y



   left join  mtr_header T  on  t.hzid = y.hzid and t.rq = TO_CHAR(y.CFRQ, 'yyyy-mm') and t.rid = y.gzdm



   left join ck10_ghdj g on g.id = y.ydid



  WHERE y.ydlx = 1



    AND y.GZDM = V_ID



    AND g.seq_id > bg_ghdj_seq



    AND g.seq_id <= ed_ghdj_seq



  GROUP BY y.hzid,t.rq,y.ydid,t.id;







    commit;



  ------------------------------mapping end-----------------------------------------



  else



  --按日进行汇总



dbms_output.put_line(to_char(sysdate,'yyyymmddhhmiss')||' 开始日汇总');



  INSERT INTO mtr_header



     (rid,rq, jgid,jgdm,jgmc, hzid,jg1,jg2,sjje, jgms,jdtx,hzdm,hzmc,shzt,ysid,ysdm,ysmc,zjhm,tcqdm)



     SELECT V_ID AS RID,



        to_char(y.cfrq,'yyyy-mm-dd') AS RQ,



        max(T.JGID),



        max(T.Jgdm),



        max(T.Jgmc),



				y.hzid,



        count(DISTINCT T.ID) as jg1,



        COUNT(DISTINCT T.ID) AS JG2,



        SUM(T.JE)*count(DISTINCT T.ID)/count(T.ID) AS SJJE, --mtr_clinical_result有重复



        ' 次。' AS JGMS,



        '疑似违反《 '||v_mc||' 》，涉及 ' ||count(distinct t.id)|| ' 次。' as jdtx,



        max(t.hzdm),



        max(t.hzxm) as hzmc,



        c.shzt,



				t.ysid,



				t.ysdm,



				t.ysmc,



				max(r.zjhm) zjhm
,


				max(g.tcqdm) tcqdm


   FROM mtr_clinical_ydnr y



   left join  MTR_CLINICAL_RESULT T  on  t.id = y.mcrid



   left join ck10_ghdj g on g.id = y.ydid



	 left join mt_rule c on c.id = y.gzdm



	 left join ck01_cbry r on r.id=y.hzid



  WHERE y.ydlx = 1



    AND y.GZDM = V_ID



    AND g.seq_id > bg_ghdj_seq



    AND g.seq_id <= ed_ghdj_seq



    AND T.FLAG = 0



  GROUP BY y.gzdm,y.hzid,to_char(y.cfrq,'yyyy-mm-dd'),c.shzt,t.ysid,t.ysdm,t.ysmc;







  commit;







  --------------------------------------------header end------------------------------



dbms_output.put_line(to_char(sysdate,'yyyymmddhhmiss') || ' end header');



  ------------------------------mapping start-----------------------------------------







INSERT INTO MTR_MAPPING



   (HID, RID, RQ, LID)



 SELECT



 DISTINCT T.ID AS HID, v_id AS RID, t.rq AS RQ, y.ydid AS LID



   FROM mtr_clinical_ydnr y



   left join  mtr_header T  on  t.hzid = y.hzid and t.rq = TO_CHAR(y.CFRQ, 'yyyy-mm-dd') and t.rid = y.gzdm



   left join ck10_ghdj g on g.id = y.ydid



  WHERE y.ydlx = 1



    AND y.GZDM = V_ID



    AND g.seq_id > bg_ghdj_seq



    AND g.seq_id <= ed_ghdj_seq



  GROUP BY y.gzdm,y.hzid,t.rq,y.ydid,t.id;







    commit;



  end if;



dbms_output.put_line(to_char(sysdate,'yyyymmddhhmiss') || ' end update');



  ----------------------------------mapping end----------------------------------------







  --获取结束时间



  v_end_time := to_char(sysdate, 'yyyymmdd hh24:mi:ss');











  --执行完成，更新执行状态为2(成功)



  update log_pr_rid_list t



     set t.deal_flag = '2', t.end_time = v_end_time



   where t.rid = v_id



     and t.rq = v_rq;



  commit;







exception



  when others then



    rollback;







    v_end_time  := to_char(sysdate, 'yyyymmdd hh24:mi:ss');







    --如果未执行成功，更新状态为0



    update log_pr_rid_list t



       set t.deal_flag = 0



     where t.rid = v_id



       and t.rq = v_rq;



    commit;







    --使用存储过程 pr_log_write 向 log_record 插入错误日志记录



    pr_hs_log_write(v_pr_name,



                 v_rq,



                 v_begin_time,



                 v_end_time,



                 0,



                 0,



                 sqlcode,



                 substr(sqlerrm, 1, 500),



                 '');







    raise;







end pr_gn_clinical_new_month;

/
