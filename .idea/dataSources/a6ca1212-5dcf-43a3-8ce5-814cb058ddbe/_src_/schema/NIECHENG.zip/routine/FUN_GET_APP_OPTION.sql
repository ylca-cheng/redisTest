CREATE function fun_get_app_option(v_lbdm in varchar2,
                                              v_dm   in varchar2)
  return varchar2 is
  v_temp_dm   varchar2(200);
  v_temp_lbdm varchar2(200);

  /***********************************************************
  ????????fun_get_app_option
  ??????lqw
  ??????2014-03-21
  ??????????????????????app_option??????????????????????????????

  **********************************************************/

begin

  v_temp_lbdm := upper(v_lbdm);

  select t.dm
    into v_temp_dm
    from app_option t
   where t.lbdm = v_temp_lbdm
     and t.dm = v_dm;

  if v_dm <> v_temp_dm or v_dm is null then
    return - 1;
  else
    return v_dm;
  end if;

exception
  when others then
    return - 1;

end fun_get_app_option;

/
