CREATE procedure pr_hs_log_write(p_i_pr_name    in varchar2,
                                         p_i_rq         in varchar2,
                                         p_i_begin_time in varchar2,
                                         p_i_end_time   in varchar2,
                                         p_i_deal_flag  in varchar2,
                                         p_i_step_no    in varchar2,
                                         p_i_err_code   in varchar2,
                                         p_i_err_text   in varchar2,
                                         p_i_v_sql      in varchar2) is
  v_sql      varchar2(8000);
  v_err_code log_record.err_code%type;
  v_err_text log_record.err_text%type;
  /******************************************************************************
    名称： pr_log_write
    作者： lqw
    创建时间： 20130718
    更新时间：
    描述： 记录报错日志

    修改人:
    修改时间：
    修改内容:
  *******************************************************************************/

begin

  if p_i_deal_flag = '0' then

    v_sql := ' insert into log_record(pr_name, rq, begin_time, end_time, deal_flag, step_no, err_code, err_text, v_sql, id) values (:1, :2, :3, :4, :5, :6, :7, :8, :9, seq_log_record.nextval) ';

    execute immediate v_sql
      using p_i_pr_name, p_i_rq, p_i_begin_time, p_i_end_time, p_i_deal_flag, p_i_step_no, p_i_err_code, p_i_err_text, p_i_v_sql;

  end if;

  commit;

exception
  when others then
    rollback;

    v_err_code := sqlcode;
    v_err_text := substr(sqlerrm, 1, 500);
    dbms_output.put_line(v_err_code || ':' || v_err_text);

    raise;

end pr_hs_log_write;

/
