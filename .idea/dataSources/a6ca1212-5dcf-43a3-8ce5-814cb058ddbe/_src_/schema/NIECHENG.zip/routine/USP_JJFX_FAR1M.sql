CREATE procedure usp_jjfx_far1m(argym in varchar2)
is
i number :=0;
  /*
    argym 格式 YYYY-MM
  */
  begin

    --删除FA_R1_M
  delete from FA_R1_M where tjrq=argym;
  commit;

    --汇总入FA_R1_M
  i:=0;
  for c_row in
  (
  select
  tt.tjrq,tt.tcqdm,tt.yllb,tt.jzlx,tt.jgdm,nvl(y.jglx,'0') jglx,nvl(y.jgdj,'0') jgdj,tt.ddm,tt.ddl,tt.dxl
  ,tt.cblb,tt.cbdl,tt.ryzt,tt.hzxb,tt.hznld
  ,tt.r001,tt.r002,tt.r003,tt.r004,tt.r005,tt.r006,tt.r007,tt.r008,tt.r009,tt.r010
  ,tt.r011,tt.r012,tt.r013,tt.r014,tt.r015,tt.r016,tt.r017,tt.r018,tt.r019,tt.r020
  ,tt.r021,tt.r022,tt.r023,tt.r024,tt.r025,tt.r026,tt.r027,tt.r028,tt.r029,tt.r030
  ,tt.r031,tt.r032,tt.r033,tt.r034,tt.r035,tt.r036,tt.r037,tt.r038,tt.r039,tt.r040
  ,tt.r041,tt.r042,tt.r043,tt.r044,tt.r045,tt.r046,tt.r047,tt.r048,tt.r049,tt.r050
  from
  (
  select
  argym tjrq,nvl(tcqdm,'0') tcqdm,nvl(yllb,'0') yllb,nvl(jzlx,'0') jzlx,jgid jgdm
  ,nvl(ddm,'0') ddm,nvl(ddm,'0') ddl,nvl(ddm,'0') dxl
  ,nvl(rylb,'0') cblb,nvl(rylb,'0') cbdl,nvl(rylb,'0') ryzt,'0' hzxb,0 hznld
  ,nvl(sum(tczf),0)+nvl(sum(gbzf),0)+nvl(sum(qbzf),0)+nvl(sum(zhzf),0)+nvl(sum(gbzhzf),0)+nvl(sum(qbzhzf),0) r001
  ,nvl(sum(tczf),0)+nvl(sum(gbzf),0)+nvl(sum(qbzf),0) r002
  ,nvl(sum(zhzf),0)+nvl(sum(gbzhzf),0)+nvl(sum(qbzhzf),0) r003
  ,nvl(sum(xjzf),0) r004,nvl(sum(zlje),0) r005,nvl(sum(zfje),0) r006
  ,nvl(sum(zfuje),0) r007,nvl(sum(tczf),0) r008,nvl(sum(gbzf),0) r009
  ,nvl(sum(qbzf),0) r010,nvl(sum(zhzf),0) r011,nvl(sum(gbzhzf),0) r012
  ,nvl(sum(qbzhzf),0) r013,nvl(sum(zfy),0) r014,0 r015,count(distinct ghdjid) r016
  ,0 r017,count(distinct grid) r018,sum(abs(ceil(yscyrq-ysryrq))) as r019,0 as r020
  ,0 as r021,0 as r022,0 as r023,0 as r024,0 as r025
  ,0 as r026,0 as r027,0 as r028,0 as r029,0 as r030
  ,0 as r031,0 as r032,0 as r033,0 as r034,0 as r035
  ,0 as r036,0 as r037,0 as r038,0 as r039,0 as r040
  ,0 as r041,0 as r042,0 as r043,0 as r044,0 as r045
  ,0 as r046,0 as r047,0 as r048,0 as r049,0 as r050
  from JJFX_JSMX_TMP
  group by nvl(tcqdm,'0'),nvl(yllb,'0'),nvl(jzlx,'0'),jgid,nvl(ddm,'0'),nvl(rylb,'0')
  ) tt
  left join ck01_yljg y
  on tt.jgdm=y.id
  )
  loop
  insert into FA_R1_M
  (tjrq,tcqdm,yllb,jzlx,jgdm,jglx,jgdj,ddm,ddl,dxl,cblb,cbdl,ryzt,hzxb,hznld
  ,r001,r002,r003,r004,r005,r006,r007,r008,r009,r010
  ,r011,r012,r013,r014,r015,r016,r017,r018,r019,r020
  ,r021,r022,r023,r024,r025,r026,r027,r028,r029,r030
  ,r031,r032,r033,r034,r035,r036,r037,r038,r039,r040
  ,r041,r042,r043,r044,r045,r046,r047,r048,r049,r050)
  values
  (c_row.tjrq,c_row.tcqdm,c_row.yllb,c_row.jzlx,c_row.jgdm
  ,c_row.jglx,c_row.jgdj,c_row.ddm,c_row.ddl,c_row.dxl
  ,c_row.cblb,c_row.cbdl,c_row.ryzt,c_row.hzxb,c_row.hznld
  ,c_row.r001,c_row.r002,c_row.r003,c_row.r004,c_row.r005
  ,c_row.r006,c_row.r007,c_row.r008,c_row.r009,c_row.r010
  ,c_row.r011,c_row.r012,c_row.r013,c_row.r014,c_row.r015
  ,c_row.r016,c_row.r017,c_row.r018,c_row.r019,c_row.r020
  ,c_row.r021,c_row.r022,c_row.r023,c_row.r024,c_row.r025
  ,c_row.r026,c_row.r027,c_row.r028,c_row.r029,c_row.r030
  ,c_row.r031,c_row.r032,c_row.r033,c_row.r034,c_row.r035
  ,c_row.r036,c_row.r037,c_row.r038,c_row.r039,c_row.r040
  ,c_row.r041,c_row.r042,c_row.r043,c_row.r044,c_row.r045
  ,c_row.r046,c_row.r047,c_row.r048,c_row.r049,c_row.r050);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --更新药品费用
  i:=0;
  for u_row in
  (
  select
  argym tjrq,nvl(tcqdm,'0') tcqdm,nvl(yllb,'0') yllb,nvl(jzlx,'0') jzlx,jgid jgdm
  ,nvl(ddm,'0') ddm,nvl(ddm,'0') ddl,nvl(ddm,'0') dxl
  ,nvl(rylb,'0') cblb,nvl(rylb,'0') cbdl,nvl(rylb,'0') ryzt,'0' hzxb,0 hznld
  ,sum(je) r015
  from JJFX_CFMX_TMP
  where sflb in (select dm from app_option where lbdm='SFLB' and upper(cs)='YP')
  group by nvl(tcqdm,'0'),nvl(yllb,'0'),nvl(jzlx,'0'),jgid,nvl(ddm,'0'),nvl(rylb,'0')
  )
  loop
  update FA_R1_M m set m.r015=u_row.r015
  where m.tjrq=u_row.tjrq
  and m.tcqdm=u_row.tcqdm and m.yllb=u_row.yllb and m.jzlx=u_row.jzlx
  and m.jgdm=u_row.jgdm and m.ddm=u_row.ddm and m.ddl=u_row.ddl
  and m.dxl=u_row.dxl and m.cblb=u_row.cblb and m.cbdl=u_row.cbdl
  and m.ryzt=u_row.ryzt and m.hzxb=u_row.hzxb and m.hznld=u_row.hznld;
    if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  end;

/
