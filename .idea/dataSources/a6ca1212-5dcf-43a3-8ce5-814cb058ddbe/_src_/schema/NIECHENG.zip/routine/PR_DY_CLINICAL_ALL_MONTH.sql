CREATE procedure pr_dy_clinical_all_month is

  /*************************************************************
  名称：pr_gn_clinical_day_all
  作者：lqw
  时间：2014-01-07
  --参数：v_rq  varchar2  'yyyy-mm'
  描述：临床规则调用
  *************************************************************/

min_data_status_info_id   NUMBER ;

begin

  select max(t.id) into min_data_status_info_id from data_status_info t
  where clinical_summary_flag = '0' and t.clinical_analysis_flag =1;
  for c_row in (SELECT distinct gzdm  FROM mtr_clinical_result)
    loop
       dbms_output.put_line('开始汇总rid:'||c_row.gzdm);
       pr_gn_clinical_new_month(c_row.gzdm);
       dbms_output.put_line('完成汇总rid:'||c_row.gzdm);
    end loop;


 /* UPDATE data_status t
   set t.clinical_summary_flag = '1'
     where t.id in( select pid from data_status_info where id = min_data_status_info_id);*/
  UPDATE data_status_info t
   set t.clinical_summary_flag = '1'
     where t.id = min_data_status_info_id;
   commit;
  ------------------------------------------------------------------------

exception
  when others then
    rollback;

    raise;

end pr_dy_clinical_all_month;

/
