CREATE FUNCTION encrypt (inpass in varchar2)
RETURN varchar2 IS
string_in varchar2(78);
string_out varchar2(39);
offset number(2);
outpass varchar2(30);
BEGIN
offset :=to_number(to_char(sysdate,'ss'))mod 39;
string_in :='YN8K1JOZVURB3MDETS5GPL27AXWIHQ94C6F0#$_';
string_out :='_$#ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
outpass :=substr(string_in,offset,1);
string_in :=string_in||string_in;
string_in :=substr(string_in,offset,39);
outpass :=outpass||translate(upper(inpass),
string_in,string_out);
return outpass;
END;

/
