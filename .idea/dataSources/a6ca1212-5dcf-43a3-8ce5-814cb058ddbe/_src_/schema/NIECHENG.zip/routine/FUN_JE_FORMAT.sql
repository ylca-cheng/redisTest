CREATE function fun_je_format(n_je in number) return varchar2 is
  n_temp_je_1 varchar2(30);
  n_temp_je_2 varchar2(30);

  /***********************************************************
  ????????fun_je_format
  ??????lqw
  ??????2014-05-08
  ?????????????? (number)??????????????(9,999,999.99)(varchar2)

  **********************************************************/

begin

  n_temp_je_1 := ltrim(to_char(n_je, '9,999,999,999,999,999,999.99'));

  n_temp_je_2 := ltrim(to_char(n_je, '0.99'));

  if n_je is not null then

    if n_je >= 1 or n_je <= -1 then

      return n_temp_je_1;

    elsif n_je > -1 and n_je < 1 then

      return n_temp_je_2;

    end if;

  else

    return null;

  end if;

exception
  when others then
    return null;

end fun_je_format;

/
