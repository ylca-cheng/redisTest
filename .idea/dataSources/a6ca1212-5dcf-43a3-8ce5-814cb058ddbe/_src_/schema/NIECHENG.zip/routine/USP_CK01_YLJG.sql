CREATE procedure USP_CK01_YLJG is


begin


  insert into ck01_yljg
    (id, jgdm, jgmc, jgdj, jglb, tcqdm, jglx , yxbz, tjbz)
    select distinct jgid, jgdm, jgmc, jgdj, jglb, tcqdm, '1','1','1' from ck10_ghdj
    where jgid is not null and jgid not in (select id from ck01_yljg);


  commit;

end;

/
