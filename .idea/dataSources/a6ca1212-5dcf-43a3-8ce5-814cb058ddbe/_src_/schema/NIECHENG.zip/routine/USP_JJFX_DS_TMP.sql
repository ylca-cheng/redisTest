CREATE procedure usp_jjfx_ds_tmp(argym in varchar2)
is
i number :=0;
  /*
    argym 格式 YYYY-MM
  */
  begin
    --清除数据源临时表
    execute immediate 'truncate table JJFX_JSMX_TMP';
  --清除数据源临时表
    execute immediate 'truncate table JJFX_CFMX_TMP';

    --删除索引
  execute immediate 'DROP INDEX i_jjsmxtmp_ghdjid';
  execute immediate 'DROP INDEX i_jjsmxtmp_ddm';
  execute immediate 'DROP INDEX i_jjsmxtmp_yscyrq';
  execute immediate 'DROP INDEX i_jjsmxtmp_jzlx';
  execute immediate 'DROP INDEX i_jjsmxtmp_jgid';
  execute immediate 'DROP INDEX i_jjsmxtmp_grid';
  execute immediate 'DROP INDEX i_jjsmxtmp_tcqdm';

    --删除索引
  execute immediate 'DROP INDEX i_jcfmxtmp_ghdjid';
  execute immediate 'DROP INDEX i_jcfmxtmp_ddm';
  execute immediate 'DROP INDEX i_jcfmxtmp_yscyrq';
  execute immediate 'DROP INDEX i_jcfmxtmp_jzlx';
  execute immediate 'DROP INDEX i_jcfmxtmp_jgid';
  execute immediate 'DROP INDEX i_jcfmxtmp_grid';
  execute immediate 'DROP INDEX i_jcfmxtmp_tcqdm';
  execute immediate 'DROP INDEX i_jcfmxtmp_xmdm';

  --初始化JJFX_JSMX_TMP数据
  i:=0;
  for c_row in
  (
  select ghdj.id ghdjid,ghdj.tcqdm,ghdj.jgid,ghdj.grid,ghdj.zjhm,ghdj.hznl,ghdj.rylb
  ,ghdj.ryzt,ghdj.grsf,ghdj.cblb,ghdj.dwid,ghdj.jzlx,ghdj.yllb,ghdj.cyzddm
  ,case when regexp_like(cyzddm,'^[A-Za-z]{1}\d{2}\.\d{1}.*') then substr(ghdj.cyzddm,0,5) else '' end ddm
  ,ghdj.ryzddm,ghdj.ksid,ghdj.ksdm,ghdj.ysid,ghdj.ysdm,ghdj.ch,ghdj.zyts
  ,ghdj.jylx,ghdj.bxbz,to_char(ghdj.ryrq,'YYYY-MM-DD') ryrq,to_char(ghdj.cyrq,'YYYY-MM-DD') cyrq
  ,ghdj.ryrq ysryrq,ghdj.cyrq yscyrq,jsmx.id jsmxid,to_char(jsmx.jsrq,'YYYY-MM-DD') jsrq
  ,jsmx.jsrq ysjsrq,jsmx.zfy,jsmx.xjzf,jsmx.zlje,jsmx.zfje,jsmx.zfuje
  ,jsmx.tczf,jsmx.gbzf,jsmx.qbzf,jsmx.qtzf,jsmx.zhzf,jsmx.gbzhzf,jsmx.qbzhzf,jsmx.qtzhzf
  from (select * from ck10_ghdj
  where cyrq between to_date(argym||'-01 00:00:00','yyyy-mm-dd hh24:mi:ss')
  and last_day(to_date(argym||'-01 23:59:59','yyyy-mm-dd hh24:mi:ss'))) ghdj
  join ck10_jsmx jsmx
  on ghdj.id=jsmx.ghdjid
  )
  loop
  insert into JJFX_JSMX_TMP
  (ghdjid,tcqdm,jgid,grid,zjhm,hznl,rylb,ryzt,grsf,cblb,dwid,jzlx,yllb,cyzddm,ddm,ryzddm
  ,ksid,ksdm,ysid,ysdm,ch,zyts,jylx,bxbz,ryrq,cyrq,ysryrq,yscyrq,jsmxid,jsrq,ysjsrq
  ,zfy,xjzf,zlje,zfje,zfuje,tczf,gbzf,qbzf,qtzf,zhzf,gbzhzf,qbzhzf,qtzhzf)
  values
  (c_row.ghdjid,c_row.tcqdm,c_row.jgid,c_row.grid,c_row.zjhm,c_row.hznl,c_row.rylb
  ,c_row.ryzt,c_row.grsf,c_row.cblb,c_row.dwid,c_row.jzlx,c_row.yllb,c_row.cyzddm,c_row.ddm,c_row.ryzddm
  ,c_row.ksid,c_row.ksdm,c_row.ysid,c_row.ysdm,c_row.ch,c_row.zyts,c_row.jylx,c_row.bxbz
  ,c_row.ryrq,c_row.cyrq,c_row.ysryrq,c_row.yscyrq,c_row.jsmxid,c_row.jsrq,c_row.ysjsrq
  ,c_row.zfy,c_row.xjzf,c_row.zlje,c_row.zfje,c_row.zfuje,c_row.tczf,c_row.gbzf,c_row.qbzf
  ,c_row.qtzf,c_row.zhzf,c_row.gbzhzf,c_row.qbzhzf,c_row.qtzhzf);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --初始化JJFX_CFMX_TMP数据
  i:=0;
    for c_row in
  (
  select cfmx.id cfmxid,ghdj.id ghdjid,ghdj.tcqdm,ghdj.jgid,ghdj.grid,ghdj.zjhm,ghdj.hznl
  ,ghdj.rylb,ghdj.ryzt,ghdj.grsf,ghdj.cblb,ghdj.dwid,ghdj.jzlx,ghdj.yllb,ghdj.cyzddm
  ,case when regexp_like(cyzddm,'^[A-Za-z]{1}\d{2}\.\d{1}.*') then substr(ghdj.cyzddm,0,5) else '' end ddm
  ,ghdj.ryzddm
  ,ghdj.ksid,ghdj.ksdm,ghdj.ysid,ghdj.ysdm,ghdj.ch,ghdj.zyts,ghdj.jylx,ghdj.bxbz
  ,to_char(ghdj.ryrq,'YYYY-MM-DD') ryrq,to_char(ghdj.cyrq,'YYYY-MM-DD') cyrq,to_char(cfmx.cfrq,'YYYY-MM-DD') cfrq
  ,ghdj.ryrq ysryrq,ghdj.cyrq yscyrq,cfmx.cfrq yscfrq
  ,cfmx.xmdm,cfmx.ypdj xmdj,cfmx.xmlb,cfmx.sflb,cfmx.sl,cfmx.je,cfmx.zlje,cfmx.zfje,cfmx.zfbl
  from (select * from ck10_ghdj
  where cyrq between to_date(argym||'-01 00:00:00','yyyy-mm-dd hh24:mi:ss')
  and last_day(to_date(argym||'-01 23:59:59','yyyy-mm-dd hh24:mi:ss'))) ghdj
  join ck10_cfmx cfmx
  on ghdj.id=cfmx.ghdjid
  )
  loop
  insert into JJFX_CFMX_TMP
  (cfmxid,ghdjid,tcqdm,jgid,grid,zjhm,hznl,rylb,ryzt,grsf,cblb,dwid,jzlx,yllb,cyzddm,ddm,ryzddm
  ,ksid,ksdm,ysid,ysdm,ch,zyts,jylx,bxbz,ryrq,cyrq,cfrq,ysryrq,yscyrq,yscfrq
  ,xmdm,xmdj,xmlb,sflb,sl,je,zlje,zfje,zfbl)
  values
  (c_row.cfmxid,c_row.ghdjid,c_row.tcqdm,c_row.jgid,c_row.grid,c_row.zjhm,c_row.hznl,c_row.rylb
  ,c_row.ryzt,c_row.grsf,c_row.cblb,c_row.dwid,c_row.jzlx,c_row.yllb,c_row.cyzddm,c_row.ddm,c_row.ryzddm
  ,c_row.ksid,c_row.ksdm,c_row.ysid,c_row.ysdm,c_row.ch,c_row.zyts,c_row.jylx,c_row.bxbz
  ,c_row.ryrq,c_row.cyrq,c_row.cfrq,c_row.ysryrq,c_row.yscyrq,c_row.yscfrq,c_row.xmdm,c_row.xmdj
  ,c_row.xmlb,c_row.sflb,c_row.sl,c_row.je,c_row.zlje,c_row.zfje,c_row.zfbl);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --创建索引
  execute immediate 'CREATE INDEX i_jjsmxtmp_ghdjid ON JJFX_JSMX_TMP (ghdjid)';
  execute immediate 'CREATE INDEX i_jjsmxtmp_ddm ON JJFX_JSMX_TMP (ddm)';
  execute immediate 'CREATE INDEX i_jjsmxtmp_yscyrq ON JJFX_JSMX_TMP (yscyrq)';
  execute immediate 'CREATE INDEX i_jjsmxtmp_jzlx ON JJFX_JSMX_TMP (jzlx)';
  execute immediate 'CREATE INDEX i_jjsmxtmp_jgid ON JJFX_JSMX_TMP (jgid)';
  execute immediate 'CREATE INDEX i_jjsmxtmp_grid ON JJFX_JSMX_TMP (grid)';
  execute immediate 'CREATE INDEX i_jjsmxtmp_tcqdm ON JJFX_JSMX_TMP (tcqdm)';

  --创建索引
  execute immediate 'CREATE INDEX i_jcfmxtmp_ghdjid ON JJFX_CFMX_TMP (ghdjid)';
  execute immediate 'CREATE INDEX i_jcfmxtmp_ddm ON JJFX_CFMX_TMP (ddm)';
  execute immediate 'CREATE INDEX i_jcfmxtmp_yscyrq ON JJFX_CFMX_TMP (yscyrq)';
  execute immediate 'CREATE INDEX i_jcfmxtmp_jzlx ON JJFX_CFMX_TMP (jzlx)';
  execute immediate 'CREATE INDEX i_jcfmxtmp_jgid ON JJFX_CFMX_TMP (jgid)';
  execute immediate 'CREATE INDEX i_jcfmxtmp_grid ON JJFX_CFMX_TMP (grid)';
  execute immediate 'CREATE INDEX i_jcfmxtmp_tcqdm ON JJFX_CFMX_TMP (tcqdm)';
  execute immediate 'CREATE INDEX i_jcfmxtmp_xmdm ON JJFX_CFMX_TMP (xmdm)';

  end;

/
