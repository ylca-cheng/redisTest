CREATE procedure USP_DM_FXDBZ (BDAY in varchar2,EDAY in varchar2)
is
  I_DEX NUMBER := 1;

  begin

 	for E in (
 		select ym,jzlx,jgid,ddm
		,sum(r001) r001,sum(r002) r002,sum(r003) r003,sum(r004) r004,sum(r005) r005
		,sum(r006) r006,sum(r007) r007,sum(r008) r008,sum(r009) r009,sum(r010) r010
		from
		--1
		(select to_char(cyrq,'YYYY-MM') ym,jzlx,jgid,substr(cyzddm,0,5) ddm
		,count(id) R001
		,count(distinct grid) R002
		,sum(zyts) R003
		,sum(zje) R004
		,0 R005
		,0 R006,0 R007,0 R008,0 R009,0 R010
		from ck10_ghdj
		where 1=1
		and jzlx=2
		and cyrq between to_date(BDAY||' 00:00:00','yyyy-mm-dd hh24:mi:ss')
		and to_date(EDAY||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
		and length(cyzddm)>=3
		and regexp_like(cyzddm,'^[A-Za-z]{1}\d{2}\.\d{1}.*')
		group by to_char(cyrq,'YYYY-MM'),jzlx,jgid,substr(cyzddm,0,5)
		union all
		--2
		select ym,jzlx,jgid,ddm
		,0 R001,0 R002,0 R003,0 R004,0 R005
		,sum(r006) R006
		,sum(decode(xgd, '0', r006,null)) as R007
		,sum(decode(xgd, '1', r006,null)) as R008
		,sum(decode(xgd, '2', r006,null)) as R009
		,sum(decode(xgd, null, r006,null)) as R010
		from
		(select to_char(g.cyrq,'YYYY-MM') ym,g.jzlx,g.jgid,substr(g.cyzddm,0,5) ddm,c.xgd
		,sum(c.je) R006
		 from
		(select * from ck10_ghdj
		where 1=1
		and jzlx=2
		and cyrq between to_date(BDAY||' 00:00:00','yyyy-mm-dd hh24:mi:ss')
		and to_date(EDAY||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
		and length(cyzddm)>=3
		and regexp_like(cyzddm,'^[A-Za-z]{1}\d{2}\.\d{1}.*')) g,ck10_cfmx c
		where g.id=c.ghdjid
		group by to_char(g.cyrq,'YYYY-MM'),g.jzlx,g.jgid,substr(g.cyzddm,0,5),c.xgd) t
		group by ym,jzlx,jgid,ddm) b
		group by ym,jzlx,jgid,ddm
		)
  	LOOP
		INSERT INTO FX_DBZ (YM,JZLX,JGID,DDM,R001,R002,R003,R004,R005,R006,R007,R008,R009,R010)
		VALUES(E.YM,E.JZLX,E.JGID,E.DDM,E.R001,E.R002,E.R003,E.R004,E.R005,E.R006,E.R007,E.R008,E.R009,E.R010);

		IF I_DEX>1000 THEN
   			COMMIT;
    		I_DEX:=I_DEX-1000;
   		END IF;
   			I_DEX:=I_DEX+1;
  	END LOOP;
  	COMMIT;
  end;

/
