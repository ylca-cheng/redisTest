CREATE procedure PR_GN_CLINICAL_SUMMARY(vid in number,bg_ghdj_seq  in number,ed_ghdj_seq in number)
is
/*
*
*@作者:xuchuanhou
*@功能：上海大检查汇总存储过程
*@日期：20150909
*/
begin

  --执行时先删除mtr_header_new、mtr_mapping_new表中需要重跑的数据
  delete from mtr_header_new  where gzdm = vid
  and id in
 (select hid from mtr_mapping_new p ,
                   mtr_clinical_result r,
                   ck10_ghdj g
              where r.id=p.mcrid
              and r.ghdjid=g.id
              and r.gzdm=vid
              and  g.seq_id >=bg_ghdj_seq
              and g.seq_id <ed_ghdj_seq
          );

  delete from mtr_mapping_new m where  not exists
   (select id from mtr_header_new h where h.id=m.hid);
commit;

-- -- 上海大检查新版汇总存储过程

if( vid=7 or vid=8 or vid=57 or vid=58 or vid=1150 or vid=109 ) then
   begin

    --医生维度
      insert into mtr_header_new(rq,gzdm,gzmc,jgdm,jgmc,sjje,wgms,jcsl,dxdm,dxmc,dxlx,pcdm)
        SELECT
        to_char(g.cyrq,'yyyymm') AS RQ,
        T.gzdm AS gzdm,c.MC GZMC,
         T.JGID,T.Jgmc,
        SUM(T.JE)*count(DISTINCT T.ID)/count(T.ID) AS SJJE, --mtr_clinical_result有重复
        '疑似违反《 '||c.MC||' 》，涉及 ' ||count(distinct t.id)|| ' 次。' as WGMS,
         count(distinct t.id ) as JCSL,
         T.ysid as dxdm ,T.ysmc as dxmc,
          '1' as dxlx,T.pcdm
        from  MTR_CLINICAL_RESULT T
        left join ck10_ghdj g on g.id = T.ghdjid
        left join mt_rule c on c.id = T.gzdm
        WHERE
        T.GZDM = vid
        and G.Seq_Id <ed_ghdj_seq
        and g.seq_id >=bg_ghdj_seq
        and t.ysid is not null
        AND T.FLAG = 0
        GROUP BY T.gzdm,c.MC,to_char(g.cyrq,'yyyymm'),t.ysid,t.ysmc,T.Jgid,T.Jgmc,T.pcdm;

      -- mapping
      insert into mtr_mapping_new(hid,mcrid)
      select H.id,M.id  from mtr_header_new H,
           mtr_clinical_result M,
           ck10_ghdj g
       where
            H.Dxdm=M.Ysid
            and M.Jgid=H.Jgdm
            and H.pcdm=M.pcdm
            and H.Gzdm=M.Gzdm
            and G.Seq_Id <ed_ghdj_seq
             and g.seq_id >=bg_ghdj_seq
            and  H.Dxlx=1
            and g.id=M.Ghdjid
            and H.Rq=to_char(g.cyrq,'yyyymm');

            commit;

   end;


ELSIF ( vid=112 or vid=118  or vid=121 or vid=125)
 then
   begin

--参保人维度
    insert into mtr_header_new(rq,gzdm,gzmc,jgdm,jgmc,sjje,wgms,jcsl,dxdm,dxmc,dxlx,pcdm)
      SELECT
      to_char(g.cyrq,'yyyymm') AS RQ,
      T.gzdm AS gzdm,c.MC GZMC,
       T.JGID,T.Jgmc,
      SUM(T.JE)*count(DISTINCT T.ID)/count(T.ID) AS SJJE, --mtr_clinical_result有重复
      '疑似违反《 '||c.MC||' 》，涉及 ' ||count(distinct t.id)|| ' 次。' as WGMS,
       count(distinct t.id ) as JCSL,
       T.hzid as dxdm ,T.hzxm as dxmc,
        '2' as dxlx,T.pcdm
      from  MTR_CLINICAL_RESULT T
      left join ck10_ghdj g on g.id = T.ghdjid
      left join mt_rule c on c.id = T.gzdm
      WHERE
      T.GZDM = vid
      and t.hzid is not null
      and G.Seq_Id <ed_ghdj_seq
      and g.seq_id >=bg_ghdj_seq
      AND T.FLAG = 0
      GROUP BY T.gzdm,c.MC,to_char(g.cyrq,'yyyymm'),t.hzid,t.hzxm,T.Jgid,T.Jgmc,T.pcdm;

-- mapping
    insert into mtr_mapping_new(hid,mcrid)
    select H.id,M.id  from mtr_header_new H,
         mtr_clinical_result M,
         ck10_ghdj g  where
          H.Dxdm=M.hzid
          and H.pcdm=M.pcdm
          and M.Jgid=H.Jgdm
          and H.Gzdm=M.Gzdm
      and G.Seq_Id <ed_ghdj_seq
       and g.seq_id >=bg_ghdj_seq
          and  H.Dxlx=2
          and g.id=M.Ghdjid
          and H.Rq=to_char(g.cyrq,'yyyymm');
   end;

   commit;

elsif ( vid=37 or vid=59 or vid=60 or vid=65 or vid=114 or vid=115 or vid=568 )
then
--项目维度
-- header_new
begin
   insert into mtr_header_new(rq,gzdm,gzmc,jgdm,jgmc,sjje,wgms,jcsl,dxdm,dxmc,dxlx,pcdm,yydj)
    SELECT
  to_char(g.cyrq,'yyyymm') AS RQ,
  T.gzdm AS gzdm,c.MC GZMC,
   T.JGID,T.Jgmc,
  SUM(T.JE)*count(DISTINCT T.ID)/count(T.ID) AS SJJE, --mtr_clinical_result有重复
  '疑似违反《 '||c.MC||' 》，涉及 ' ||count(distinct t.id)|| ' 次。' as WGMS,
   count(distinct t.id ) as JCSL,
   y.xmdm as dxdm ,y.xmmc as dxmc,
    '3' as dxlx,T.pcdm,max(CF.dj) as yydj
  from mtr_clinical_ydnr y, mtr_clinical_result T ,ck10_ghdj g  ,mt_rule c  ,ck10_cfmx CF
   where
    y.ydlx=2  and T.FLAG = 0 and T.GZDM  = vid
    and G.Seq_Id <ed_ghdj_seq  and g.seq_id >=bg_ghdj_seq
    and y.xmdm is not null and  Y.Mcrid=T.Id    and  g.id = T.ghdjid
    and c.id = T.gzdm and CF.id = y.YDID
  GROUP BY T.gzdm,c.MC,to_char(g.cyrq,'yyyymm'),y.xmdm,y.xmmc,T.Jgid,T.Jgmc,T.pcdm;


--mapping
insert into mtr_mapping_new(hid,mcrid)
select distinct H.id,M.id
   from mtr_header_new H,
     mtr_clinical_result M,
     mtr_clinical_ydnr y,
     ck10_ghdj g
     where
     H.Dxdm=y.xmdm
     and y.mcrid=M.id
     and y.ydlx=2
     and M.Jgid=H.Jgdm
     and h.pcdm=M.pcdm
     and g.id=M.Ghdjid
     and H.Gzdm=M.Gzdm
     and G.Seq_Id <ed_ghdj_seq
     and g.seq_id >=bg_ghdj_seq
     and  H.Dxlx=3
     and H.Rq=to_char(g.cyrq,'yyyymm');


end;

commit;

end if;

end PR_GN_CLINICAL_SUMMARY;
/
