CREATE procedure usp_jjfx_farmxm(argym in varchar2)
is
i number :=0;
  /*
    argym 格式 YYYY-MM
  */
  begin

  --删除FA_R2_M
  delete from FA_R2_M where tjrq=argym;
  commit;
  --删除FA_R3_M
  delete from FA_R3_M where tjrq=argym;
  commit;
  --删除FA_R4_M
  delete from FA_R4_M where tjrq=argym;
  commit;

  --汇总入FA_R2_M,FA_R3_M,FA_R4_M
  for c_row in
  (
  select
  t.tjrq,t.tcqdm,t.yllb,t.jzlx,t.jgdm,nvl(y.jglx,'0') jglx,nvl(y.jgdj,'0') jgdj,t.ddm,t.ddl,t.dxl
  ,t.cblb,t.cbdl,t.ryzt,t.hzxb,t.hznld,t.xmdm,nvl(v.xmlb,'0') xmlb,nvl(v.xmdj,'0') xmdj,nvl(v.sflb,'0') sflb
  ,t.r001,t.r002,t.r003,t.r004,t.r005,t.r006,t.r007,t.r008,t.r009,t.r010
  from
  (
  select
  argym tjrq,nvl(tcqdm,'0') tcqdm,nvl(yllb,'0') yllb,nvl(jzlx,'0') jzlx,jgid jgdm
  ,nvl(ddm,'0') ddm,nvl(ddm,'0') ddl,nvl(ddm,'0') dxl
  ,nvl(rylb,'0') cblb,nvl(rylb,'0') cbdl,nvl(rylb,'0') ryzt,'0' hzxb,0 hznld,xmdm
  ,nvl(sum(je),0) r001,nvl(sum(zlje),0) r002,nvl(sum(zfje),0) r003,0 r004,nvl(sum(sl),0) r005
  ,count(*) r006,count(distinct ghdjid) r007,sum(nvl(zyts,1)) r008,0 r009,0 r010
  from JJFX_CFMX_TMP
  group by nvl(tcqdm,'0'),nvl(yllb,'0'),nvl(jzlx,'0'),jgid,nvl(ddm,'0'),nvl(rylb,'0'),xmdm
  ) t
  left join ck01_yljg y
  on t.jgdm=y.id
  left join v_sml v
  on t.xmdm=v.dm
  )
  loop

  if(c_row.xmlb='1')
  then
  insert into FA_R2_M
  (tjrq,tcqdm,yllb,jzlx,jgdm,jglx,jgdj,ddm,ddl,dxl
  ,cblb,cbdl,ryzt,hzxb,hznld,xmdm,xmdj,sflb
  ,r001,r002,r003,r004,r005,r006,r007,r008,r009,r010)
  values
  (c_row.tjrq,c_row.tcqdm,c_row.yllb,c_row.jzlx,c_row.jgdm
  ,c_row.jglx,c_row.jgdj,c_row.ddm,c_row.ddl,c_row.dxl
  ,c_row.cblb,c_row.cbdl,c_row.ryzt,c_row.hzxb,c_row.hznld
  ,c_row.xmdm,c_row.xmdj,c_row.sflb
  ,c_row.r001,c_row.r002,c_row.r003,c_row.r004,c_row.r005
  ,c_row.r006,c_row.r007,c_row.r008,c_row.r009,c_row.r010);
  end if;
  if(c_row.xmlb='2')
  then
  insert into FA_R4_M
  (tjrq,tcqdm,yllb,jzlx,jgdm,jglx,jgdj,ddm,ddl,dxl
  ,cblb,cbdl,ryzt,hzxb,hznld,xmdm,xmdj,sflb
  ,r001,r002,r003,r004,r005,r006,r007,r008,r009,r010)
  values
  (c_row.tjrq,c_row.tcqdm,c_row.yllb,c_row.jzlx,c_row.jgdm
  ,c_row.jglx,c_row.jgdj,c_row.ddm,c_row.ddl,c_row.dxl
  ,c_row.cblb,c_row.cbdl,c_row.ryzt,c_row.hzxb,c_row.hznld
  ,c_row.xmdm,c_row.xmdj,c_row.sflb
  ,c_row.r001,c_row.r002,c_row.r003,c_row.r004,c_row.r005
  ,c_row.r006,c_row.r007,c_row.r008,c_row.r009,c_row.r010);
  end if;
  if(c_row.xmlb='3')
  then
  insert into FA_R3_M
  (tjrq,tcqdm,yllb,jzlx,jgdm,jglx,jgdj,ddm,ddl,dxl
  ,cblb,cbdl,ryzt,hzxb,hznld,xmdm,xmdj,sflb
  ,r001,r002,r003,r004,r005,r006,r007,r008,r009,r010)
  values
  (c_row.tjrq,c_row.tcqdm,c_row.yllb,c_row.jzlx,c_row.jgdm
  ,c_row.jglx,c_row.jgdj,c_row.ddm,c_row.ddl,c_row.dxl
  ,c_row.cblb,c_row.cbdl,c_row.ryzt,c_row.hzxb,c_row.hznld
  ,c_row.xmdm,c_row.xmdj,c_row.sflb
  ,c_row.r001,c_row.r002,c_row.r003,c_row.r004,c_row.r005
  ,c_row.r006,c_row.r007,c_row.r008,c_row.r009,c_row.r010);
  end if;

  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;


  end;

/
