CREATE procedure pr_delete_header_mapping(v_id   in number,
                                                     v_rq   in varchar2,
                                                     v_pcdm in varchar2) is

  /******************************************************************************
    名称： pr_delete_header_mapping
    作者： lcj
    创建时间： 20140107
    更新时间：
    描述： 删除header、mapping表数据

    修改人:
    修改时间：
    修改内容:
  *******************************************************************************/

begin

  delete from mtr_mapping t
   where t.rid = v_id
     and t.rq like '' || v_rq || '%'
     and exists (select 1
            from mtr_header a
           where a.id = t.hid
             and a.pcdm = v_pcdm);
  commit;

  delete from mtr_header t
   where t.rid = v_id
     and t.rq like '' || v_rq || '%'
     and t.pcdm = v_pcdm;
  commit;

end pr_delete_header_mapping;

/
