CREATE procedure usp_jjfx_v1(argym in varchar2)
is
i number :=0;
  /*
    参数说明：argym 格式 YYYY-MM
  发布时间：2014-12-05
  基金分析入口
  执行示例：exec usp_jjfx_v1('2013-01');
  */
  begin
    /**
    清除并导入基金分析结算明细和处方明细临时表数据
    表：jjfx_jsmx_tmp，jjfx_cfmx_tmp
    */
    usp_jjfx_ds_tmp(argym);

    /**
    汇总并保存基金分析汇总结果(TJ_门诊住院)
    表：tj_mz,tj_zy,tj_mzxm,tj_zyxm
    */
    usp_jjfx_tj_mzzy(argym);

    /**
    汇总并保存患者排名TJHZ_PM01..PM06
    表：tjhz_pm01...tjhz_pm06
    */
    usp_jjfx_hzpm(argym);

    /**
    汇总并保存参保人/医疗机构筛查(门诊，住院，购药)
    表：tjhz_mz，tjhz_zy，tjhz_gy
    */
    usp_jjfx_tjhz(argym);

    /**
    汇总并保存基金分析首页数据
    表：fa_r1_m
    */
    usp_jjfx_far1m(argym);

    /**
    汇总并保存基金分析项目明细数据
    表：fa_r2_m，fa_r3_m，fa_r4_m
    */
    usp_jjfx_farmxm(argym);

    /**
    汇总并保存医师排名与分析内容(门诊住院)
    表：TJYS_RMZ，TJYS_YMZ，TJYS_YMZXM，TJYS_YZY，TJYS_YZYXM
    */
    usp_jjfx_tjys(argym);

  end;

/
