CREATE procedure pr_hs_update_header_xxsj(v_id in NUMBER
                                                     ,v_rq in VARCHAR2
                                                     ) is
  v_rule_mc   varchar2(200);
  v_rule_xsdx varchar2(200);

  /**********************************************************************
  名称：update_mtr_header_xxsj
  作者：lcj
  创建时间：20140219
  修改时间：
  描述：更新header表详细数据
  ***********************************************************************/

  max_data_status_id  NUMBER ;
  ed_ghdj_seq         NUMBER ;
  bg_ghdj_seq         NUMBER ;


BEGIN



  select mc, xsdx into v_rule_mc, v_rule_xsdx from mt_rule where id = v_id;
  commit;

  update mtr_header a
     set jg1 =
         ---20141103   xu.vj 根据陈昌得要统一JG1，和描述 将jg1改成jg2的值
         --(select count(*) from mtr_mapping where hid = a.id),
         ---20141112 xu.vj 完善经验性规则
         CASE WHEN a.rid <1000 OR a.rid >10000 THEN a.jg2
              ELSE    (select count(*) from mtr_mapping where hid = a.id)
         END
         ,
         jgdm = jgid,
         ysdm = ysid,
         jgmc = case nvl(jgid, 'null')
                  when 'null' then
                   '其它'
                  else

                   (select jgmc from ck01_yljg where id = a.jgid)
                end,
         hzdm =
         (select dm from ck01_cbry where id = a.hzid),
         zjhm =
         (select zjhm from ck01_cbry where id = a.hzid),
         hzmc =
         (case v_rule_xsdx
           when '参保人' then
            (select xm from ck01_cbry where id = a.hzid)
           when '机构' then
            (select jgmc from ck01_yljg where id = a.jgid)
           when '医生' then
            a.ysmc
           when '床号' then
            a.ksmc || ':' || a.dm1 || '号床'
           else
            (select xm from ck01_cbry where id = a.hzid)
         end),
         jdtx =
         (case nvl(jdtx, '1')
           when '1' then
            case length(rq)
              when 7 then
               '当月疑似违反《' || v_rule_mc || '》，涉及' || a.jg2 || a.jgms
              when 10 then
               '当日疑似违反《' || v_rule_mc || '》，涉及' || a.jg2 || a.jgms
              else
               ''
            end
           else
            jdtx
         end)
   where a.rid = v_id
    and a.rq like '' || v_rq || '%'

     ;

  commit;

  -----------------打补丁1-----------------
  update mtr_header a
     set SHZT = case (select gzfl from mt_rule where id=a.rid)
                  when '1' then
                   '0'
                  when '2' then
                   '7'
                  when '3' then
                   '9'
                  else
                   '0'
                end
   where a.rid = v_id
     and a.rq like '' || v_rq || '%';

  commit;
  ---------------------------------------

  -----------------打补丁2-----------------
  update mtr_header a
     set hzmc = hzid
   where a.rid = v_id
     and a.rq like '' || v_rq || '%'

     and hzmc is null;
  commit;
  ---------------------------------------

end pr_hs_update_header_xxsj;

/
