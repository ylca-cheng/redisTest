CREATE procedure update_mtr_header_sjje(v_id   in number,
                                                   v_rq   in varchar2,
                                                   v_pcdm in varchar2) is
  v_zje number(12, 2);

  type def_cursor is ref cursor;
  tmp_cursor  def_cursor;
  tmp_cursor1 def_cursor;

  v_mtr_header_def mtr_header%rowtype;
  v_ghdjid         mtr_mapping.lid%type;

BEGIN

  update mtr_header t
     set t.sjje = 0
   where t.rid = v_id
     and t.rq like '' || v_rq || '%'
     and t.pcdm = v_pcdm;
  commit;

  open tmp_cursor for
    SELECT h.id
      from mtr_header h
     where h.rid = v_id
       and h.rq like '' || v_rq || '%'
       and h.pcdm = v_pcdm;

  loop
    fetch tmp_cursor
      into v_mtr_header_def.id;
    exit when tmp_cursor%notfound;

    open tmp_cursor1 for
      SELECT m.lid from mtr_mapping m where m.hid = v_mtr_header_def.id;

    loop
      fetch tmp_cursor1
        into v_ghdjid;
      exit when tmp_cursor1%notfound;

      select nvl(sum(m.zfy), 0)
        into v_zje
        from ck10_jsmx m
       where m.ghdjid = v_ghdjid;

      update mtr_header t
         set t.sjje = t.sjje + v_zje
       where t.id = v_mtr_header_def.id;

    end loop;
    close tmp_cursor1;
    commit;
  end loop;
  close tmp_cursor;

  commit;

end update_mtr_header_sjje;

/
