CREATE procedure usp_jjfx_tjhz(argym in varchar2)
is
i number :=0;
ym number:=0;
yq number:=0;
yy number:=0;
  /*
    argym 格式 YYYY-MM
  */
  begin

    select to_number(to_char(to_date(argym||'-01','YYYY-MM-DD'),'YYYYMM')) into ym  from dual;
  select to_number(to_char(to_date(argym||'-01','YYYY-MM-DD'),'YYYYQ')) into yq from dual;
  select to_number(to_char(to_date(argym||'-01','YYYY-MM-DD'),'YYYY')) into yy from dual;

  --删除tjhz_mz
  delete from tjhz_mz where rqm=ym;
  commit;
  --删除tjhz_zy
  delete from tjhz_zy where rqm=ym;
  commit;
  --删除tjhz_gy
  delete from tjhz_gy where rqm=ym;
  commit;

  --汇总入tjhz_mz
  i:=0;
  for c_row in
  (
  select
  ym rqm,yq rqs,yy rqy
  ,nvl(tcqdm,'0') tcqdm,jgid,grid,nvl(dwid,'0') dwid,nvl(rylb,'0') rylb,nvl(yllb,'0') yllb
  ,count(distinct ghdjid) r01,sum(zfy) r02,sum(nvl(tczf,0)) r03,sum(nvl(zhzf,0)) r04
  ,0 r05,0 r06,0 r07,0 r08,0 r09,0 r10
  from JJFX_JSMX_TMP
  where jzlx='1' and grid is not null
  group by nvl(tcqdm,'0'),jgid,grid,nvl(dwid,'0'),nvl(rylb,'0'),nvl(yllb,'0')
  )
  loop
  insert into tjhz_mz
  (rqm,rqs,rqy,tcqdm,jgid,grid,dwid,rylb,yllb
  ,r01,r02,r03,r04,r05,r06,r07,r08,r09,r10)
  values
  (c_row.rqm,c_row.rqs,c_row.rqy,c_row.tcqdm,c_row.jgid
  ,c_row.grid,c_row.dwid,c_row.rylb,c_row.yllb
  ,c_row.r01,c_row.r02,c_row.r03,c_row.r04,c_row.r05
  ,c_row.r06,c_row.r07,c_row.r08,c_row.r09,c_row.r10);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入tjhz_zy
  i:=0;
  for c_row in
  (
  select
  ym rqm,yq rqs,yy rqy
  ,nvl(tcqdm,'0') tcqdm,jgid,grid,nvl(dwid,'0') dwid,nvl(rylb,'0') rylb,nvl(yllb,'0') yllb
  ,count(distinct ghdjid) r01,sum(zfy) r02,sum(nvl(tczf,0)) r03,sum(nvl(zhzf,0)) r04
  ,0 r05,0 r06,0 r07,0 r08,0 r09,0 r10
  from JJFX_JSMX_TMP
  where jzlx='2' and grid is not null
  group by nvl(tcqdm,'0'),jgid,grid,nvl(dwid,'0'),nvl(rylb,'0'),nvl(yllb,'0')
  )
  loop
  insert into tjhz_zy
  (rqm,rqs,rqy,tcqdm,jgid,grid,dwid,rylb,yllb
  ,r01,r02,r03,r04,r05,r06,r07,r08,r09,r10)
  values
  (c_row.rqm,c_row.rqs,c_row.rqy,c_row.tcqdm,c_row.jgid
  ,c_row.grid,c_row.dwid,c_row.rylb,c_row.yllb
  ,c_row.r01,c_row.r02,c_row.r03,c_row.r04,c_row.r05
  ,c_row.r06,c_row.r07,c_row.r08,c_row.r09,c_row.r10);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  --汇总入tjhz_gy
  i:=0;
  for c_row in
  (
  select
  ym rqm,yq rqs,yy rqy
  ,nvl(tcqdm,'0') tcqdm,jgid,grid,nvl(dwid,'0') dwid,nvl(rylb,'0') rylb,nvl(yllb,'0') yllb
  ,count(distinct ghdjid) r01,sum(zfy) r02,sum(nvl(tczf,0)) r03,sum(nvl(zhzf,0)) r04
  ,0 r05,0 r06,0 r07,0 r08,0 r09,0 r10
  from JJFX_JSMX_TMP
  where jzlx='3' and grid is not null
  group by nvl(tcqdm,'0'),jgid,grid,nvl(dwid,'0'),nvl(rylb,'0'),nvl(yllb,'0')
  )
  loop
  insert into tjhz_gy
  (rqm,rqs,rqy,tcqdm,jgid,grid,dwid,rylb,yllb
  ,r01,r02,r03,r04,r05,r06,r07,r08,r09,r10)
  values
  (c_row.rqm,c_row.rqs,c_row.rqy,c_row.tcqdm,c_row.jgid
  ,c_row.grid,c_row.dwid,c_row.rylb,c_row.yllb
  ,c_row.r01,c_row.r02,c_row.r03,c_row.r04,c_row.r05
  ,c_row.r06,c_row.r07,c_row.r08,c_row.r09,c_row.r10);
  if i>1000 then
    commit;
    i:=i-1000;
  end if;
    i:=i+1;
  end loop;
  commit;

  end;

/
