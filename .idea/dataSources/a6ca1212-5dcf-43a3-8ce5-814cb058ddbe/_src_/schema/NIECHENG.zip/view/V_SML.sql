CREATE VIEW V_SML AS select "DM","MC","SFLB","XMDJ","ZGJG","ZFBL","XMLB","SXDM","TYDM","TYMC","YBBXBZ","YXBZ" from
(select dm,mc,sflb,ypdj as xmdj,zgjg,zfbl,'1' as xmlb,sxdm,tydm,tymc,ybbxbz,yxbz from ck02_ypml
union all
select a.dm,a.mc,a.sflb,a.bxlb as xmdj,a.zgjg,a.zfbl,'2' as xmlb,sxdm,tydm,tymc,'-1' ybbxbz,yxbz from ck02_zlxm a
union all
select a.dm,a.mc,a.sflb,a.bxlb as xmdj,zgjg,zfbl,'3' as xmlb,sxdm,tydm,tymc,'-1' ybbxbz,yxbz from ck02_yycl a) t
/
