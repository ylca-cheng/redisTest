CREATE VIEW V_TEMP_ZY AS select "XM","ID","LSH","YSFLSH","MXDM","MXSL","MXJE","RK" from (
select
t1.xm,
t1.id,
t1.lsh,
t1.ysflsh,
t1.mxdm,
t1.mxsl,
t1.mxje,
rank() over(partition by t1.xm,t1.lsh,t1.ysflsh,t1.mxdm,t1.mxsl,t1.mxje order by id) rk from temp_zy t1
)tt where tt.rk=1
/
