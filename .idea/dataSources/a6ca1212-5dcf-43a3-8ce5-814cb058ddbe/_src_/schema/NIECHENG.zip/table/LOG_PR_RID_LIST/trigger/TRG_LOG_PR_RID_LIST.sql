CREATE TRIGGER TRG_LOG_PR_RID_LIST
BEFORE INSERT
  ON LOG_PR_RID_LIST
FOR EACH ROW
  begin
select seq_log_pr_rid_list.nextval into :new.id from dual;
end;
/
