CREATE TRIGGER TRG_MTR_HEADER
BEFORE INSERT
  ON MTR_HEADER
FOR EACH ROW
  begin
  select seq_mtr_header.nextval into :new.id from dual;
end;
/
