CREATE PROCEDURE etl_zyjzjl(IN vpcdm VARCHAR(50), IN Startsj DATE, IN Endsj DATE)
  begin 
     	--  异常处理
   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION
   begin
       rollback;
       GET DIAGNOSTICS CONDITION 1  v_code = RETURNED_SQLSTATE , v_message= MESSAGE_TEXT; 
       insert into etl_log(dt,pr_name, message)
       select sysdate(),'etl_zyjzjl',concat('报错',v_code,v_message);
      commit;
   end;

 
   
        --  涉及更新的挂号ID筛选
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zyjzjl',
		               '开始查找出涉及更新挂号ID');
                 COMMIT;

       insert into t_zyghgxjl
            (GHID, YXBZ, CJSJ, GXSJ)
      SELECT t.ID, '1',t.CJSJ,sysdate()
                FROM zjb_zyjzjl t
          INNER JOIN t_zyjzjl t1
              ON t.id = t1.ID
         WHERE t.cjsj >= Startsj
          AND t.cjsj < Endsj;
      COMMIT;

      --  中间表数据抽取到仓库表
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zyjzjl',
		               '开始抽取住院就诊记录');
                 COMMIT;
        replace into t_zyjzjl(ID
                      ,JZLSH
                      ,YLJGDM
                      ,ZYH
                      ,BAH	
                      ,KH
                      ,KLX
                      ,HZID
                      ,HZXM
                      ,HZXB
                      ,HZNL
                      ,CSRQ
                      ,BXLX
                      ,YLLB
                      ,RYKSDM
                      ,RYKSMC
                      ,CYKSDM
                      ,CYKSMC
                      ,YSID
                      ,YSXM
                      ,RYRQ
                      ,CYRQ
                      ,ZDDM
                      ,ZDMC
                      ,ZDDMLX
                      ,ZS
                      ,ZZMS
                      ,XBS
                      ,GMS
                      ,JWS
                      ,YCJZS
                      ,ZYSZMS
                      ,TGJC
                      ,FZJC
                      ,CLCS
                      ,SSY
                      ,SZY
                      ,TW
                      ,ML
                      ,XL
                      ,ZJE
                      ,RYTS
                      ,CYBZ  
                      ,ZDDM1
                      ,ZDMC1
                      ,ZDDM2
                      ,ZDMC2
                      ,ZDDM3
                      ,ZDMC3
                      ,ZDDM4
                      ,ZDMC4
                      ,ZDDM5
                      ,ZDMC5
                      ,ZDDM6
                      ,ZDMC6
                      ,ZDDM7
                      ,ZDMC7
                      ,ZDDM8
                      ,ZDMC8
                      ,ZDDM9
                      ,ZDMC9
                      ,PCDM
                      ,ZSSDM
                      ,ZSSMC
                      ,FXBZ)
            SELECT     ID
                      ,JZLSH
                      ,YLJGDM
                      ,ZYH
                      ,BAH	
                      ,KH
                      ,KLX
                      ,HZID
                      ,HZXM
                      ,HZXB
                      ,HZNL
                      ,CSRQ
                      ,BXLX
                      ,YLLB
                      ,RYKSDM
                      ,RYKSMC
                      ,CYKSDM
                      ,CYKSMC
                      ,YSID
                      ,YSXM
                      ,RYRQ
                      ,CYRQ
                      ,ZDDM
                      ,ZDMC
                      ,ZDDMLX
                      ,ZS
                      ,ZZMS
                      ,XBS
                      ,GMS
                      ,JWS
                      ,YCJZS
                      ,ZYSZMS
                      ,TGJC
                      ,FZJC
                      ,CLCS
                      ,SSY
                      ,SZY
                      ,TW
                      ,ML
                      ,XL
                      ,ZJE
                      ,RYTS
                      ,CYBZ  
                      ,ZDDM1
                      ,ZDMC1
                      ,ZDDM2
                      ,ZDMC2
                      ,ZDDM3
                      ,ZDMC3
                      ,ZDDM4
                      ,ZDMC4
                      ,ZDDM5
                      ,ZDMC5
                      ,ZDDM6
                      ,ZDMC6
                      ,ZDDM7
                      ,ZDMC7
                      ,ZDDM8
                      ,ZDMC8
                      ,ZDDM9
                      ,ZDMC9
                      ,vpcdm
                      ,ZSSDM
                      ,ZSSMC
                      ,'1'  from zjb_zyjzjl 
               WHERE  cjsj >= Startsj
                  AND cjsj < Endsj;
         COMMIT;
    --  备份数据  
           INSERT INTO etl_log (dt, pr_name, message)
              VALUES
	              (sysdate(),
		            'etl_zyjzjl',
		            '开始备份所抽取住院就诊记录');
                 COMMIT;
        replace into zjb_zyjzjl_bak(ID
                                  ,JZLSH
                                  ,YLJGDM
                                  ,ZYH
                                  ,BAH
                                  ,CXBZ
                                  ,KH
                                  ,KLX
                                  ,HZID
                                  ,HZXM
                                  ,HZXB
                                  ,HZNL
                                  ,CSRQ
                                  ,BXLX
                                  ,YLLB
                                  ,RYKSDM
                                  ,RYKSMC
                                  ,CYKSDM
                                  ,CYKSMC
                                  ,YSID
                                  ,YSXM
                                  ,RYRQ
                                  ,CYRQ
                                  ,ZDDM
                                  ,ZDMC
                                  ,ZDDMLX
                                  ,ZS
                                  ,ZZMS
                                  ,XBS
                                  ,GMS
                                  ,JWS
                                  ,YCJZS
                                  ,ZYSZMS
                                  ,TGJC
                                  ,FZJC
                                  ,CLCS
                                  ,SSY
                                  ,SZY
                                  ,TW
                                  ,ML
                                  ,XL
                                  ,RYTS
                                  ,CYBZ
                                  ,ZJE
                                  ,ZDDM1
                                  ,ZDMC1
                                  ,ZDDM2
                                  ,ZDMC2
                                  ,ZDDM3
                                  ,ZDMC3
                                  ,ZDDM4
                                  ,ZDMC4
                                  ,ZDDM5
                                  ,ZDMC5
                                  ,ZDDM6
                                  ,ZDMC6
                                  ,ZDDM7
                                  ,ZDMC7
                                  ,ZDDM8
                                  ,ZDMC8
                                  ,ZDDM9
                                  ,ZDMC9
                                  ,ZSSDM
                                  ,ZSSMC
                                  ,CJSJ)
                          SELECT   ID
                                  ,JZLSH
                                  ,YLJGDM
                                  ,ZYH
                                  ,BAH
                                  ,CXBZ
                                  ,KH
                                  ,KLX
                                  ,HZID
                                  ,HZXM
                                  ,HZXB
                                  ,HZNL
                                  ,CSRQ
                                  ,BXLX
                                  ,YLLB
                                  ,RYKSDM
                                  ,RYKSMC
                                  ,CYKSDM
                                  ,CYKSMC
                                  ,YSID
                                  ,YSXM
                                  ,RYRQ
                                  ,CYRQ
                                  ,ZDDM
                                  ,ZDMC
                                  ,ZDDMLX
                                  ,ZS
                                  ,ZZMS
                                  ,XBS
                                  ,GMS
                                  ,JWS
                                  ,YCJZS
                                  ,ZYSZMS
                                  ,TGJC
                                  ,FZJC
                                  ,CLCS
                                  ,SSY
                                  ,SZY
                                  ,TW
                                  ,ML
                                  ,XL
                                  ,RYTS
                                  ,CYBZ
                                  ,ZJE
                                  ,ZDDM1
                                  ,ZDMC1
                                  ,ZDDM2
                                  ,ZDMC2
                                  ,ZDDM3
                                  ,ZDMC3
                                  ,ZDDM4
                                  ,ZDMC4
                                  ,ZDDM5
                                  ,ZDMC5
                                  ,ZDDM6
                                  ,ZDMC6
                                  ,ZDDM7
                                  ,ZDMC7
                                  ,ZDDM8
                                  ,ZDMC8
                                  ,ZDDM9
                                  ,ZDMC9
                                  ,ZSSDM
                                  ,ZSSMC
                                  ,CJSJ   FROM zjb_zyjzjl
                       WHERE  cjsj >= Startsj
                          AND cjsj < Endsj;
                COMMIT;
            
        -- 删除数据
                INSERT INTO etl_log (dt, pr_name, message)
                         VALUES
	                     (sysdate(),
		                   'etl_zyjzjl',
		                   '删除中间表数据');
               COMMIT;
              delete from zjb_zyjzjl  
                     WHERE  cjsj >= Startsj
                        AND cjsj < Endsj;
               COMMIT;
         INSERT INTO etl_log (dt, pr_name, message)
             VALUES
	           (sysdate(),
	          	'etl_zyjzjl',
	          	'住院就诊记录抽取完毕');
         COMMIT;
end;
