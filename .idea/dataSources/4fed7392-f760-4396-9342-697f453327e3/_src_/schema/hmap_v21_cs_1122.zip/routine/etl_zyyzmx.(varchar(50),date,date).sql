CREATE PROCEDURE etl_zyyzmx(IN vpcdm VARCHAR(50), IN Startsj DATE, IN Endsj DATE)
  begin 
      	--  异常处理
   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION
   begin
       rollback;
       GET DIAGNOSTICS CONDITION 1  v_code = RETURNED_SQLSTATE , v_message= MESSAGE_TEXT; 
       insert into etl_log(dt,pr_name, message)
       select sysdate(),'etl_zyyzmx',concat('报错',v_code,v_message);
      commit;
   end;


    --  涉及更新的挂号ID筛选
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zyyzmx',
		               '开始查找出涉及更新挂号ID');
                 COMMIT;

       insert into t_zyghgxjl
            (GHID, YXBZ, CJSJ, GXSJ)
      SELECT t.jzid, '1', t.CJSJ,sysdate()
                FROM zjb_zyyzmx t
          INNER JOIN t_zyyzmx t1
              ON t.jzid = t1.jzid
         WHERE t.cjsj >= Startsj
          AND t.cjsj < Endsj;
      COMMIT;

 --  更新挂号 SEQ_ID   
     INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zyyzmx',
		               '更新处方结算有更新的挂号SEQ_ID'); 
        replace into t_zyjzjl(ID
                      ,JZLSH
                      ,YLJGDM
                      ,ZYH
                      ,BAH	
                      ,KH
                      ,KLX
                      ,HZID
                      ,HZXM
                      ,HZXB
                      ,HZNL
                      ,CSRQ
                      ,BXLX
                      ,YLLB
                      ,RYKSDM
                      ,RYKSMC
                      ,CYKSDM
                      ,CYKSMC
                      ,YSID
                      ,YSXM
                      ,RYRQ
                      ,CYRQ
                      ,ZDDM
                      ,ZDMC
                      ,ZDDMLX
                      ,ZS
                      ,ZZMS
                      ,XBS
                      ,GMS
                      ,JWS
                      ,YCJZS
                      ,ZYSZMS
                      ,TGJC
                      ,FZJC
                      ,CLCS
                      ,SSY
                      ,SZY
                      ,TW
                      ,ML
                      ,XL
                      ,ZJE
                      ,RYTS
                      ,CYBZ  
                      ,ZDDM1
                      ,ZDMC1
                      ,ZDDM2
                      ,ZDMC2
                      ,ZDDM3
                      ,ZDMC3
                      ,ZDDM4
                      ,ZDMC4
                      ,ZDDM5
                      ,ZDMC5
                      ,ZDDM6
                      ,ZDMC6
                      ,ZDDM7
                      ,ZDMC7
                      ,ZDDM8
                      ,ZDMC8
                      ,ZDDM9
                      ,ZDMC9
                      ,PCDM
                      ,ZSSDM
                      ,ZSSMC
                      ,FXBZ)
             select   ID
                      ,JZLSH
                      ,YLJGDM
                      ,ZYH
                      ,BAH	
                      ,KH
                      ,KLX
                      ,HZID
                      ,HZXM
                      ,HZXB
                      ,HZNL
                      ,CSRQ
                      ,BXLX
                      ,YLLB
                      ,RYKSDM
                      ,RYKSMC
                      ,CYKSDM
                      ,CYKSMC
                      ,YSID
                      ,YSXM
                      ,RYRQ
                      ,CYRQ
                      ,ZDDM
                      ,ZDMC
                      ,ZDDMLX
                      ,ZS
                      ,ZZMS
                      ,XBS
                      ,GMS
                      ,JWS
                      ,YCJZS
                      ,ZYSZMS
                      ,TGJC
                      ,FZJC
                      ,CLCS
                      ,SSY
                      ,SZY
                      ,TW
                      ,ML
                      ,XL
                      ,ZJE
                      ,RYTS
                      ,CYBZ  
                      ,ZDDM1
                      ,ZDMC1
                      ,ZDDM2
                      ,ZDMC2
                      ,ZDDM3
                      ,ZDMC3
                      ,ZDDM4
                      ,ZDMC4
                      ,ZDDM5
                      ,ZDMC5
                      ,ZDDM6
                      ,ZDMC6
                      ,ZDDM7
                      ,ZDMC7
                      ,ZDDM8
                      ,ZDMC8
                      ,ZDDM9
                      ,ZDMC9
                      ,vpcdm
                      ,ZSSDM
                      ,ZSSMC
                      ,FXBZ  from t_zyjzjl
       where ID  in (select distinct ghid from t_zyghgxjl );
     COMMIT;
      
     --  中间表数据抽取到仓库表
         INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zyyzmx',
		               '开始抽取住院医嘱明细');
                 COMMIT;

     replace into t_zyyzmx(ID
                       ,JZID
                       ,YZMXH
                       ,JZLSH
                       ,YLJGDM
                       ,CXBZ
                       ,KH
                       ,KLX
                       ,SFLB
                       ,BQ
                       ,XDKSDM
                       ,XDKSMC
                       ,XDRGH
                       ,XDRXM
                       ,XDSJ
                       ,ZXKSDM
                       ,ZXKSMC
                       ,ZXRGH
                       ,ZXRXM
                       ,ZXSJ
                       ,ZZSJ
                       ,YZSM
                       ,YZLB
                       ,XMDM
                       ,XMMC
                       ,SFYP
                       ,XMDJ
                       ,XMDW
                       ,XMSL
                       ,XMJE
                       ,YPGG
                       ,YPYF
                       ,JX
                       ,YYPC
                       ,JL
                       ,JLDW
                       ,SLDW
                       ,YYTJ
                       ,YYTS
                       ,PCPB
                       ,FYSL
                       ,FYDW
                       ,ZYJZFDM
                       ,JCBW
                       ,BZ
                       ,YBXMDM
                       ,YBXMMC
                       ,FXBZ)
                 select ID
                       ,JZID
                       ,YZMXH
                       ,JZLSH
                       ,YLJGDM
                       ,CXBZ
                       ,KH
                       ,KLX
                       ,SFLB
                       ,BQ
                       ,XDKSDM
                       ,XDKSMC
                       ,XDRGH
                       ,XDRXM
                       ,XDSJ
                       ,ZXKSDM
                       ,ZXKSMC
                       ,ZXRGH
                       ,ZXRXM
                       ,ZXSJ
                       ,ZZSJ
                       ,YZSM
                       ,YZLB
                       ,XMDM
                       ,XMMC
                       ,SFYP
                       ,XMDJ
                       ,XMDW
                       ,XMSL
                       ,XMJE
                       ,YPGG
                       ,YPYF
                       ,JX
                       ,YYPC
                       ,JL
                       ,JLDW
                       ,SLDW
                       ,YYTJ
                       ,YYTS
                       ,PCPB
                       ,FYSL
                       ,FYDW
                       ,ZYJZFDM
                       ,JCBW
                       ,BZ
                       ,YBXMDM
                       ,YBXMMC
                       ,'1'  from zjb_zyyzmx 
              WHERE  cjsj >= Startsj
                 AND cjsj < Endsj;
          COMMIT;
     
      --  备份数据  
           INSERT INTO etl_log (dt, pr_name, message)
              VALUES
	              (sysdate(),
		            'etl_zyyzmx',
		            '开始备份所抽取住院医嘱明细');

        insert into zjb_zyyzmx_bak(ID
                               ,JZID
                               ,YZMXH
                               ,JZLSH
                               ,YLJGDM
                               ,CXBZ
                               ,KH
                               ,KLX
                               ,SFLB
                               ,BQ
                               ,XDKSDM
                               ,XDKSMC
                               ,XDRGH
                               ,XDRXM
                               ,XDSJ
                               ,ZXKSDM
                               ,ZXKSMC
                               ,ZXRGH
                               ,ZXRXM
                               ,ZXSJ
                               ,ZZSJ
                               ,YZSM
                               ,YZLB
                               ,XMDM
                               ,XMMC
                               ,SFYP
                               ,XMDJ
                               ,XMDW
                               ,XMSL
                               ,XMJE
                               ,YPGG
                               ,YPYF
                               ,JX
                               ,YYPC
                               ,JL
                               ,JLDW
                               ,SLDW
                               ,YYTJ
                               ,YYTS
                               ,PCPB
                               ,FYSL
                               ,FYDW
                               ,ZYJZFDM
                               ,JCBW
                               ,BZ
                               ,YBXMDM
                               ,YBXMMC
                               ,CJSJ)
                         select ID
                               ,JZID
                               ,YZMXH
                               ,JZLSH
                               ,YLJGDM
                               ,CXBZ
                               ,KH
                               ,KLX
                               ,SFLB
                               ,BQ
                               ,XDKSDM
                               ,XDKSMC
                               ,XDRGH
                               ,XDRXM
                               ,XDSJ
                               ,ZXKSDM
                               ,ZXKSMC
                               ,ZXRGH
                               ,ZXRXM
                               ,ZXSJ
                               ,ZZSJ
                               ,YZSM
                               ,YZLB
                               ,XMDM
                               ,XMMC
                               ,SFYP
                               ,XMDJ
                               ,XMDW
                               ,XMSL
                               ,XMJE
                               ,YPGG
                               ,YPYF
                               ,JX
                               ,YYPC
                               ,JL
                               ,JLDW
                               ,SLDW
                               ,YYTJ
                               ,YYTS
                               ,PCPB
                               ,FYSL
                               ,FYDW
                               ,ZYJZFDM
                               ,JCBW
                               ,BZ
                               ,YBXMDM
                               ,YBXMMC
                               ,CJSJ  from zjb_zyyzmx 
                          WHERE  cjsj >= Startsj
                             AND cjsj < Endsj;
                         COMMIT;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zyyzmx ', '获取负交易数据');
   commit;

   insert into T_ZFJY_TEMP(jzid, xmdm, dj, cxlx)
      select distinct jzid, xmdm, xmdj, '3'
         from ZJB_ZYYZMX t
            where cjsj >= startsj and cjsj < endsj and xmsl < 0;
   commit;

       -- 删除数据
                INSERT INTO etl_log (dt, pr_name, message)
                         VALUES
	                     (sysdate(),
		                   'etl_zyzymx',
		                   '删除中间表数据');

     delete from zjb_zyyzmx
         WHERE  cjsj >= Startsj
            AND cjsj < Endsj;
       COMMIT;

         INSERT INTO etl_log (dt, pr_name, message)
             VALUES
	           (sysdate(),
	          	'etl_zyyzmx',
	          	'抽取完毕');
end;
