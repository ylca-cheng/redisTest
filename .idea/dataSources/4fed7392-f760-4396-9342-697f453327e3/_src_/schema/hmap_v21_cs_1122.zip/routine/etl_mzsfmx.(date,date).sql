CREATE PROCEDURE etl_mzsfmx(IN Startsj DATE, IN Endsj DATE)
  BEGIN 

   	--  异常处理
   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION
   begin
       rollback;
       GET DIAGNOSTICS CONDITION 1  v_code = RETURNED_SQLSTATE , v_message= MESSAGE_TEXT; 
       insert into etl_log(dt,pr_name, message)
       select sysdate(),'etl_mzsfmx',concat('报错',v_code,v_message);
      commit;
   end;

          --  涉及更新的挂号ID筛选
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_mzsfmx',
		               '开始查找出涉及更新挂号ID');
                 COMMIT;

       insert into t_zyghgxjl
            (GHID, YXBZ, CJSJ, GXSJ)
      SELECT t.JZID, '1',t.CJSJ, sysdate()
                FROM zjb_mzsfmx t
          INNER JOIN t_mzsfmx t1
              ON t.JZID = t1.JZID
         WHERE t.cjsj >= Startsj
          AND t.cjsj < Endsj;
      COMMIT;

    --  中间表数据抽取到仓库表
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_mzsfmx',
		               '开始抽取门诊收费明细');
                 COMMIT;
     replace into t_mzsfmx (ID	
                           ,CFMXID
                           ,JZID
                           ,JZLSH
                           ,CFMXH
                           ,YLJGDM
                           ,KH
                           ,KLX
                           ,SFLB
                           ,MXXMLB
                           ,JSRQ
                           ,XMDM
                           ,XMMC
                           ,XMDW
                           ,XMGG
                           ,XMDJ
                           ,XMSL
                           ,XMJE
                           ,YBXMDM
                           ,YBXMMC
                           ,KSDM
                           ,KSMC
                           ,CJRQ
                           ,FXBZ)
    select ID	
          ,CFMXID
          ,JZID
          ,JZLSH
          ,CFMXH
          ,YLJGDM
          ,KH
          ,KLX
          ,SFLB
          ,MXXMLB
          ,JSRQ
          ,XMDM
          ,XMMC
          ,XMDW
          ,XMGG
          ,XMDJ
          ,XMSL
          ,XMJE
          ,YBXMDM
          ,YBXMMC
          ,KSDM
          ,KSMC
          ,CJSJ
          ,'1'   from zjb_mzsfmx
       WHERE  cjsj >= Startsj
          AND cjsj < Endsj;
     COMMIT;
    --  备份数据  
           INSERT INTO etl_log (dt, pr_name, message)
              VALUES
	              (sysdate(),
		            'etl_mzsfmx',
		            '开始备份所抽取门诊收费明细');
                 COMMIT;
      insert into zjb_mzsfmx_bak(ID
                                 ,JZID
                                 ,CFMXID	
                                 ,JZLSH
                                 ,CFMXH
                                 ,YLJGDM
                                 ,CXBZ
                                 ,KH
                                 ,KLX
                                 ,SFLB
                                 ,MXXMLB
                                 ,JSRQ
                                 ,XMDM
                                 ,XMMC
                                 ,XMDW
                                 ,XMGG
                                 ,XMDJ
                                 ,XMSL
                                 ,XMJE
                                 ,YBXMDM
                                 ,YBXMMC
                                 ,KSDM
                                 ,KSMC
                                 ,CJSJ)
        select  ID 
               ,JZID
               ,CFMXID	
               ,JZLSH
               ,CFMXH
               ,YLJGDM
               ,CXBZ
               ,KH
               ,KLX
               ,SFLB
               ,MXXMLB
               ,JSRQ
               ,XMDM
               ,XMMC
               ,XMDW
               ,XMGG
               ,XMDJ
               ,XMSL
               ,XMJE
               ,YBXMDM
               ,YBXMMC
               ,KSDM
               ,KSMC
               ,CJSJ  from zjb_mzsfmx
        WHERE  cjsj >= Startsj
           AND cjsj < Endsj;
     COMMIT;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_mzsfmx', '获取负交易数据');
   commit;

   insert into T_ZFJY_TEMP(jzid, xmdm, dj, cxlx)
      select distinct jzid, xmdm, xmdj, '2'
         from zjb_mzsfmx t
            where cjsj >= startsj and cjsj < endsj and xmsl < 0;
   commit;

   -- 删除数据
   INSERT INTO etl_log (dt, pr_name, message)
      VALUES(sysdate(), 'etl_mzsfmx', '删除中间表数据');
   COMMIT;

   delete  from zjb_mzsfmx 
      WHERE  cjsj >= Startsj AND cjsj < Endsj;
     COMMIT;

   INSERT INTO etl_log (dt, pr_name, message)
      VALUES(sysdate(),
	          	'etl_mzsfmx',
	          	'门诊收费明细抽取完毕');
         COMMIT;

end;
