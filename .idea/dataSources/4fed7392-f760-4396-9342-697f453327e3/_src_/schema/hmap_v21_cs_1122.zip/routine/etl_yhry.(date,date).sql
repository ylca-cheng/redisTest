CREATE PROCEDURE etl_yhry(IN Startsj DATE, IN Endsj DATE)
  begin 
--  异常处理
   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION
   begin
       rollback;
       GET DIAGNOSTICS CONDITION 1  v_code = RETURNED_SQLSTATE , v_message= MESSAGE_TEXT; 
       insert into etl_log(dt,pr_name, message)
       select sysdate(),'etl_yhry',concat('报错',v_code,v_message);
      commit;
   end;
--  中间表数据抽取到仓库表
    insert into etl_log
        (dt, pr_name, message)
        VALUES
      (sysdate(), 'etl_yhry', '开始抽取医护人员');
     commit;
   
   replace into t_yhry(GH
                      ,YLJGDM
                      ,XM
                      ,XB
                      ,SFZH
                      ,SSKS
                      ,SSKSMC
                      ,ZWDM
                      ,ZHIW
                      ,ZCDM
                      ,ZHIC
                      ,CSRQ
                      ,LB
                      ,ZHUANY)
   select GH
         ,YLJGDM
         ,XM
         ,XB
         ,SFZH
         ,SSKS
         ,SSKSMC
         ,ZWDM
         ,ZHIW
         ,ZCDM
         ,ZHIC
         ,CSRQ
         ,LB
         ,ZHUANY  from zjb_yhry
    where cjsj >= Startsj
           and cjsj < Endsj;
  commit;
    --  备份数据  
    insert into etl_log
      (dt, pr_name, message)
      VALUES
    (sysdate(), 'etl_yhry', '开始备份所抽取医护人员');
    commit;
     replace into zjb_yhry_bak(GH
                              ,YLJGDM
                              ,XM
                              ,XB
                              ,SFZH
                              ,SSKS
                              ,SSKSMC
                              ,ZWDM
                              ,ZHIW
                              ,ZCDM
                              ,ZHIC
                              ,CSRQ
                              ,LB
                              ,ZHUANY
                              ,CJSJ)
       select GH
             ,YLJGDM
             ,XM
             ,XB
             ,SFZH
             ,SSKS
             ,SSKSMC
             ,ZWDM
             ,ZHIW
             ,ZCDM
             ,ZHIC
             ,CSRQ
             ,LB
             ,ZHUANY
             ,CJSJ  from zjb_yhry
         where cjsj >= Startsj
           and cjsj < Endsj;
        commit;
   -- 删除数据
     insert into etl_log
         (dt, pr_name, message)
               VALUES
     (sysdate(), 'etl_yhry', '删除中间表数据');
    commit;

    delete from zjb_yhry
      where cjsj >= Startsj
           and cjsj < Endsj;
        commit;
   insert into etl_log
        (dt, pr_name, message)
              VALUES
        (sysdate(), 'etl_yhry', '医护人员抽取完毕');
     commit;
    
  end;
