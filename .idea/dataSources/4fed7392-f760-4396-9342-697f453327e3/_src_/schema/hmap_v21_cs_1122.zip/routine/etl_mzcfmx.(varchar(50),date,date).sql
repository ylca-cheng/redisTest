CREATE PROCEDURE etl_mzcfmx(IN vpcdm VARCHAR(50), IN Startsj DATE, IN Endsj DATE)
  begin

   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit handler for sqlwarning,
                               not found,
                               sqlexception
   begin
      rollback;
      get diagnostics
         condition 1 v_code = returned_sqlstate, v_message = message_text;

      insert into ETL_LOG(dt, pr_name, message)
         select sysdate(), 'etl_mzcfmx', concat('报错', v_code, v_message);
      commit;
   end;
     --  涉及更新的挂号ID筛选
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_mzcfmx',
		               '开始查找出涉及更新挂号ID');
                 COMMIT;

       insert into t_zyghgxjl
            (GHID, YXBZ, CJSJ, GXSJ)
      SELECT t.jzid, '1', t.CJSJ,sysdate()
                FROM zjb_mzcfmx t
          INNER JOIN t_mzcfmx t1
              ON t.jzid = t1.jzid
         WHERE t.cjsj >= Startsj
          AND t.cjsj < Endsj;
      COMMIT;
  
--  更新挂号 SEQ_ID
   
  INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_mzcfmx',
		               '更新处方结算有更新的挂号SEQ_ID');  
        replace into t_mzjzjl(ID
                              ,JZLSH
                              ,YLJGDM	
                              ,KH
                              ,KLX
                              ,HZID
                              ,HZXM
                              ,HZXB
                              ,HZNL
                              ,CFZBZ
                              ,BXLX
                              ,YLLB
                              ,KSDM
                              ,KSMC
                              ,YSID
                              ,YSXM
                              ,CSRQ
                              ,JZRQ
                              ,ZDDM
                              ,ZDSM
                              ,ZDMC
                              ,ZDDMLX   
                              ,ZS
                              ,ZZMS
                              ,XBS
                              ,GMS
                              ,JWS
                              ,YCJZS
                              ,ZYSZMS
                              ,TGJCJL
                              ,FZJCJL
                              ,CLCS
                              ,SSY
                              ,SZY
                              ,KFXT
                              ,CHXT
                              ,TW
                              ,ML
                              ,XL
                              ,ZJE
                              ,PCDM
                              ,FXBZ
                             )
                     select ID
                              ,JZLSH
                              ,YLJGDM	
                              ,KH
                              ,KLX
                              ,HZID
                              ,HZXM
                              ,HZXB
                              ,HZNL
                              ,CFZBZ
                              ,BXLX
                              ,YLLB
                              ,KSDM
                              ,KSMC
                              ,YSID
                              ,YSXM
                              ,CSRQ
                              ,JZRQ
                              ,ZDDM
                              ,ZDSM
                              ,ZDMC
                              ,ZDDMLX   
                              ,ZS
                              ,ZZMS
                              ,XBS
                              ,GMS
                              ,JWS
                              ,YCJZS
                              ,ZYSZMS
                              ,TGJCJL
                              ,FZJCJL
                              ,CLCS
                              ,SSY
                              ,SZY
                              ,KFXT
                              ,CHXT
                              ,TW
                              ,ML
                              ,XL
                              ,ZJE
                              ,vpcdm
                              ,FXBZ  from t_mzjzjl
      where id in (select distinct ghid from t_zyghgxjl);
   COMMIT;


   -- 中间表数据抽取到仓库表
   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_mzcfmx', '开始抽取门诊处方明细记录');
   commit;

   replace into T_MZCFMX(id,
                         jzid,
                         cfmxh,
                         jzlsh,
                         kh,
                         klx,
                         sflb,
                         ksdm,
                         ksmc,
                         ysid,
                         ysxm,
                         kfsj,
                         xmdm,
                         xmmc,
                         xmdj,
                         xmje,
                         sfyp,
                         ypgg,
                         fysl,
                         ypdw,
                         cfts,
                         yypc,
                         ywsypd,
                         jx,
                         jl,
                         jldw,
                         xmsl,
                         sldw,
                         yf,
                         yytj,
                         yyts,
                         zyjzfdm,
                         pspb,
                         jcbw,
                         bz,
                         ybxmdm,
                         ybxmmc,
                         fxbz)
   select id,
          jzid,
          cfmxh,
          jzlsh,
          kh,
          klx,
          sflb,
          ksdm,
          ksmc,
          ysid,
          ysxm,
          kfsj,
          xmdm,
          xmmc,
          xmdj,
          xmje,
          sfyp,
          ypgg,
          fysl,
          ypdw,
          cfts,
          yypc,
          ywsypd,
          jx,
          jl,
          jldw,
          xmsl,
          sldw,
          yf,
          yytj,
          yyts,
          zyjzfdm,
          pspb,
          jcbw,
          bz,
          ybxmdm,
          ybxmmc,
          '1'
     from ZJB_MZCFMX
    where cjsj >= startsj and cjsj < endsj;
   commit;

   -- 备份数据
   insert into ETL_LOG(dt, pr_name, message)
           values (
                     sysdate(),
                     'etl_mzcfmx',
                     '开始备份所抽取门诊处方明细');
   commit;

   insert into ZJB_MZCFMX_BAK(id,
                               jzid,
                               cfmxh,
                               jzlsh,
                               cxbz,
                               kh,
                               klx,
                               sflb,
                               ksdm,
                               ksmc,
                               ysid,
                               ysxm,
                               kfsj,
                               xmdm,
                               xmmc,
                               xmdj,
                               xmje,
                               sfyp,
                               ypgg,
                               fysl,
                               ypdw,
                               cfts,
                               yypc,
                               ywsypd,
                               jx,
                               jl,
                               jldw,
                               xmsl,
                               sldw,
                               yf,
                               yytj,
                               yyts,
                               zyjzfdm,
                               pspb,
                               jcbw,
                               ybxmdm,
                               ybxmmc,
                               bz,
                               cjsj)
   select id,
          jzid,
          cfmxh,
          jzlsh,
          cxbz,
          kh,
          klx,
          sflb,
          ksdm,
          ksmc,
          ysid,
          ysxm,
          kfsj,
          xmdm,
          xmmc,
          xmdj,
          xmje,
          sfyp,
          ypgg,
          fysl,
          ypdw,
          cfts,
          yypc,
          ywsypd,
          jx,
          jl,
          jldw,
          xmsl,
          sldw,
          yf,
          yytj,
          yyts,
          zyjzfdm,
          pspb,
          jcbw,
          ybxmdm,
          ybxmmc,
          bz,
          cjsj
     from ZJB_MZCFMX
    where cjsj >= startsj and cjsj < endsj;
   commit;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_mzcfmx', '获取负交易数据');
   commit;

   insert into T_ZFJY_TEMP(jzid, xmdm, dj, cxlx)
      select distinct jzid, xmdm, xmdj, '1'
         from ZJB_MZCFMX t
            where cjsj >= startsj and cjsj < endsj and xmsl < 0;
   commit;

   -- 删除数据
   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_mzcfmx', '删除中间表数据');
   commit;

   delete from ZJB_MZCFMX
         where cjsj >= startsj and cjsj < endsj;
   commit;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_mzcfmx', '中间表数据删除完成');
   commit;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_mzcfmx', '门诊处方明细抽取完毕');
   commit;

end;
