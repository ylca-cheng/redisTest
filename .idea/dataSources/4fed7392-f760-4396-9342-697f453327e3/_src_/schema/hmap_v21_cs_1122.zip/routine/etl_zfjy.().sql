CREATE PROCEDURE etl_zfjy()
  begin

   declare v_jzid1 varchar(32);
   declare v_xmdm1 varchar(32);
   declare v_dj1 decimal(12,4);

   declare v_id2 varchar(32);
   declare v_sl2 decimal(12,4);
   declare v_fxbz varchar(1);

   declare v_zsl_z decimal(12,4);
   declare v_zsl_f decimal(12,4);

   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit handler for sqlwarning,
                               not found,
                               sqlexception
   begin
      rollback;
      get diagnostics
         condition 1 v_code = returned_sqlstate, v_message = message_text;

      insert into ETL_LOG(dt, pr_name, message)
         select sysdate(), 'etl_zfjy', concat('报错', v_code, v_message);
      commit;
   end;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zfjy', '开始处理门诊处方明细正负交易数据');
   commit;

   set v_jzid1 = null;
   set v_xmdm1 = null;
   set v_dj1 = null;
   set v_zsl_z = 0;
   set v_zsl_f = 0;

   begin

      declare cur1_done int default false;
      declare cur1 cursor for select jzid, xmdm, dj from T_ZFJY_TEMP where cxlx = '1';
      declare continue handler for not found set cur1_done = true;

      open cur1;

      read_loop1: loop

         fetch cur1 into v_jzid1, v_xmdm1, v_dj1;
    
         if cur1_done then
            leave read_loop1;
         end if;

         -- 获取总的正负数量
         select ifnull(abs(sum(case when xmsl > 0 then xmsl else 0 end)), 0),
                ifnull(abs(sum(case when xmsl < 0 then xmsl else 0 end)), 0)
            into v_zsl_z, v_zsl_f
               from T_MZCFMX
                  where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3');

         -- 如果完全匹配或负交易总数大于正交易
         if v_zsl_z <= v_zsl_f then

            -- 所有数据更新为无效
            update T_MZCFMX
               set fxbz = case when fxbz = '1' then '0'
                               when fxbz = '3' then '2' end
                  where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3');
            commit;
                         
        else

          set v_zsl_z = 0;

            begin

               declare cur2_done int default false;
               declare cur2 cursor for select id, xmsl, fxbz from T_MZCFMX where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3') and xmsl > 0 order by kfsj desc;
               declare continue handler for not found set cur2_done = true;

               set v_id2 = null;
               set v_sl2 = 0;
               set v_fxbz = null;

               truncate table T_ZFJY_DETAIL_TEMP;

               insert into T_ZFJY_DETAIL_TEMP(id, fxbz)
                  select id, fxbz from T_MZCFMX where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3') and xmsl < 0;
               commit;

               open cur2;

               read_loop2: loop

                  -- 逐条获取正数据
                  fetch cur2 into v_id2, v_sl2, v_fxbz;

                  if cur2_done then
                    leave read_loop2;
                  end if;

                  -- 累加正数据
                  set v_zsl_z = v_zsl_z + ifnull(v_sl2, 0);

                  -- 先将这条数据记录到临时表
                  insert into T_ZFJY_DETAIL_TEMP(id, fxbz)
                     values(v_id2, v_fxbz);
                  commit;

                  -- 数据到此正好完全抵消
                  if v_zsl_z = v_zsl_f then

                     -- 所有数据更新为无效
                     update T_MZCFMX
                        set fxbz = case when fxbz = '1' then '0'
                                        when fxbz = '3' then '2' end
                           where id in (select id from T_ZFJY_DETAIL_TEMP);
                     commit;

                     leave read_loop2;

                  elseif v_zsl_z > v_zsl_f then

                     -- 所有数据更新为无效
                     update T_MZCFMX
                        set fxbz = case when fxbz = '1' then '0'
                                        when fxbz = '3' then '2' end
                           where id in (select id from T_ZFJY_DETAIL_TEMP);
                     commit;

                     -- 为多出的正数据生成人造数据
                     insert into T_MZCFMX(id,jzid,cfmxh,jzlsh,kh,klx,sflb,ksdm,ksmc,ysid,ysxm,kfsj,xmdm,xmmc,xmdj,xmje,sfyp,
                                          ypgg,fysl,ypdw,cfts,yypc,ywsypd,jx,jl,jldw,xmsl,sldw,yf,yytj,yyts,zyjzfdm,pspb,jcbw,bz,
                                          ybxmdm,ybxmmc,fxbz)
                        select concat(id, '#WN') as id,jzid,cfmxh,jzlsh,kh,klx,sflb,ksdm,ksmc,ysid,ysxm,kfsj,xmdm,xmmc,xmdj,
                               round(xmje / xmsl * (v_zsl_z - v_zsl_f), 4) as xmje,sfyp,ypgg,fysl,ypdw,cfts,yypc,ywsypd,jx,jl,jldw,
                               (v_zsl_z - v_zsl_f) as xmsl,sldw,yf,yytj,yyts,zyjzfdm,pspb,jcbw,bz,ybxmdm,ybxmmc,
                               '3' as fxbz
                           from T_MZCFMX
                              where id =  v_id2;
                     commit;

                     set v_id2 = concat(v_id2, '#WN');

                     -- 插入关联表数据
                     insert into T_CXGL(ysid, rzid, ghid, cxlx, cjsj, gxsj)
                        select id, v_id2, v_jzid1, '1', now(), now()
                           from T_ZFJY_DETAIL_TEMP
                              where fxbz = '1';
                     commit;

                     -- 作废的人造数据，追溯上一层的关联原始数据
                     insert into T_CXGL(ysid, rzid, ghid, cxlx, cjsj, gxsj)
                        select ysid, v_id2, v_jzid1, '1', now(), now()
                           from T_CXGL
                              where rzid in (select id
                                                from T_ZFJY_DETAIL_TEMP
                                                   where fxbz = '3') and cxlx = '1';
                     commit;

                     leave read_loop2;

                  end if;

                  set v_id2 = null;
                  set v_sl2 = 0;
                  set v_fxbz = null;

               end loop;

               close cur2;

            end;

         end if;

         set v_zsl_z = 0;
         set v_zsl_f = 0;
         set v_jzid1 = null;
         set v_xmdm1 = null;
         set v_dj1 = null;

      end loop;
  
      close cur1;

   end;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zfjy', '门诊处方明细正负交易数据处理完成');
   commit;

-- --------------------------------------------------------------------------------------------

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zfjy', '开始处理门诊收费明细正负交易数据');
   commit;

   set v_jzid1 = null;
   set v_xmdm1 = null;
   set v_dj1 = null;
   set v_zsl_z = 0;
   set v_zsl_f = 0;

   begin

      declare cur3_done int default false;
      declare cur3 cursor for select jzid, xmdm, dj from T_ZFJY_TEMP where cxlx = '2';
      declare continue handler for not found set cur3_done = true;

      open cur3;

      read_loop3: loop

         fetch cur3 into v_jzid1, v_xmdm1, v_dj1;
    
         if cur3_done then
            leave read_loop3;
         end if;

         -- 获取总的正负数量
         select ifnull(abs(sum(case when xmsl > 0 then xmsl else 0 end)), 0),
                ifnull(abs(sum(case when xmsl < 0 then xmsl else 0 end)), 0)
            into v_zsl_z, v_zsl_f
               from T_MZSFMX
                  where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3');

         -- 如果完全匹配或负交易总数大于正交易
         if v_zsl_z <= v_zsl_f then

            -- 所有数据更新为无效
            update T_MZSFMX
               set fxbz = case when fxbz = '1' then '0'
                               when fxbz = '3' then '2' end
                  where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3');
            commit;

         else

            set v_zsl_z = 0;

            begin

               declare cur4_done int default false;
               declare cur4 cursor for select id, xmsl, fxbz from T_MZSFMX where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3') and xmsl > 0 order by jsrq desc;
               declare continue handler for not found set cur4_done = true;

               set v_id2 = null;
               set v_sl2 = 0;
               set v_fxbz = null;

               truncate table T_ZFJY_DETAIL_TEMP;

               insert into T_ZFJY_DETAIL_TEMP(id, fxbz)
                  select id, fxbz from T_MZSFMX where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3') and xmsl < 0;
               commit;

               open cur4;

               read_loop4: loop

                  -- 逐条获取正数据
                  fetch cur4 into v_id2, v_sl2, v_fxbz;

                  if cur4_done then
                    leave read_loop4;
                  end if;

                  -- 累加正数据
                  set v_zsl_z = v_zsl_z + ifnull(v_sl2, 0);

                  -- 先将这条数据记录到临时表
                  insert into T_ZFJY_DETAIL_TEMP(id, fxbz)
                     values(v_id2, v_fxbz);
                  commit;

                  -- 数据到此正好完全抵消
                  if v_zsl_z = v_zsl_f then

                     -- 所有数据更新为无效
                     update T_MZSFMX
                        set fxbz = case when fxbz = '1' then '0'
                                        when fxbz = '3' then '2' end
                           where id in (select id from T_ZFJY_DETAIL_TEMP);
                     commit;

                     leave read_loop4;

                  elseif v_zsl_z > v_zsl_f then

                     -- 所有数据更新为无效
                     update T_MZSFMX
                        set fxbz = case when fxbz = '1' then '0'
                                        when fxbz = '3' then '2' end
                           where id in (select id from T_ZFJY_DETAIL_TEMP);
                     commit;

                     -- 为多出的正数据生成人造数据
                     insert into T_MZSFMX(id,cfmxid,jzid,jzlsh,cfmxh,yljgdm,kh,klx,sflb,mxxmlb,jsrq,xmdm,xmmc,xmdw,xmgg,xmdj,
                                          xmsl,xmje,ybxmdm,ybxmmc,ksdm,ksmc,cjrq,fxbz)
                        select concat(id, '#WN') as id,cfmxid,jzid,jzlsh,cfmxh,yljgdm,kh,klx,sflb,mxxmlb,jsrq,xmdm,xmmc,xmdw,
                               xmgg,xmdj,(v_zsl_z - v_zsl_f) as xmsl,
                               round(xmje / xmsl * (v_zsl_z - v_zsl_f), 4) as xmje,ybxmdm,ybxmmc,ksdm,ksmc,cjrq,'3'
                           from T_MZSFMX
                              where id = v_id2;
                     commit;

                     set v_id2 = concat(v_id2, '#WN');

                     -- 插入关联表数据
                     insert into T_CXGL(ysid, rzid, ghid, cxlx, cjsj, gxsj)
                        select id, v_id2, v_jzid1, '2', now(), now()
                           from T_ZFJY_DETAIL_TEMP
                              where fxbz = '1';
                     commit;

                     -- 作废的人造数据，追溯上一层的关联原始数据
                     insert into T_CXGL(ysid, rzid, ghid, cxlx, cjsj, gxsj)
                        select ysid, v_id2, v_jzid1, '2', now(), now()
                           from T_CXGL
                              where rzid in (select id
                                                from T_ZFJY_DETAIL_TEMP
                                                   where fxbz = '3') and cxlx = '2';
                     commit;

                     leave read_loop4;

                  end if;

                  set v_id2 = null;
                  set v_sl2 = 0;
                  set v_fxbz = null;

               end loop;

               close cur4;

            end;

         end if;

         set v_zsl_z = 0;
         set v_zsl_f = 0;
         set v_jzid1 = null;
         set v_xmdm1 = null;
         set v_dj1 = null;

      end loop;
  
      close cur3;

   end;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zfjy', '门诊收费明细正负交易数据处理完成');
   commit;

-- -------------------------------------------------------------

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zfjy', '开始处理住院医嘱明细正负交易数据');
   commit;

   set v_jzid1 = null;
   set v_xmdm1 = null;
   set v_dj1 = null;
   set v_zsl_z = 0;
   set v_zsl_f = 0;

   begin

      declare cur5_done int default false;
      declare cur5 cursor for select jzid, xmdm, dj from T_ZFJY_TEMP where cxlx = '3';
      declare continue handler for not found set cur5_done = true;

      open cur5;

      read_loop5: loop

         fetch cur5 into v_jzid1, v_xmdm1, v_dj1;
    
         if cur5_done then
            leave read_loop5;
         end if;

         -- 获取总的正负数量
         select ifnull(abs(sum(case when xmsl > 0 then xmsl else 0 end)), 0),
                ifnull(abs(sum(case when xmsl < 0 then xmsl else 0 end)), 0)
            into v_zsl_z, v_zsl_f
               from T_ZYYZMX
                  where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3');

         -- 如果完全匹配或负交易总数大于正交易
         if v_zsl_z <= v_zsl_f then

            -- 所有数据更新为无效
            update T_ZYYZMX
               set fxbz = case when fxbz = '1' then '0'
                               when fxbz = '3' then '2' end
                  where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3');
            commit;

         else

            set v_zsl_z = 0;

            begin

               declare cur6_done int default false;
               declare cur6 cursor for select id, xmsl, fxbz from T_ZYYZMX where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3') and xmsl > 0 order by xdsj desc;
               declare continue handler for not found set cur6_done = true;

               set v_id2 = null;
               set v_sl2 = 0;
               set v_fxbz = null;

               truncate table T_ZFJY_DETAIL_TEMP;

               insert into T_ZFJY_DETAIL_TEMP(id, fxbz)
                  select id, fxbz from T_ZYYZMX where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3') and xmsl < 0;
               commit;

               open cur6;

               read_loop6: loop

                  -- 逐条获取正数据
                  fetch cur6 into v_id2, v_sl2, v_fxbz;

                  if cur6_done then
                    leave read_loop6;
                  end if;

                  -- 累加正数据
                  set v_zsl_z = v_zsl_z + ifnull(v_sl2, 0);

                  -- 先将这条数据记录到临时表
                  insert into T_ZFJY_DETAIL_TEMP(id, fxbz)
                     values(v_id2, v_fxbz);
                  commit;

                  -- 数据到此正好完全抵消
                  if v_zsl_z = v_zsl_f then

                     -- 所有数据更新为无效
                     update T_ZYYZMX
                        set fxbz = case when fxbz = '1' then '0'
                                        when fxbz = '3' then '2' end
                           where id in (select id from T_ZFJY_DETAIL_TEMP);
                     commit;

                     leave read_loop6;

                  elseif v_zsl_z > v_zsl_f then

                     -- 所有数据更新为无效
                     update T_ZYYZMX
                        set fxbz = case when fxbz = '1' then '0'
                                        when fxbz = '3' then '2' end
                           where id in (select id from T_ZFJY_DETAIL_TEMP);
                     commit;

                     -- 为多出的正数据生成人造数据
                     insert into T_ZYYZMX(id,jzid,yzmxh,jzlsh,yljgdm,cxbz,kh,klx,sflb,bq,xdksdm,xdksmc,xdrgh,xdrxm,xdsj,zxksdm,
                                          zxksmc,zxrgh,zxrxm,zxsj,zzsj,yzsm,yzlb,xmdm,xmmc,sfyp,xmdj,xmdw,xmsl,xmje,ypgg,ypyf,
                                          jx,yypc,jl,jldw,sldw,yytj,yyts,pcpb,fysl,fydw,zyjzfdm,jcbw,bz,ybxmdm,ybxmmc,jccs,
                                          yzzxsj,fxbz)
                        select concat(id, '#WN') as id,jzid,yzmxh,jzlsh,yljgdm,cxbz,kh,klx,sflb,bq,xdksdm,xdksmc,xdrgh,xdrxm,xdsj,
                               zxksdm,zxksmc,zxrgh,zxrxm,zxsj,zzsj,yzsm,yzlb,xmdm,xmmc,sfyp,xmdj,xmdw,
                               (v_zsl_z - v_zsl_f) as xmsl,
                                round(xmje / xmsl * (v_zsl_z - v_zsl_f), 4) as xmje,ypgg,ypyf,jx,yypc,jl,jldw,sldw,yytj,yyts,pcpb,fysl,fydw,
                               zyjzfdm,jcbw,bz,ybxmdm,ybxmmc,jccs,yzzxsj,'3'
                           from T_ZYYZMX
                              where id = v_id2;
                     commit;

                     set v_id2 = concat(v_id2, '#WN');

                     -- 插入关联表数据
                     insert into T_CXGL(ysid, rzid, ghid, cxlx, cjsj, gxsj)
                        select id, v_id2, v_jzid1, '3', now(), now()
                           from T_ZFJY_DETAIL_TEMP
                              where fxbz = '1';
                     commit;

                     -- 作废的人造数据，追溯上一层的关联原始数据
                     insert into T_CXGL(ysid, rzid, ghid, cxlx, cjsj, gxsj)
                        select ysid, v_id2, v_jzid1, '3', now(), now()
                           from T_CXGL
                              where rzid in (select id
                                                from T_ZFJY_DETAIL_TEMP
                                                   where fxbz = '3') and cxlx = '3';
                     commit;

                     leave read_loop6;

                  end if;

                  set v_id2 = null;
                  set v_sl2 = 0;
                  set v_fxbz = null;

               end loop;

               close cur6;

            end;

         end if;

         set v_zsl_z = 0;
         set v_zsl_f = 0;
         set v_jzid1 = null;
         set v_xmdm1 = null;
         set v_dj1 = null;

      end loop;
  
      close cur5;

   end;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zfjy', '住院医嘱明细正负交易数据处理完成');
   commit;

-- --------------------------------------------------------------------------------------------

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zfjy', '开始处理住院收费明细正负交易数据');
   commit;

   set v_jzid1 = null;
   set v_xmdm1 = null;
   set v_dj1 = null;
   set v_zsl_z = 0;
   set v_zsl_f = 0;

   begin

      declare cur7_done int default false;
      declare cur7 cursor for select jzid, xmdm, dj from T_ZFJY_TEMP where cxlx = '4';
      declare continue handler for not found set cur7_done = true;

      open cur7;

      read_loop7: loop

         fetch cur7 into v_jzid1, v_xmdm1, v_dj1;
    
         if cur7_done then
            leave read_loop7;
         end if;

         -- 获取总的正负数量
         select ifnull(abs(sum(case when xmsl > 0 then xmsl else 0 end)), 0),
                ifnull(abs(sum(case when xmsl < 0 then xmsl else 0 end)), 0)
            into v_zsl_z, v_zsl_f
               from T_ZYSFMX
                  where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3');

         -- 如果完全匹配或负交易总数大于正交易
         if v_zsl_z <= v_zsl_f then

            -- 所有数据更新为无效
            update T_ZYSFMX
               set fxbz = case when fxbz = '1' then '0'
                               when fxbz = '3' then '2' end
                  where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3');
            commit;

         else

            set v_zsl_z = 0;

            begin

               declare cur8_done int default false;
               declare cur8 cursor for select id, xmsl, fxbz from T_ZYSFMX where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3') and xmsl > 0 order by jsrq desc;
               declare continue handler for not found set cur8_done = true;

               set v_id2 = null;
               set v_sl2 = 0;
               set v_fxbz = null;

               truncate table T_ZFJY_DETAIL_TEMP;

               insert into T_ZFJY_DETAIL_TEMP(id, fxbz)
                  select id, fxbz from T_ZYSFMX where jzid = v_jzid1 and xmdm = v_xmdm1 and xmdj = v_dj1 and fxbz in ('1', '3') and xmsl < 0;
               commit;

               open cur8;

               read_loop8: loop

                  -- 逐条获取正数据
                  fetch cur8 into v_id2, v_sl2, v_fxbz;

                  if cur8_done then
                    leave read_loop8;
                  end if;

                  -- 累加正数据
                  set v_zsl_z = v_zsl_z + ifnull(v_sl2, 0);

                  -- 先将这条数据记录到临时表
                  insert into T_ZFJY_DETAIL_TEMP(id, fxbz)
                     values(v_id2, v_fxbz);
                  commit;

                  -- 数据到此正好完全抵消
                  if v_zsl_z = v_zsl_f then

                     -- 所有数据更新为无效
                     update T_ZYSFMX
                        set fxbz = case when fxbz = '1' then '0'
                                        when fxbz = '3' then '2' end
                           where id in (select id from T_ZFJY_DETAIL_TEMP);
                     commit;

                     leave read_loop8;

                  elseif v_zsl_z > v_zsl_f then

                     -- 所有数据更新为无效
                     update T_ZYSFMX
                        set fxbz = case when fxbz = '1' then '0'
                                        when fxbz = '3' then '2' end
                           where id in (select id from T_ZFJY_DETAIL_TEMP);
                     commit;

                     -- 为多出的正数据生成人造数据
                     insert into T_ZYSFMX(id,yzmxid,jzid,jzlsh,yzmxh,yljgdm,kh,klx,sflb,jsrq,xmdm,xmmc,xmdw,xmgg,xmdj,xmsl,xmje,
                                          ybxmdm,ybxmmc,ksdm,ksmc,fxbz)
                        select concat(id, '#WN') as id,yzmxid,jzid,jzlsh,yzmxh,yljgdm,kh,klx,sflb,jsrq,xmdm,xmmc,xmdw,xmgg,xmdj,
                               (v_zsl_z - v_zsl_f) as xmsl,
                               round(xmje / xmsl * (v_zsl_z - v_zsl_f), 4) as xmje,ybxmdm,ybxmmc,ksdm,ksmc,'3'
                           from T_ZYSFMX
                              where id = v_id2;
                     commit;

                     set v_id2 = concat(v_id2, '#WN');

                     -- 插入关联表数据
                     insert into T_CXGL(ysid, rzid, ghid, cxlx, cjsj, gxsj)
                        select id, v_id2, v_jzid1, '4', now(), now()
                           from T_ZFJY_DETAIL_TEMP
                              where fxbz = '1';
                     commit;

                     -- 作废的人造数据，追溯上一层的关联原始数据
                     insert into T_CXGL(ysid, rzid, ghid, cxlx, cjsj, gxsj)
                        select ysid, v_id2, v_jzid1, '4', now(), now()
                           from T_CXGL
                              where rzid in (select id
                                                from T_ZFJY_DETAIL_TEMP
                                                   where fxbz = '3') and cxlx = '4';
                     commit;

                     leave read_loop8;

                  end if;

                  set v_id2 = null;
                  set v_sl2 = 0;
                  set v_fxbz = null;

               end loop;

               close cur8;

            end;

         end if;

         set v_zsl_z = 0;
         set v_zsl_f = 0;
         set v_jzid1 = null;
         set v_xmdm1 = null;
         set v_dj1 = null;

      end loop;
  
      close cur7;

   end;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zfjy', '住院收费明细正负交易数据处理完成');
   commit;

end;
