CREATE PROCEDURE etl_hzxx(IN Startsj DATE, IN Endsj DATE)
  BEGIN
	--  异常处理
   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION
   begin
       rollback;
       GET DIAGNOSTICS CONDITION 1  v_code = RETURNED_SQLSTATE , v_message= MESSAGE_TEXT; 
       insert into etl_log(dt,pr_name, message)
       select sysdate(),'etl_hzxx',concat('报错',v_code,v_message);
      commit;
   end;
--  中间表数据抽取到仓库表
         INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_hzxx',
		               '开始抽取患者信息');
                 COMMIT;

          REPLACE INTO t_hzxx (HZID,
	                             YLJGDM,
	                             KH,
		                           KLX,
		                           HZXM,
		                           HZXB,
		                           HYZK,
		                           CSRQ,
		                           MZ,
		                           GJ,
		                           DHHM) 
      SELECT  HZID,
	            YLJGDM,
	            KH,
	            KLX,
	            HZXM,
	            HZXB,
	            HYZK,
	            CSRQ,
	            MZ,
	            GJ,
	            DHHM
           FROM zjb_hzxx
       WHERE  cjsj >= Startsj
          AND cjsj < Endsj;
          COMMIT;

--  备份数据  
           INSERT INTO etl_log (dt, pr_name, message)
              VALUES
	              (sysdate(),
		            'etl_hzxx',
		            '开始备份所抽取患者信息');

            REPLACE INTO zjb_hzxx_bak (HZID,
	                                     YLJGDM,
	                                     KH,
	                                     KLX,
	                                     HZXM,
	                                     HZXB,
	                                     HYZK,
	                                     CSRQ,
	                                     MZ,
	                                     GJ,
	                                     DHHM,
	                                     CJSJ) 
                  SELECT  HZID,
	                        YLJGDM,
	                        KH,
	                        KLX,
	                        HZXM,
	                        HZXB,
	                        HYZK,
	                        CSRQ,
	                        MZ,
	                        GJ,
	                        DHHM,
	                        CJSJ
                 FROM  zjb_hzxx
                WHERE  cjsj >= Startsj
                   AND cjsj < Endsj;
              COMMIT;
    -- 删除数据
                INSERT INTO etl_log (dt, pr_name, message)
                         VALUES
	                     (sysdate(),
		                   'etl_hzxx',
		                   '删除中间表数据');

           DELETE FROM zjb_hzxx
              WHERE  cjsj >= Startsj
                 AND cjsj < Endsj;
            COMMIT;

           INSERT INTO etl_log (dt, pr_name, message)
             VALUES
	           (sysdate(),
	          	'etl_hzxx',
	          	'患者信息抽取完毕');
 
END;
