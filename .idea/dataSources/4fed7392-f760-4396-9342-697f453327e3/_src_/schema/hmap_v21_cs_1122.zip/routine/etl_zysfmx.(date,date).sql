CREATE PROCEDURE etl_zysfmx(IN Startsj DATE, IN Endsj DATE)
  begin 
       	--  异常处理
   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION
   begin
       rollback;
       GET DIAGNOSTICS CONDITION 1  v_code = RETURNED_SQLSTATE , v_message= MESSAGE_TEXT; 
       insert into etl_log(dt,pr_name, message)
       select sysdate(),'etl_zysfmx',concat('报错',v_code,v_message);
      commit;
   end;

     INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zysfmx',
		               '清空记录更新挂号临时表');
                 COMMIT;
     truncate table t_zyghgxjl;

  --  涉及更新的挂号ID筛选
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zysfmx',
		               '开始查找出涉及更新挂号ID');
                 COMMIT;

       insert into t_zyghgxjl
            (GHID, YXBZ, CJSJ, GXSJ)
      SELECT t.jzid, '1',t.CJSJ, sysdate()
                FROM zjb_zysfmx t
          INNER JOIN t_zysfmx t1
              ON t.jzid = t1.jzid
         WHERE t.cjsj >= Startsj
          AND t.cjsj < Endsj;
      COMMIT;

      --  中间表数据抽取到仓库表
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zysfmx',
		               '开始抽取住院收费明细');
                 COMMIT;
        
      replace into  t_zysfmx(ID
                           ,YZMXID
                           ,JZID
                           ,JZLSH
                           ,YZMXH
                           ,YLJGDM	
                           ,KH
                           ,KLX
                           ,SFLB
                           ,JSRQ
                           ,XMDM
                           ,XMMC
                           ,XMDW
                           ,XMGG
                           ,XMDJ
                           ,XMSL
                           ,XMJE
                           ,YBXMDM
                           ,YBXMMC
                           ,FXBZ)
                  select    ID
                           ,YZMXID
                           ,JZID
                           ,JZLSH
                           ,YZMXH
                           ,YLJGDM	
                           ,KH
                           ,KLX
                           ,SFLB
                           ,JSRQ
                           ,XMDM
                           ,XMMC
                           ,XMDW
                           ,XMGG
                           ,XMDJ
                           ,XMSL
                           ,XMJE
                           ,YBXMDM
                           ,YBXMMC
                           ,'1'  from zjb_zysfmx 
                 WHERE  cjsj >= Startsj
                    AND cjsj < Endsj; 
           COMMIT;

      --  备份数据  
           INSERT INTO etl_log (dt, pr_name, message)
              VALUES
	              (sysdate(),
		            'etl_zysfmx',
		            '开始备份所抽取住院收费明细');
          COMMIT;
      
             replace into zjb_zysfmx_bak(ID
                             ,YZMXID
                             ,JZID
                             ,JZLSH
                             ,YZMXH
                             ,YLJGDM
                             ,CXBZ
                             ,KH
                             ,KLX
                             ,SFLB
                             ,JSRQ
                             ,XMDM
                             ,XMMC
                             ,XMDW
                             ,XMGG
                             ,XMDJ
                             ,XMSL
                             ,XMJE
                             ,YBXMDM
                             ,YBXMMC
                             ,CJSJ)

                       select ID
                             ,YZMXID
                             ,JZID
                             ,JZLSH
                             ,YZMXH
                             ,YLJGDM
                             ,CXBZ
                             ,KH
                             ,KLX
                             ,SFLB
                             ,JSRQ
                             ,XMDM
                             ,XMMC
                             ,XMDW
                             ,XMGG
                             ,XMDJ
                             ,XMSL
                             ,XMJE
                             ,YBXMDM
                             ,YBXMMC
                             ,CJSJ  from zjb_zysfmx
                 WHERE  cjsj >= Startsj
                    AND cjsj < Endsj; 
           COMMIT;

   insert into ETL_LOG(dt, pr_name, message)
        values (sysdate(), 'etl_zysfmx', '获取负交易数据');
   commit;

   insert into T_ZFJY_TEMP(jzid, xmdm, dj, cxlx)
      select distinct jzid, xmdm, xmdj, '4'
         from ZJB_ZYSFMX t
            where cjsj >= startsj and cjsj < endsj and xmsl < 0;
   commit;
      
      -- 删除数据
                INSERT INTO etl_log (dt, pr_name, message)
                         VALUES
	                     (sysdate(),
		                   'etl_zysfmx',
		                   '删除中间表数据');

      delete from  zjb_zysfmx 
          WHERE  cjsj >= Startsj
             AND cjsj < Endsj; 
           COMMIT;
      
        INSERT INTO etl_log (dt, pr_name, message)
             VALUES
	           (sysdate(),
	          	'etl_zysfmx',
	          	'住院收费明细抽取完毕');
        COMMIT;
 end;
