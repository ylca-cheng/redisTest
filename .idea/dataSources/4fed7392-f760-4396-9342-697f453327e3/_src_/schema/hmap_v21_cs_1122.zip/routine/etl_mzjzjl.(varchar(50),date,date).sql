CREATE PROCEDURE etl_mzjzjl(IN vpcdm VARCHAR(50), IN Startsj DATE, IN Endsj DATE)
  BEGIN
 
   	--  异常处理
   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION
   begin
       rollback;
       GET DIAGNOSTICS CONDITION 1  v_code = RETURNED_SQLSTATE , v_message= MESSAGE_TEXT; 
       insert into etl_log(dt,pr_name, message)
       select sysdate(),'etl_mzjzjl',concat('报错',v_code,v_message);
      commit;
   end;
     --  涉及更新的挂号ID筛选
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_mzjzlj',
		               '开始查找出涉及更新挂号ID');
                 COMMIT;

       insert into t_zyghgxjl
            (GHID, YXBZ, CJSJ, GXSJ)
      SELECT t.ID, '1', t.CJSJ,sysdate()
                FROM zjb_mzjzjl t
          INNER JOIN t_mzjzjl t1
              ON t.id = t1.ID
         WHERE t.cjsj >= Startsj
          AND t.cjsj < Endsj;
      COMMIT;

     --  中间表数据抽取到仓库表
          INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_mzjzlj',
		               '开始抽取门诊就诊记录');
                 COMMIT;
         replace into t_mzjzjl(ID
                              ,JZLSH
                              ,YLJGDM	
                              ,KH
                              ,KLX
                              ,HZID
                              ,HZXM
                              ,HZXB
                              ,HZNL
                              ,CFZBZ
                              ,BXLX
                              ,YLLB
                              ,KSDM
                              ,KSMC
                              ,YSID
                              ,YSXM
                              ,CSRQ
                              ,JZRQ
                              ,ZDDM
                              ,ZDSM
                              ,ZDMC
                              ,ZDDMLX   
                              ,ZS
                              ,ZZMS
                              ,XBS
                              ,GMS
                              ,JWS
                              ,YCJZS
                              ,ZYSZMS
                              ,TGJCJL
                              ,FZJCJL
                              ,CLCS
                              ,SSY
                              ,SZY
                              ,KFXT
                              ,CHXT
                              ,TW
                              ,ML
                              ,XL
                              ,ZJE
                              ,PCDM
                              ,FXBZ
                             )
                select  ID
                       ,JZLSH
                       ,YLJGDM	
                       ,KH
                       ,KLX
                       ,HZID
                       ,HZXM
                       ,HZXB
                       ,HZNL
                       ,CFZBZ
                       ,BXLX
                       ,YLLB
                       ,KSDM
                       ,KSMC
                       ,YSID
                       ,YSXM
                       ,CSRQ
                       ,JZRQ
                       ,ZDDM
                       ,ZDSM
                       ,ZDMC
                       ,ZDDMLX   
                       ,ZS
                       ,ZZMS
                       ,XBS
                       ,GMS
                       ,JWS
                       ,YCJZS
                       ,ZYSZMS
                       ,TGJCJL
                       ,FZJCJL
                       ,CLCS
                       ,SSY
                       ,SZY
                       ,KFXT
                       ,CHXT
                       ,TW
                       ,ML
                       ,XL
                       ,ZJE
                       ,vpcdm
                       ,'1'   from  zjb_mzjzjl 
               WHERE  cjsj >= Startsj
                  AND cjsj < Endsj;
           COMMIT;
    
 --  备份数据  
           INSERT INTO etl_log (dt, pr_name, message)
              VALUES
	              (sysdate(),
		            'etl_mzjzjl',
		            '开始备份所抽取门诊就诊记录');
                 COMMIT;
     
            REPLACE INTO zjb_mzjzjl_bak (ID
                                        ,JZLSH
                                        ,YLJGDM
                                        ,CXBZ
                                        ,KH
                                        ,KLX
                                        ,HZID
                                        ,HZXM
                                        ,HZXB
                                        ,HZNL
                                        ,CFZBZ
                                        ,BXLX
                                        ,YLLB
                                        ,KSDM
                                        ,KSMC
                                        ,YSID
                                        ,YSXM
                                        ,CSRQ
                                        ,JZRQ
                                        ,ZDDM
                                        ,ZDSM
                                        ,ZDMC
                                        ,ZDDMLX
                                        ,ZJE
                                        ,ZS
                                        ,ZZMS
                                        ,XBS
                                        ,GMS
                                        ,JWS
                                        ,YCJZS
                                        ,ZYSZMS
                                        ,TGJCJL
                                        ,FZJCJL
                                        ,CLCS
                                        ,SSY
                                        ,SZY
                                        ,KFXT
                                        ,CHXT
                                        ,TW
                                        ,ML
                                        ,XL
                                        ,CJSJ)
                     select ID
                           ,JZLSH
                           ,YLJGDM
                           ,CXBZ
                           ,KH
                           ,KLX
                           ,HZID
                           ,HZXM
                           ,HZXB
                           ,HZNL
                           ,CFZBZ
                           ,BXLX
                           ,YLLB
                           ,KSDM
                           ,KSMC
                           ,YSID
                           ,YSXM
                           ,CSRQ
                           ,JZRQ
                           ,ZDDM
                           ,ZDSM
                           ,ZDMC
                           ,ZDDMLX
                           ,ZJE
                           ,ZS
                           ,ZZMS
                           ,XBS
                           ,GMS
                           ,JWS
                           ,YCJZS
                           ,ZYSZMS
                           ,TGJCJL
                           ,FZJCJL
                           ,CLCS
                           ,SSY
                           ,SZY
                           ,KFXT
                           ,CHXT
                           ,TW
                           ,ML
                           ,XL
                           ,CJSJ from zjb_mzjzjl  
                     WHERE  cjsj >= Startsj
                        AND cjsj < Endsj;
             COMMIT;

        -- 删除数据
                INSERT INTO etl_log (dt, pr_name, message)
                         VALUES
	                     (sysdate(),
		                   'etl_mzjzjl',
		                   '删除中间表数据');
              COMMIT;

               delete from zjb_mzjzjl  
                    WHERE  cjsj >= Startsj
                        AND cjsj < Endsj;
               COMMIT;
      INSERT INTO etl_log (dt, pr_name, message)
             VALUES
	           (sysdate(),
	          	'etl_mzjzjl',
	          	'门诊就诊记录抽取完毕');
 
   end;
