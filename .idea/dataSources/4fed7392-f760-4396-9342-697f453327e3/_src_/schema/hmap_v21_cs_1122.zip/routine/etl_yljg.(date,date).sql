CREATE PROCEDURE etl_yljg(IN Startsj DATE, IN Endsj DATE)
  begin 
       
	--  异常处理
   declare v_code varchar(100);
   declare v_message varchar(1000);

   -- 定义异常处理
   declare exit HANDLER FOR SQLWARNING,NOT FOUND,SQLEXCEPTION
   begin
       rollback;
       GET DIAGNOSTICS CONDITION 1  v_code = RETURNED_SQLSTATE , v_message= MESSAGE_TEXT; 
       insert into etl_log(dt,pr_name, message)
       select sysdate(),'etl_yljg',concat('报错',v_code,v_message);
      commit;
   end;
        
       --  中间表数据抽取到仓库表
         INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_yljg',
		               '开始抽取医疗机构');
                 COMMIT;
            
            replace into t_yljg(ID
                               ,JGDM
                               ,JGMC
                               ,JGLX
                               ,JGDJ)
             select ID
                   ,JGDM
                   ,JGMC
                   ,JGLX
                   ,JGDJ  from zjb_yljg
              WHERE  cjsj >= Startsj
                 AND cjsj < Endsj;
            COMMIT;
   
       --  备份数据  
           INSERT INTO etl_log (dt, pr_name, message)
              VALUES
	              (sysdate(),
		            'etl_yljg',
		            '开始备份所抽取医疗机构');
             replace into zjb_yljg_bak (ID
                                       ,JGDM
                                       ,JGMC
                                       ,JGLX
                                       ,JGDJ
                                       ,CJSJ)
                  select ID
                        ,JGDM
                        ,JGMC
                        ,JGLX
                        ,JGDJ
                        ,CJSJ  from zjb_yljg
                     WHERE  cjsj >= Startsj
                        AND cjsj < Endsj;
              COMMIT;
           -- 删除数据
                INSERT INTO etl_log (dt, pr_name, message)
                         VALUES
	                     (sysdate(),
		                   'etl_yljg',
		                   '删除中间表数据');
             delete from zjb_yljg 
                  WHERE  cjsj >= Startsj
                     AND cjsj < Endsj;
             COMMIT;
          INSERT INTO etl_log (dt, pr_name, message)
             VALUES
	           (sysdate(),
	          	'etl_yljg',
	          	'医疗机构抽取完毕');
         COMMIT;
     end;
