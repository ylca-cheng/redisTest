CREATE FUNCTION months_between(beginDate DATETIME, endDate DATETIME)
  RETURNS INT(10)
  BEGIN
RETURN YEAR(beginDate)*12+MONTH(beginDate)-YEAR(endDate)*12-MONTH(endDate);
END;
