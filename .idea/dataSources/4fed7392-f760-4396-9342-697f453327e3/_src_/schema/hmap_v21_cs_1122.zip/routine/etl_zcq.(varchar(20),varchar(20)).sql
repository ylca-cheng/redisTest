CREATE PROCEDURE etl_zcq(IN kssj VARCHAR(20), IN jssj VARCHAR(20))
  begin 
                declare  Startsj date;  -- 数据抽取开始时间
                declare  Endsj   date;  -- 数据抽取结束时间
                declare  vpcdm  bigint (50); --  数据批次代码
                declare  MzGhdj_minseq  int; --  挂号最小ID 
                declare  MzGhdj_maxseq  int; --  挂号最大ID
                declare  MzGhdj_count   int; --  本批次门诊挂号数据量
                declare  ZyGhdj_minseq  int; --  挂号最小ID 
                declare  ZyGhdj_maxseq  int; --  挂号最大ID
                declare  ZyGhdj_count   int; -- 本批次住院挂号数据量
                declare  vdate varchar(50);  -- 月抽取使用
                declare  Startmon date;   -- 上月初
                declare  Endmon   date;   -- 上月底
                declare  MzGhdj_minseqMon  int; --  月记录挂号 最小ID 
                declare  MzGhdj_maxseqMon  int; --  月记录挂号最大ID
                declare  MzGhdj_countMon   int; --  月记录门诊挂号数据量
                declare  ZyGhdj_minseqMon  int; --  月记录挂号最小ID 
                declare  ZyGhdj_maxseqMon  int; --  月记录挂号最大ID
                declare  ZyGhdj_countMon   int; --   月记录住院挂号数据量

             set Startmon=date_sub(date_sub(date_format(now(), '%y-%m-%d'),
                        interval extract(day from now()) - 1 day),interval 1 month);  -- 上月初
             set Endmon=date_sub(date_sub(date_format(now(), '%y-%m-%d'),
                        interval extract(day from now()) - 1 day),interval 0 month);  -- 上月底
             set vdate = date_format(sysdate(),'%d');   
             set Startsj=kssj; -- 正常抽取开始时间为昨天
             set  Endsj=jssj;  -- 正常抽取结束时间为昨天
             set vpcdm = date_format(sysdate(),'%Y%m%d%H%i');-- 当前批次代码生成
            
             INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zysfmx',
		               '清空记录更新挂号临时表');
                 COMMIT;
                truncate table t_zyghgxjl;

             INSERT INTO etl_log (dt, pr_name, message)
             VALUES( sysdate(),
		               'etl_zcq',
		               '清空负交易临时表');
             COMMIT;
				 
             truncate table T_ZFJY_TEMP;

             INSERT INTO etl_log (dt, pr_name, message)
             VALUES(sysdate(),
		                'etl_zcq',
		                concat('当前抽取数据时间区间为', kssj,'-', jssj));
             COMMIT;


             call etl_hzxx(Startsj,Endsj);  
             call etl_ksxx(Startsj,Endsj);
             call etl_yhry(Startsj,Endsj);
             call etl_yljg(Startsj,Endsj);
             call etl_mzsfmx(Startsj,Endsj);
             call etl_mzcfmx(vpcdm,Startsj,Endsj);
             call etl_mzjzjl(vpcdm,Startsj,Endsj);
             call etl_zysfmx(Startsj,Endsj);
             call etl_zyyzmx(vpcdm,Startsj,Endsj);
             call etl_zyjzjl(vpcdm,Startsj,Endsj);
             
              
              select min(SEQ_ID) into MzGhdj_minseq from t_mzjzjl   -- 门诊最小SEQ_ID
                 where PCDM=vpcdm;    --  本批次最小SEQ_ID
              select max(SEQ_ID) into MzGhdj_maxseq from t_mzjzjl   -- 门诊最大SEQ_ID
                 where PCDM=vpcdm;    --  本批次最大SEQ_ID
              select count(SEQ_ID) into MzGhdj_count from t_mzjzjl  -- 门诊数据量
                 where PCDM=vpcdm;    --  本批次共抽取挂号数据数量
              select min(SEQ_ID) into ZyGhdj_minseq from t_zyjzjl   -- 住院最小SEQ_ID
                 where PCDM=vpcdm;    --  本批次最小SEQ_ID
              select max(SEQ_ID) into ZyGhdj_maxseq from t_zyjzjl   -- 住院最大SEQ_ID
                 where PCDM=vpcdm;    --  本批次最大SEQ_ID
              select count(SEQ_ID) into ZyGhdj_count from t_zyjzjl  -- 住院数据量
                 where PCDM=vpcdm;  

              select min(SEQ_ID) into MzGhdj_minseqMon from t_mzjzjl   -- 月记录门诊最小SEQ_ID
                 where jzrq>=Startmon
                   and jzrq<Endmon; 
              select max(SEQ_ID) into MzGhdj_maxseqMon from t_mzjzjl   -- 月记录门诊最大SEQ_ID
                  where jzrq>=Startmon
                    and jzrq<Endmon;   
              select count(SEQ_ID) into MzGhdj_countMon from t_mzjzjl  -- 月记录门诊数据量
                 where jzrq>=Startmon
                   and jzrq<Endmon;  
              select min(SEQ_ID) into ZyGhdj_minseqMon from t_zyjzjl   -- 月记录住院最小SEQ_ID
                  where cyrq>=Startmon
                    and cyrq<Endmon;  
              select max(SEQ_ID) into ZyGhdj_maxseqMon from t_zyjzjl   -- 月记录住院最大SEQ_ID
                  where cyrq>=Startmon
                    and cyrq<Endmon;    
              select count(SEQ_ID) into ZyGhdj_countMon from t_zyjzjl  -- 月记录住院数据量
                 where cyrq>=Startmon
                   and cyrq<Endmon; 

    -- 数据抽取完毕 生成门诊DATA_STATUS  日记录
   INSERT INTO data_status  (
                  ID,
                  BATCH_NUM,
                  GHDJ_MIN_SEQ,
	                GHDJ_SEQ,
	                GHDJ_FLAG,
	                JSMX_SEQ,
	                JSMX_FLAG,
	                CFMX_SEQ,
	                CFMX_FLAG,
	                CREATE_TIME,
	                JZLX,
	                ZQ,
	                RQ,
	                ENABLE_FLAG,
	                SORTNUM)
           VALUES(0,
                   vpcdm,
                   ifnull(MzGhdj_minseq,0),
                   ifnull(MzGhdj_maxseq,0),
                  '1',
                   0,
                   '1',
                   0,
                   '1',
                   sysdate(),
                   '1',
                   'D',
                   date_format(sysdate(),'%y%m%d'),
                    1,
                    null);
					
      -- 生成门诊DATA_STATUS_INFO   日记录
           insert into  data_status_info (ID
                                 ,PID
                                 ,GHDJ_MIN_SEQ
                                 ,GHDJ_MAX_SEQ
                                 ,GHDJ_COUNT
                                 ,GENERAL_RULE_FLAG
                                 ,CLINICAL_ANALYSIS_FLAG
                                 ,CLINICAL_SUMMARY_FLAG
                                 ,STATISTICAL_ANALYSIS_FLAG
                                 ,MANY_CARD_FLAG
                                 ,DRUG_RELATION_FLAG
                                 ,START_DATE
                                 ,END_DATE
                                 ,SORTNUM
                                 ,ENABLE_FLAG
                                 ,CREATE_TIME
                                 ,SEQ_DATE_FLAG)
                    select   0,
                             id,
                             GHDJ_MIN_SEQ,
                             GHDJ_SEQ,
                             MzGhdj_count,
                             '0',
                             '0',
                             '0',
                             '0',
                             '-1',
                             '-1',
                             date_format(Startsj,'%Y%m%d'),
                             date_format(Endsj,'%Y%m%d'),
                             0,
                             '1',
                             sysdate(),
                             '1'  from data_status
                    where   BATCH_NUM=vpcdm
                            and  JZLX='1'
                            and   ZQ='D' ;     
                   COMMIT;

       -- 住院生成DATAS_STAUTS 日记录
         INSERT INTO data_status (
                  ID,
                  BATCH_NUM,
                  GHDJ_MIN_SEQ,
	                GHDJ_SEQ,
	                GHDJ_FLAG,
	                JSMX_SEQ,
	                JSMX_FLAG,
	                CFMX_SEQ,
	                CFMX_FLAG,
	                CREATE_TIME,
	                JZLX,
	                ZQ,
	                RQ,
	                ENABLE_FLAG,
	                SORTNUM)
           VALUES(0,
                   vpcdm,
                   ifnull(ZyGhdj_minseq,0),
                   ifnull(ZyGhdj_maxseq,0),
                  '1',
                   0,
                   '1',
                   0,
                   '1',
                   sysdate(),
                   '2',
                   'D',
                   date_format(sysdate(),'%y%m%d'),
                    1,
                    null);  

          -- 生成门诊DATA_STATUS_INFO   日记录
           insert into  data_status_info (ID
                                 ,PID
                                 ,GHDJ_MIN_SEQ
                                 ,GHDJ_MAX_SEQ
                                 ,GHDJ_COUNT
                                 ,GENERAL_RULE_FLAG
                                 ,CLINICAL_ANALYSIS_FLAG
                                 ,CLINICAL_SUMMARY_FLAG
                                 ,STATISTICAL_ANALYSIS_FLAG
                                 ,MANY_CARD_FLAG
                                 ,DRUG_RELATION_FLAG
                                 ,START_DATE
                                 ,END_DATE
                                 ,SORTNUM
                                 ,ENABLE_FLAG
                                 ,CREATE_TIME
                                 ,SEQ_DATE_FLAG)
                    select   0,
                             id,
                             GHDJ_MIN_SEQ,
                             GHDJ_SEQ,
                             ZyGhdj_count,
                             '0',
                             '0',
                             '0',
                             '0',
                             '-1',
                             '-1',
                             date_format(Startsj,'%Y%m%d'),
                             date_format(Endsj,'%Y%m%d'),
                             0,
                             '1',
                             sysdate(),
                             '1'  from data_status
                    where   BATCH_NUM=vpcdm
                            and  JZLX='2'
                            and   ZQ='D' ;     
                   COMMIT;    
       
       -- 月记录生成
     if   vdate='01'  then 
        -- 生成门诊DATA_STATUS  月记录
   INSERT INTO data_status  (
                  ID,
                  BATCH_NUM,
                  GHDJ_MIN_SEQ,
	                GHDJ_SEQ,
	                GHDJ_FLAG,
	                JSMX_SEQ,
	                JSMX_FLAG,
	                CFMX_SEQ,
	                CFMX_FLAG,
	                CREATE_TIME,
	                JZLX,
	                ZQ,
	                RQ,
	                ENABLE_FLAG,
	                SORTNUM)
           VALUES(0,
                   vpcdm,
                   ifnull(MzGhdj_minseqMon,0),
                   ifnull(MzGhdj_maxseqMon,0),
                  '1',
                   0,
                   '1',
                   0,
                   '1',
                   sysdate(),
                   '1',
                   'M',
                   date_format(sysdate(),'%y%m%d'),
                    1,
                    null);

        -- 生成门诊DATA_STATUS_INFO  月记录
         insert into  data_status_info (ID
                                 ,PID
                                 ,GHDJ_MIN_SEQ
                                 ,GHDJ_MAX_SEQ
                                 ,GHDJ_COUNT
                                 ,GENERAL_RULE_FLAG
                                 ,CLINICAL_ANALYSIS_FLAG
                                 ,CLINICAL_SUMMARY_FLAG
                                 ,STATISTICAL_ANALYSIS_FLAG
                                 ,MANY_CARD_FLAG
                                 ,DRUG_RELATION_FLAG
                                 ,START_DATE
                                 ,END_DATE
                                 ,SORTNUM
                                 ,ENABLE_FLAG
                                 ,CREATE_TIME
                                 ,SEQ_DATE_FLAG)
                    select   0,
                             id,
                             GHDJ_MIN_SEQ,
                             GHDJ_SEQ,
                             MzGhdj_countMon,
                             '0',
                             '0',
                             '0',
                             '0',
                             '-1',
                             '-1',
                             date_format(Startmon,'%Y%m%d'),
                             date_format(Endmon,'%Y%m%d'),
                             0,
                             '1',
                             sysdate(),
                             '1'  from data_status
                    where   BATCH_NUM=vpcdm
                            and  JZLX='1'
                            and   ZQ='M' ;
                    COMMIT; 

          -- 生成住院DATA_STATUS  月记录
              INSERT INTO data_status  (
                  ID,
                  BATCH_NUM,
                  GHDJ_MIN_SEQ,
	                GHDJ_SEQ,
	                GHDJ_FLAG,
	                JSMX_SEQ,
	                JSMX_FLAG,
	                CFMX_SEQ,
	                CFMX_FLAG,
	                CREATE_TIME,
	                JZLX,
	                ZQ,
	                RQ,
	                ENABLE_FLAG,
	                SORTNUM)
           VALUES(0,
                   vpcdm,
                   ifnull(ZyGhdj_minseqMon,0),
                   ifnull(ZyGhdj_maxseqMon,0),
                  '1',
                   0,
                   '1',
                   0,
                   '1',
                   sysdate(),
                   '2',
                   'M',
                   date_format(sysdate(),'%y%m%d'),
                    1,
                    null);

      -- 生成门诊DATA_STATUS_INFO  月记录
         insert into  data_status_info (ID
                                 ,PID
                                 ,GHDJ_MIN_SEQ
                                 ,GHDJ_MAX_SEQ
                                 ,GHDJ_COUNT
                                 ,GENERAL_RULE_FLAG
                                 ,CLINICAL_ANALYSIS_FLAG
                                 ,CLINICAL_SUMMARY_FLAG
                                 ,STATISTICAL_ANALYSIS_FLAG
                                 ,MANY_CARD_FLAG
                                 ,DRUG_RELATION_FLAG
                                 ,START_DATE
                                 ,END_DATE
                                 ,SORTNUM
                                 ,ENABLE_FLAG
                                 ,CREATE_TIME
                                 ,SEQ_DATE_FLAG)
                    select   0,
                             id,
                             GHDJ_MIN_SEQ,
                             GHDJ_SEQ,
                             ZyGhdj_countMon,
                             '0',
                             '0',
                             '0',
                             '0',
                             '-1',
                             '-1',
                             date_format(Startmon,'%Y%m%d'),
                             date_format(Endmon,'%Y%m%d'),
                             0,
                             '1',
                             sysdate(),
                             '1'  from data_status
                    where   BATCH_NUM=vpcdm
                            and  JZLX='2'
                            and   ZQ='M' ;
                    COMMIT; 
        end if;

        -- 负交易处理  
        call etl_zfjy;

       INSERT INTO etl_log (dt, pr_name, message)
               VALUES
	                ( sysdate(),
		               'etl_zcq',
		               '程序执行完毕');
      end;
