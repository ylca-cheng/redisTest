CREATE FUNCTION MAINT_LOG(START_DATE IN VARCHAR2,
                                     END_DATE   IN VARCHAR2)
  RETURN T_MAINT_LOG_TABLE
  PIPELINED AS
  TABLE_SQL        VARCHAR2(4000); --记录表sql
  TABLE_DATA_SQL   VARCHAR2(500); --拼接时间sql
  TABLE_START_DATE VARCHAR2(500); --拼接时间sql
  TABLE_ADD_SB     VARCHAR2(100); --已提交新增
  TABLE_SB_EDIT    VARCHAR2(100); --已提交编辑
  TABLE_SB_DEL     VARCHAR2(100); --已提交删除
  TABLE_COUNT      VARCHAR2(100); --总数
  SUBMIT_NUM       VARCHAR2(100); --提交数
  IS_SUBMIT        VARCHAR2(100); --判断是否提交
  DATA_NM          VARCHAR2(100); --表名
  DATA_RELA        VARCHAR2(100); --关联表
  RELA_FIELD       VARCHAR2(100); --关联字段
  DATA_SHEET       VARCHAR2(100); --数据表
  CORRESPOND_FIELD VARCHAR2(100); --关联表对应数据表字段
  FATHER_DATA      VARCHAR2(100); --父类表
  FATHER_FIELD     VARCHAR2(100); --关联父类表字段
  TABLE_MSG        VARCHAR2(100);
  TYPE TYPE_VARRAY IS VARRAY(9999999) OF VARCHAR2(4000);
  MSG_ARRAY          TYPE_VARRAY; --将类型赋给变量
  MAINT_ARRAY        TYPE_VARRAY;
  RULE_ARRAY         TYPE_VARRAY;
  IS_NULL            TYPE_VARRAY;
  OPERS_ARRAY        TYPE_VARRAY;
  SUBMIT_TYPES_ARRAY TYPE_VARRAY;
  CHANGE_TYPES_ARRAY TYPE_VARRAY;
  OPER_ARRAY         TYPE_VARRAY;
  SUBMIT_TYPE_ARRAY  TYPE_VARRAY;
  CHANGE_TYPE_ARRAY  TYPE_VARRAY;
  TARGET_ARRAY       TYPE_VARRAY;
  CHANGE_ARRAY       TYPE_VARRAY;
  SUBMIT_ARRAY       TYPE_VARRAY;
  I                  NUMBER;
  J                  NUMBER;
  K                  NUMBER;
  TABLE_MAINT_LOG    T_MAINT_LOG;
BEGIN
  SELECT MOD_CD, MAINT_NM, DATA_RELA, RULE BULK COLLECT
    INTO MSG_ARRAY, MAINT_ARRAY, IS_NULL, RULE_ARRAY
    FROM KBMS_CLINICAL_CLASS_NAME
   WHERE MAINT_NM IS NOT NULL
     AND FLG = '1';
  <<OUTER>>
  FOR I IN 1 .. MSG_ARRAY.COUNT() LOOP
    TABLE_ADD_SB := 0;
    TABLE_SB_EDIT := 0;
    TABLE_SB_DEL := 0;
    TABLE_COUNT := 0;
    IF START_DATE IS NULL THEN
      TABLE_SQL := '';
    ELSE
      TABLE_DATA_SQL := ' AND TO_DATE( OPER_TIME, ''YYYY-MM-DD HH24:MI:SS'')  >= TO_DATE( ''' || START_DATE || ''',''YYYY-MM-DD  HH24:MI:SS'') ';
      TABLE_START_DATE :='AND TO_DATE( OPER_TIME, ''YYYY-MM-DD HH24:MI:SS'')  >= TO_DATE( ''' || START_DATE || ''',''YYYY-MM-DD  HH24:MI:SS'') ';
    END IF;
    IF END_DATE IS NULL THEN
      TABLE_SQL := '';
    ELSE
      TABLE_DATA_SQL := TABLE_DATA_SQL || ' AND TO_DATE( OPER_TIME, ''YYYY-MM-DD HH24:MI:SS'')  <= TO_DATE( ''' || END_DATE || ''',''YYYY-MM-DD  HH24:MI:SS'') ';
    END IF;

    TABLE_SQL := 'SELECT TARGET_ID,OPERS,SUBMIT_TYPES,CHANGE_TYPES FROM (SELECT TARGET_ID, ''''''''||LISTAGG(OPER, ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME)||'''''''' OPERS, ''''''''||LISTAGG(NVL(SUBMIT_TYPE,0), ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME) ||'''''''' SUBMIT_TYPES, ''''''''||LISTAGG(NVL(CHANGE_TYPE,0), ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME) ||'''''''' CHANGE_TYPES FROM KBMS_CLINICAL_OPER_LOG WHERE ((CHANGE_TYPE <> ''D'' AND CHANGE_TYPE <> ''E'') OR CHANGE_TYPE IS NULL) AND USER_NAME IN (SELECT USER_NAME FROM KBMS_USER_ROLE WHERE ROLE_ID IN(''R00007'', ''R00006'', ''R00002'', ''R00001'', ''R00000'')) AND MSG = ''' ||
                 MSG_ARRAY(I) || '''' || TABLE_DATA_SQL || ' GROUP BY MSG, TARGET_ID )';
    EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO TARGET_ARRAY,OPERS_ARRAY, SUBMIT_TYPES_ARRAY ,CHANGE_TYPES_ARRAY;
    IF IS_NULL(I) IS NULL THEN
      <<INNER>>
      FOR J IN 1 .. OPERS_ARRAY.COUNT() LOOP
        TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||OPERS_ARRAY(J)||'))';
        EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO OPER_ARRAY;
        TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||SUBMIT_TYPES_ARRAY(J)||'))';
        EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO SUBMIT_TYPE_ARRAY;
        TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||CHANGE_TYPES_ARRAY(J)||'))';
        EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO CHANGE_TYPE_ARRAY;
        ------------------药品规则配置、药品说明书、商品名药品规则配置---------------------------
        IF MSG_ARRAY(I) = 'DrugList' OR MSG_ARRAY(I) = 'DrugInstructions' OR MSG_ARRAY(I) = 'DrugTradNameInstructions' THEN
          ---------------新增开头--------------------
          IF OPER_ARRAY(1) = '新增' THEN
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              TABLE_SQL := '';
            ELSE
                TABLE_ADD_SB := TABLE_ADD_SB + 1;
            END IF;
          END IF;
          ---------------修改开头--------------------
          IF OPER_ARRAY(1) = '修改' THEN
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              IF CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
                TABLE_SB_DEL := TABLE_SB_DEL + 1;
              END IF;
            ELSE
              IF INSTR(CHANGE_TYPES_ARRAY(J),'B') > 0  THEN
                TABLE_SB_EDIT := TABLE_SB_EDIT + 1;
              END IF;
            END IF;
          END IF;
          ---------------删除开头--------------------
          IF OPER_ARRAY(1) = '删除' OR OPER_ARRAY(1) = '逻辑删除' THEN
            IF CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
              TABLE_SB_DEL := TABLE_SB_DEL + 1;
            END IF;
          END IF;
        ELSE
          ---------------新增开头--------------------
          IF OPER_ARRAY(1) = '新增' THEN
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              TABLE_SQL := '';
            ELSE
              IF INSTR(OPERS_ARRAY(J),'提交') > 0 THEN
                TABLE_ADD_SB := TABLE_ADD_SB + 1;
              ELSE
                IF INSTR(OPERS_ARRAY(J),'修改') > 0 AND INSTR(SUBMIT_TYPES_ARRAY(J),'1') > 0 THEN
                  TABLE_ADD_SB := TABLE_ADD_SB + 1;
                END IF;
              END IF;
            END IF;
          END IF;
         ---------------提交开头--------------------
          IF OPER_ARRAY(1) = '提交' THEN
             IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
               TABLE_SQL := '';
             ELSE
               TABLE_ADD_SB := TABLE_ADD_SB + 1;
             END IF;
          END IF;
          ---------------修改开头--------------------
          IF OPER_ARRAY(1) = '修改' THEN
            IF INSTR(OPERS_ARRAY(J),'提交') > 0 AND INSTR(OPERS_ARRAY(J),'删除') <= 0 THEN
              TABLE_ADD_SB := TABLE_ADD_SB + 1;
            ELSE
              IF INSTR(SUBMIT_TYPES_ARRAY(J),'1') > 0  THEN
                IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                  IF CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
                    TABLE_SB_DEL := TABLE_SB_DEL + 1;
                  END IF;
                ELSE
                  IF INSTR(CHANGE_TYPES_ARRAY(J),'B') > 0  THEN
                    TABLE_SB_EDIT := TABLE_SB_EDIT + 1;
                  END IF;
                END IF;
              END IF;
            END IF;
          END IF;
          ---------------删除开头--------------------
          IF OPER_ARRAY(1) = '删除' OR OPER_ARRAY(1) = '逻辑删除' THEN
            IF SUBMIT_TYPE_ARRAY(1) = '2' AND CHANGE_TYPE_ARRAY(1) = 'B' THEN
               TABLE_SB_DEL := TABLE_SB_DEL + 1;
            END IF;
          END IF;
        END IF;
      END LOOP INNER;
    ELSE
      SELECT DATA_NM, DATA_RELA, RELA_FIELD, DATA_SHEET, CORRESPOND_FIELD, FATHER_DATA, FATHER_FIELD
        INTO DATA_NM, DATA_RELA, RELA_FIELD, DATA_SHEET, CORRESPOND_FIELD, FATHER_DATA, FATHER_FIELD
        FROM KBMS_CLINICAL_CLASS_NAME
       WHERE MOD_CD = MSG_ARRAY(I);
      ---记录从关联数据表操作的模块ID
      TABLE_SQL := 'SELECT MOD_CD FROM KBMS_CLINICAL_CLASS_NAME WHERE DATA_NM = ''' ||DATA_SHEET || '''';
      EXECUTE IMMEDIATE TABLE_SQL INTO TABLE_MSG;

      IF FATHER_DATA IS NULL THEN
         DBMS_OUTPUT.PUT_LINE('NULL！！！');
      ELSE
        <<INNER>>
        FOR K IN 1 .. TARGET_ARRAY.COUNT() LOOP
          TABLE_SQL := 'SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||OPERS_ARRAY(K)||'))';
          EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO OPER_ARRAY;
          TABLE_SQL := 'SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||SUBMIT_TYPES_ARRAY(K)||'))';
          EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO SUBMIT_TYPE_ARRAY;
          TABLE_SQL := 'SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||CHANGE_TYPES_ARRAY(K)||'))';
          EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO CHANGE_TYPE_ARRAY;
          --父类数据是否提交
          TABLE_SQL := 'SELECT IS_SUBMIT FROM '|| FATHER_DATA ||' WHERE ID = (SELECT '|| FATHER_FIELD ||' FROM '|| DATA_NM ||' WHERE ID = '''||TARGET_ARRAY(K)||''')';
          EXECUTE IMMEDIATE TABLE_SQL INTO IS_SUBMIT;
          IF IS_SUBMIT = '1' THEN
            --查询关联表是否提交
            --TABLE_SQL :='SELECT IS_SUBMIT FROM '|| DATA_RELA ||' WHERE ID = (SELECT ' || RELA_FIELD || ' FROM  ' || DATA_NM || ' WHERE ID = ''' || TARGET_ARRAY(K) || ''')';
            --EXECUTE IMMEDIATE TABLE_SQL INTO IS_SUBMIT;
           -- IF IS_SUBMIT = '1' THEN
              --查询关联表对应数据表已提交且这段时间没有进行操作的数据
            TABLE_SQL :='SELECT COUNT(1) FROM ' || DATA_SHEET || ' WHERE IS_SUBMIT = ''1'' AND ID NOT IN (SELECT TARGET_ID FROM KBMS_CLINICAL_OPER_LOG T1 WHERE T1.MSG = (SELECT MOD_CD FROM KBMS_CLINICAL_CLASS_NAME WHERE DATA_NM = '''|| DATA_SHEET ||''') AND OPER = ''提交'' '|| TABLE_START_DATE ||' ) AND ' || CORRESPOND_FIELD || ' =  (SELECT ' || RELA_FIELD || ' FROM  ' || DATA_NM || ' WHERE ID = ''' || TARGET_ARRAY(K) || ''') ';
            EXECUTE IMMEDIATE TABLE_SQL INTO SUBMIT_NUM;
           -- ELSE
             -- SUBMIT_NUM := 0;
           -- END IF;
            ---------------新增开头--------------------
            IF OPER_ARRAY(1) = '新增' THEN
              IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                TABLE_SQL := '';
              ELSE
                IF INSTR(OPERS_ARRAY(K),'提交') > 0 THEN
                  TABLE_ADD_SB := TABLE_ADD_SB + SUBMIT_NUM;
                ELSE
                  IF INSTR(OPERS_ARRAY(K),'修改') > 0 AND INSTR(SUBMIT_TYPES_ARRAY(K),'1') > 0 THEN
                    TABLE_ADD_SB := TABLE_ADD_SB + SUBMIT_NUM;
                  END IF;
                END IF;
              END IF;
            END IF;

           ---------------提交开头--------------------
            IF OPER_ARRAY(1) = '提交' THEN
               IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                 TABLE_SQL := '';
               ELSE
                 TABLE_ADD_SB := TABLE_ADD_SB + SUBMIT_NUM;
               END IF;
            END IF;
            ---------------修改开头--------------------
            IF OPER_ARRAY(1) = '修改' THEN
              IF INSTR(OPERS_ARRAY(K),'提交') > 0 AND INSTR(OPERS_ARRAY(K),'删除') <= 0 THEN
                TABLE_ADD_SB := TABLE_ADD_SB + SUBMIT_NUM;
              ELSE
                IF INSTR(SUBMIT_TYPES_ARRAY(K),'1') > 0  THEN
                  IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                    IF CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
                      TABLE_SB_DEL := TABLE_SB_DEL + 1;
                    END IF;
                  ELSE
                    IF INSTR(CHANGE_TYPES_ARRAY(K),'B') > 0  THEN
                      TABLE_SB_EDIT := TABLE_SB_EDIT + SUBMIT_NUM;
                    END IF;
                  END IF;
                END IF;
              END IF;
            END IF;
            ---------------删除开头--------------------
            IF OPER_ARRAY(1) = '删除' OR OPER_ARRAY(1) = '逻辑删除' THEN
              IF SUBMIT_TYPE_ARRAY(1) = '2' AND CHANGE_TYPE_ARRAY(1) = 'B' THEN
                 TABLE_SB_DEL := TABLE_SB_DEL + SUBMIT_NUM;
              END IF;
            END IF;
          END IF;
        END LOOP INNER;
      END IF;
      ---记录从关联数据表操作
      TABLE_SQL := 'SELECT TARGET_ID,OPERS,SUBMIT_TYPES,CHANGE_TYPES FROM (SELECT TARGET_ID, ''''''''||LISTAGG(OPER, ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME)||'''''''' OPERS, ''''''''||LISTAGG(NVL(SUBMIT_TYPE,0), ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME) ||'''''''' SUBMIT_TYPES, ''''''''||LISTAGG(NVL(CHANGE_TYPE,0), ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME) ||'''''''' CHANGE_TYPES FROM KBMS_CLINICAL_OPER_LOG WHERE ((CHANGE_TYPE <> ''D'' AND CHANGE_TYPE <> ''E'') OR CHANGE_TYPE IS NULL) AND USER_NAME IN (SELECT USER_NAME FROM KBMS_USER_ROLE WHERE ROLE_ID IN(''R00007'', ''R00006'', ''R00002'', ''R00001'', ''R00000'')) AND MSG = ''' ||
                 TABLE_MSG || '''' || TABLE_DATA_SQL || ' GROUP BY MSG, TARGET_ID )';
      EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO TARGET_ARRAY,OPERS_ARRAY, SUBMIT_TYPES_ARRAY ,CHANGE_TYPES_ARRAY;
      DBMS_OUTPUT.PUT_LINE(DATA_NM);
       DBMS_OUTPUT.PUT_LINE(DATA_RELA);
        DBMS_OUTPUT.PUT_LINE(RELA_FIELD);
         DBMS_OUTPUT.PUT_LINE(DATA_SHEET);
          DBMS_OUTPUT.PUT_LINE(CORRESPOND_FIELD);
           DBMS_OUTPUT.PUT_LINE(FATHER_DATA);
            DBMS_OUTPUT.PUT_LINE(FATHER_FIELD);
      <<INNER>>
      FOR K IN 1 .. TARGET_ARRAY.COUNT() LOOP
        --判断上表是否提交
        TABLE_SQL:= 'SELECT IS_SUBMIT FROM '|| FATHER_DATA ||' WHERE ID IN ( SELECT '|| FATHER_FIELD ||' FROM '|| DATA_NM ||' WHERE '|| RELA_FIELD ||' = (SELECT '|| CORRESPOND_FIELD||' FROM '|| DATA_SHEET ||' WHERE ID = '''|| TARGET_ARRAY(K) ||'''))' ;
        EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO SUBMIT_ARRAY;
        <<IN_INNER>>
        FOR J IN 1 .. SUBMIT_ARRAY.COUNT() LOOP
          IF SUBMIT_ARRAY(J) = '1' THEN
            TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||OPERS_ARRAY(K)||'))';
            EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO OPER_ARRAY;
            TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||SUBMIT_TYPES_ARRAY(K)||'))';
            EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO SUBMIT_TYPE_ARRAY;
            TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||CHANGE_TYPES_ARRAY(K)||'))';
            EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO CHANGE_TYPE_ARRAY;
            ---------------新增开头--------------------
            IF OPER_ARRAY(1) = '新增' THEN
              IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                TABLE_SQL := '';
              ELSE
                IF INSTR(OPERS_ARRAY(K),'提交') > 0 THEN
                  TABLE_ADD_SB := TABLE_ADD_SB + 1;
                ELSE
                  IF INSTR(OPERS_ARRAY(K),'修改') > 0 AND INSTR(SUBMIT_TYPES_ARRAY(K),'1') > 0 THEN
                    TABLE_ADD_SB := TABLE_ADD_SB + 1;
                  END IF;
                END IF;
              END IF;
            END IF;
           ---------------提交开头--------------------
            IF OPER_ARRAY(1) = '提交' THEN
               IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                 TABLE_SQL := '';
               ELSE
                 TABLE_ADD_SB := TABLE_ADD_SB + 1;
               END IF;
            END IF;
            ---------------修改开头--------------------
            IF OPER_ARRAY(1) = '修改' THEN
              IF INSTR(OPERS_ARRAY(K),'提交') > 0 AND INSTR(OPERS_ARRAY(K),'删除') <= 0 THEN
                TABLE_ADD_SB := TABLE_ADD_SB + 1;
              ELSE
                IF INSTR(SUBMIT_TYPES_ARRAY(K),'1') > 0  THEN
                  IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                    IF CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
                      TABLE_SB_DEL := TABLE_SB_DEL + 1;
                    END IF;
                  ELSE
                    IF INSTR(CHANGE_TYPES_ARRAY(K),'B') > 0  THEN
                      TABLE_SB_EDIT := TABLE_SB_EDIT + 1;
                    END IF;
                  END IF;
                END IF;
              END IF;
            END IF;
            ---------------删除开头--------------------
            IF OPER_ARRAY(1) = '删除' OR OPER_ARRAY(1) = '逻辑删除' THEN
              IF SUBMIT_TYPE_ARRAY(1) = '2' AND CHANGE_TYPE_ARRAY(1) = 'B' THEN
                 TABLE_SB_DEL := TABLE_SB_DEL + 1;
              END IF;
            END IF;
          END IF;
        END LOOP IN_INNER;
      END LOOP INNER;

    END IF;
    TABLE_COUNT     := TABLE_ADD_SB + TABLE_SB_EDIT + TABLE_SB_DEL;
    TABLE_MAINT_LOG := T_MAINT_LOG(MAINT_ARRAY(I),
                                   TABLE_ADD_SB,
                                   TABLE_SB_EDIT,
                                   TABLE_SB_DEL,
                                   TABLE_COUNT,
                                   RULE_ARRAY(I));
    PIPE ROW(TABLE_MAINT_LOG);
  END LOOP OUTER;
  RETURN;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('表不存在！！！');
END;
/
