CREATE function FN_GET_SYNONYM(vZskbm varchar2) return varchar2 is
  vResult varchar2(1000);
begin
   
   vResult := '';

   for c_row1 in (select distinct 知识库通用名 as rst
                    from temp_jjys t
                       where t.知识库编码 = vZskbm)
   loop
      if c_row1.rst is not null then
         vResult := vResult || c_row1.rst || ',';
      end if;
   end loop;

   for c_row2 in (select distinct 知识库商品名 as rst
                    from temp_jjys t
                       where t.知识库编码 = vZskbm)
   loop
      if c_row2.rst is not null then
         vResult := vResult || c_row2.rst || ',';
      end if;
   end loop;
   
   for c_row3 in (select distinct 映射商品名 as rst
                    from temp_jjys t
                       where t.知识库编码 = vZskbm)
   loop
      if c_row3.rst is not null then
         vResult := vResult || c_row3.rst || ',';
      end if;
   end loop;

   vResult := substr(vResult, 1, length(vResult) - 1);

   return(vResult);

end FN_GET_SYNONYM;
/
