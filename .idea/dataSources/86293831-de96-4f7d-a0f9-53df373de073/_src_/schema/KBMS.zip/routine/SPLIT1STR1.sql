CREATE function split1str1(str in clob,
                                    i  in number := 0,
                                    sep in varchar2 := ',') return varchar2 is
  t_i    number;
  t_count number;
  t_str  varchar2(4000);
begin
  if i = 0 then
    t_str := str;
  elsif instr(str, sep) = 0 then
    t_str := sep;
  else
    select count(*) into t_count from table(split1(str, sep));

    if i <= t_count then
      select str
        into t_str
        from (select rownum as item, column_value as str
                from table(split1(str, sep)))
      where item = i;
    end if;
  end if;

  return t_str;
end;
/
