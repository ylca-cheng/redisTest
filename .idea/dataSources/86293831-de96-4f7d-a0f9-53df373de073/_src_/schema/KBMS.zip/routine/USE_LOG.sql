CREATE FUNCTION USE_LOG(START_DATE IN VARCHAR2,
                                   END_DATE   IN VARCHAR2)
  RETURN T_USER_LOG_TABLE
  PIPELINED AS
  TABLE_SQL        VARCHAR2(4000); --记录表sql
  TABLE_DATA_SQL   VARCHAR2(4000); --记录表时间sql
  TABLE_SELECT_SQL VARCHAR2(4000); --记录sql
  TABLE_ADD_SB     VARCHAR2(200); --新增已提交
  TABLE_ADD_NOT_SB VARCHAR2(200); --新增未提交
  TABLE_MAPPING    VARCHAR2(200); --映射
  TABLE_SB_EDIT_B  VARCHAR2(200); --已提交编辑B
  TABLE_SB_EDIT_C  VARCHAR2(200); --已提交编辑C
  TABLE_SB_DEL     VARCHAR2(200); --已提交删除
  TABLE_N_SB_DEL   VARCHAR2(200); --未提交删除
  TABLE_COUNT      VARCHAR2(200); --总数
  TABLE_NUM_B      VARCHAR2(200);
  TABLE_NUM_C      VARCHAR2(200);
  TYPE TYPE_VARRAY IS VARRAY(9999999) OF VARCHAR2(4000);
  USER_ARRAY         TYPE_VARRAY;
  MSGS_ARRAY         TYPE_VARRAY;
  TARGETS_ARRAY      TYPE_VARRAY;
  OPERS_ARRAY        TYPE_VARRAY;
  SUBMIT_TYPES_ARRAY TYPE_VARRAY;
  CHANGE_TYPES_ARRAY TYPE_VARRAY;
  TARGET_ARRAY       TYPE_VARRAY;
  OPER_ARRAY         TYPE_VARRAY;
  SUBMIT_TYPE_ARRAY  TYPE_VARRAY;
  CHANGE_TYPE_ARRAY  TYPE_VARRAY;
  I                  NUMBER;
  J                  NUMBER;
  TABLE_USER_LOG T_USER_LOG;
BEGIN
  -----------------------------组装时间sql---------------------------
  IF START_DATE IS NULL THEN
    TABLE_SQL := '';
  ELSE
    TABLE_DATA_SQL := ' AND TO_DATE( OPER_TIME, ''YYYY-MM-DD HH24:MI:SS'')  >= TO_DATE( ''' || START_DATE || ''',''YYYY-MM-DD  HH24:MI:SS'') ';
  END IF;
  IF END_DATE IS NULL THEN
    TABLE_SQL := '';
  ELSE
    TABLE_DATA_SQL := TABLE_DATA_SQL || ' AND TO_DATE( OPER_TIME, ''YYYY-MM-DD HH24:MI:SS'')  <= TO_DATE( ''' || END_DATE || ''',''YYYY-MM-DD  HH24:MI:SS'') ';
  END IF;
  SELECT USER_NAME BULK COLLECT INTO USER_ARRAY FROM KBMS_CLINICAL_OPER_LOG WHERE ((CHANGE_TYPE <> 'D' AND CHANGE_TYPE <> 'E') OR CHANGE_TYPE IS NULL) AND USER_NAME IN (SELECT USER_NAME FROM KBMS_USER_ROLE WHERE ROLE_ID IN('R00007', 'R00006', 'R00002','R00001','R00000')) GROUP BY USER_NAME;
  <<OUTER>>
  FOR I IN 1 .. USER_ARRAY.COUNT() LOOP
    TABLE_SQL := 'SELECT MSG,TARGET_ID,OPERS,SUBMIT_TYPES,CHANGE_TYPES FROM (SELECT USER_NAME,MSG,TARGET_ID, ''''''''||LISTAGG(OPER, ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME)||'''''''' OPERS, ''''''''||LISTAGG(NVL(SUBMIT_TYPE,0), ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME) ||'''''''' SUBMIT_TYPES, ''''''''||LISTAGG(NVL(CHANGE_TYPE,0), ''''''''||'',''||'''''''') WITHIN GROUP(ORDER BY TARGET_ID, OPER_TIME) ||'''''''' CHANGE_TYPES FROM KBMS_CLINICAL_OPER_LOG WHERE ((CHANGE_TYPE <> ''D'' AND CHANGE_TYPE <> ''E'') OR CHANGE_TYPE IS NULL) AND USER_NAME = '''||USER_ARRAY(I)|| ''''||TABLE_DATA_SQL|| ' GROUP BY TARGET_ID,MSG,USER_NAME ) ';
    EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO MSGS_ARRAY,TARGETS_ARRAY,OPERS_ARRAY,SUBMIT_TYPES_ARRAY,CHANGE_TYPES_ARRAY;
    TABLE_ADD_SB := 0;
    TABLE_ADD_NOT_SB := 0;
    TABLE_MAPPING := 0;
    TABLE_SB_EDIT_B := 0;
    TABLE_SB_EDIT_C := 0;
    TABLE_SB_DEL := 0;
    TABLE_N_SB_DEL := 0;
    TABLE_COUNT := 0;
    <<INNER>>
    FOR J IN 1 .. TARGETS_ARRAY.COUNT() LOOP
      -----------关键字段排列-----------------------------
      TABLE_SELECT_SQL := 'SELECT NVL(SUM(DECODE(CV3,''B'',1,0)),0),NVL(SUM(DECODE(CV3,''C'',1,0)),0) FROM (SELECT ROWNUM RW1, COLUMN_VALUE CV1 FROM TABLE(SYS.ODCIVARCHAR2LIST('||OPERS_ARRAY(J)||'))) T1 LEFT JOIN (SELECT ROWNUM RW2, COLUMN_VALUE CV2 FROM TABLE(SYS.ODCIVARCHAR2LIST('||SUBMIT_TYPES_ARRAY(J)||'))) T2 ON T1.RW1 = T2.RW2 LEFT JOIN (SELECT ROWNUM RW3, COLUMN_VALUE CV3 FROM TABLE(SYS.ODCIVARCHAR2LIST('||CHANGE_TYPES_ARRAY(J)||'))) T3 ON T1.RW1 = T3.RW3 ';
      TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||OPERS_ARRAY(J)||'))';
      EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO OPER_ARRAY;
      TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||SUBMIT_TYPES_ARRAY(J)||'))';
      EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO SUBMIT_TYPE_ARRAY;
      TABLE_SQL := ' SELECT COLUMN_VALUE FROM TABLE(SYS.ODCIVARCHAR2LIST('||CHANGE_TYPES_ARRAY(J)||'))';
      EXECUTE IMMEDIATE TABLE_SQL BULK COLLECT INTO CHANGE_TYPE_ARRAY;
      -------药品列表和药品说明书默认为已提交数据
      IF MSGS_ARRAY(J) = 'DrugFromSX' OR MSGS_ARRAY(J) = 'DrugList' THEN
        ---------------新增开头--------------------
         IF OPER_ARRAY(1) = '新增' THEN
           TABLE_ADD_SB := TABLE_ADD_SB + 1;
           IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
             IF CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
               TABLE_SB_DEL := TABLE_SB_DEL + 1;
             END IF;
           END IF;
           IF INSTR(OPERS_ARRAY(J),'修改') > 0 THEN
             TABLE_SQL := TABLE_SELECT_SQL || 'WHERE T1.CV1 = ''修改''';
             EXECUTE IMMEDIATE TABLE_SQL INTO TABLE_NUM_B,TABLE_NUM_C;
             TABLE_SB_EDIT_B := TABLE_SB_EDIT_B + TABLE_NUM_B;
             TABLE_SB_EDIT_C := TABLE_SB_EDIT_C + TABLE_NUM_C;
           END IF;
         END IF;
         ---------------修改开头--------------------
         IF OPER_ARRAY(1) = '修改' THEN
           TABLE_SQL := TABLE_SELECT_SQL || 'WHERE T1.CV1 = ''修改''';
           EXECUTE IMMEDIATE TABLE_SQL INTO TABLE_NUM_B,TABLE_NUM_C;
           TABLE_SB_EDIT_B := TABLE_SB_EDIT_B + TABLE_NUM_B;
           TABLE_SB_EDIT_C := TABLE_SB_EDIT_C + TABLE_NUM_C;
           IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
             IF CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
               TABLE_SB_DEL := TABLE_SB_DEL + 1;
             END IF;
           END IF;
         END IF;
         ---------------删除开头--------------------
         IF OPER_ARRAY(1) = '删除' OR OPER_ARRAY(1) = '逻辑删除' THEN
           IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
             IF CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
               TABLE_SB_DEL := TABLE_SB_DEL + 1;
             END IF;
           END IF;
         END IF;
      ELSE
        ----------药品规则配置-药品规则默认为未提交----------
        ---------未提交数据不统计修改------------------------
        IF MSGS_ARRAY(J) = 'DrugInstructions' THEN
          ---------------新增开头--------------------
          IF OPER_ARRAY(1) = '新增' THEN
            TABLE_ADD_NOT_SB := TABLE_ADD_NOT_SB + 1;
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              TABLE_N_SB_DEL := TABLE_N_SB_DEL + 1;
            END IF;
          END IF;
         ---------------删除开头--------------------
         IF OPER_ARRAY(1) = '修改' THEN
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              TABLE_N_SB_DEL := TABLE_N_SB_DEL + 1;
            END IF;
         END IF;
         ---------------删除开头--------------------
         IF OPER_ARRAY(1) = '删除' OR OPER_ARRAY(1) = '逻辑删除' THEN
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              TABLE_N_SB_DEL := TABLE_N_SB_DEL + 1;
            END IF;
         END IF;
        ELSE
          ---------------新增开头--------------------
          IF OPER_ARRAY(1) = '新增' THEN
            IF INSTR(SUBMIT_TYPES_ARRAY(J),'1') > 0 OR INSTR(SUBMIT_TYPES_ARRAY(J),'2') > 0 THEN
              TABLE_ADD_SB := TABLE_ADD_SB + 1;
              IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                IF SUBMIT_TYPE_ARRAY(SUBMIT_TYPE_ARRAY.COUNT()) = '2' AND CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
                  TABLE_SB_DEL := TABLE_SB_DEL + 1;
                END IF;
              END IF;
              IF INSTR(OPERS_ARRAY(J),'修改') > 0 THEN
                TABLE_SQL := TABLE_SELECT_SQL || 'WHERE T1.CV1 = ''修改'' AND T2.CV2 = ''1''';
                EXECUTE IMMEDIATE TABLE_SQL INTO TABLE_NUM_B,TABLE_NUM_C;
                TABLE_SB_EDIT_B := TABLE_SB_EDIT_B + TABLE_NUM_B;
                TABLE_SB_EDIT_C := TABLE_SB_EDIT_C + TABLE_NUM_C;
              END IF;
            ELSE
              IF INSTR(OPERS_ARRAY(J),'提交') > 0 THEN
                TABLE_ADD_SB := TABLE_ADD_SB + 1;
              ELSE
                TABLE_ADD_NOT_SB := TABLE_ADD_NOT_SB + 1;
              END IF;
              IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
                TABLE_N_SB_DEL := TABLE_N_SB_DEL + 1;
              END IF;
            END IF;
          END IF;
          ---------------提交开头--------------------
          IF OPER_ARRAY(1) = '提交' THEN
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              IF SUBMIT_TYPE_ARRAY(SUBMIT_TYPE_ARRAY.COUNT()) = '2' AND CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
                TABLE_SB_DEL := TABLE_SB_DEL + 1;
              END IF;
            END IF;
            IF INSTR(OPERS_ARRAY(J),'修改') > 0 THEN
              TABLE_SQL := TABLE_SELECT_SQL || 'WHERE T1.CV1 = ''修改'' AND T2.CV2 = ''1''';
              EXECUTE IMMEDIATE TABLE_SQL INTO TABLE_NUM_B,TABLE_NUM_C;
              TABLE_SB_EDIT_B := TABLE_SB_EDIT_B + TABLE_NUM_B;
              TABLE_SB_EDIT_C := TABLE_SB_EDIT_C + TABLE_NUM_C;
            END IF;
          END IF;
          ---------------映射--------------------
          IF INSTR(OPERS_ARRAY(J),'映射') > 0 THEN
            TABLE_MAPPING := TABLE_MAPPING + 1;
          END IF;
          ---------------修改开头--------------------
          IF OPER_ARRAY(1) = '修改' THEN
            TABLE_SQL := TABLE_SELECT_SQL || 'WHERE T1.CV1 = ''修改'' AND T2.CV2 = ''1''';
            EXECUTE IMMEDIATE TABLE_SQL INTO TABLE_NUM_B,TABLE_NUM_C;
            TABLE_SB_EDIT_B := TABLE_SB_EDIT_B + TABLE_NUM_B;
            TABLE_SB_EDIT_C := TABLE_SB_EDIT_C + TABLE_NUM_C;
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              IF SUBMIT_TYPE_ARRAY(SUBMIT_TYPE_ARRAY.COUNT()) = '2' AND CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
                TABLE_SB_DEL := TABLE_SB_DEL + 1;
              END IF;
              IF SUBMIT_TYPE_ARRAY(SUBMIT_TYPE_ARRAY.COUNT()) = '0' THEN
                TABLE_N_SB_DEL := TABLE_N_SB_DEL + 1;
              END IF;
            END IF;
          END IF;
          ---------------删除开头--------------------
          IF OPER_ARRAY(1) = '删除' OR OPER_ARRAY(1) = '逻辑删除' THEN
            IF OPER_ARRAY(OPER_ARRAY.COUNT()) = '删除' OR OPER_ARRAY(OPER_ARRAY.COUNT()) = '逻辑删除' THEN
              IF SUBMIT_TYPE_ARRAY(SUBMIT_TYPE_ARRAY.COUNT()) = '2' AND CHANGE_TYPE_ARRAY(CHANGE_TYPE_ARRAY.COUNT()) = 'B' THEN
                TABLE_SB_DEL := TABLE_SB_DEL + 1;
              END IF;
              IF SUBMIT_TYPE_ARRAY(SUBMIT_TYPE_ARRAY.COUNT()) = '0' THEN
                TABLE_N_SB_DEL := TABLE_N_SB_DEL + 1;
               END IF;
            END IF;
          END IF;
        ----------------------------------------
        END IF;
      END IF;
    END LOOP INNER;
    TABLE_COUNT    := TABLE_ADD_SB + TABLE_ADD_NOT_SB + TABLE_MAPPING + TABLE_SB_EDIT_B + TABLE_SB_EDIT_C + TABLE_SB_DEL + TABLE_N_SB_DEL;
    TABLE_USER_LOG := T_USER_LOG(USER_ARRAY(I),
                                 TABLE_ADD_SB,
                                 TABLE_ADD_NOT_SB,
                                 TABLE_MAPPING,
                                 TABLE_SB_EDIT_B,
                                 TABLE_SB_EDIT_C,
                                 TABLE_SB_DEL,
                                 TABLE_N_SB_DEL,
                                 TABLE_COUNT);
    PIPE ROW(TABLE_USER_LOG);
  END LOOP OUTER;
  RETURN;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('表不存在！！！');
END;
/
