CREATE type tabletype1 as table of varchar2(32676)
/
