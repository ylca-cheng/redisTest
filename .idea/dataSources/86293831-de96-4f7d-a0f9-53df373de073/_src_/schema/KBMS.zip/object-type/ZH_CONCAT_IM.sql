CREATE TYPE zh_concat_im AUTHID CURRENT_USER AS OBJECT
(
  CURR_STR clob,
  STATIC FUNCTION ODCIAGGREGATEINITIALIZE(SCTX IN OUT zh_concat_im)
    RETURN NUMBER,
  MEMBER FUNCTION ODCIAGGREGATEITERATE(SELF IN OUT zh_concat_im,
                                       P1   IN VARCHAR2) RETURN NUMBER,
  MEMBER FUNCTION ODCIAGGREGATETERMINATE(SELF        IN zh_concat_im,
                                         RETURNVALUE OUT clob,
                                         FLAGS       IN NUMBER)
    RETURN NUMBER,

  MEMBER FUNCTION ODCIAGGREGATEMERGE(SELF  IN OUT zh_concat_im,
                                     SCTX2 IN zh_concat_im) RETURN NUMBER
)
/
