CREATE type str2tblType  as table of varchar2(4000)
/
