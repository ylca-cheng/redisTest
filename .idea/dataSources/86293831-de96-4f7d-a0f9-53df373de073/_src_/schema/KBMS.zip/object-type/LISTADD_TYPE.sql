CREATE type listadd_type as table of varchar2(4000)
/
