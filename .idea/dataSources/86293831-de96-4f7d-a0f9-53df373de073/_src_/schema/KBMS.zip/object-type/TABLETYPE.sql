CREATE type tabletype as table of varchar2(32676)
/
